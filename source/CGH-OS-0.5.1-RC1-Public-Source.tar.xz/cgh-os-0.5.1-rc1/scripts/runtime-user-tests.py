#!/usr/bin/env python3
"""Safe user-session checks. Uses temporary files; does not install software."""
import os,pathlib,subprocess,tempfile,json,shutil,sys,tarfile
results=[]
def check(name,args,timeout=90):
 try:
  p=subprocess.run(args,capture_output=True,text=True,timeout=timeout)
  results.append({'check':name,'passed':p.returncode==0,'returncode':p.returncode})
 except (OSError,subprocess.TimeoutExpired):results.append({'check':name,'passed':False,'reason':'unavailable or timeout'})
if os.geteuid()==0:raise SystemExit('Run user checks as the ordinary desktop user, not root.')
with tempfile.TemporaryDirectory(prefix='cgh-user-test-') as td:
 r=pathlib.Path(td)
 check('python_venv',['python3','-m','venv',str(r/'venv')])
 if (r/'venv/bin/python').exists():check('isolated_python',[str(r/'venv/bin/python'),'-c','assert sum([2,3])==5'])
 check('javascript',['node','-e','if ([1,2,3].reduce((a,b)=>a+b,0)!==6) process.exit(1)'])
 (r/'main.c').write_text('int main(void){return 0;}\n')
 check('c_compiler',['gcc',str(r/'main.c'),'-o',str(r/'main')])
 if (r/'main').exists():check('compiled_program',[str(r/'main')])
 check('gtk_import',['python3','-c','import gi;gi.require_version("Gtk","3.0");from gi.repository import Gtk'])
 check('vm_disk_creation',['qemu-img','create','-f','qcow2',str(r/'test.qcow2'),'128M'])
 check('rootless_podman_info',['podman','info','--format','json'],timeout=60)
 image=None
 try:
  fs=r/'container';(fs/'bin').mkdir(parents=True);(fs/'tmp').mkdir()
  binary=pathlib.Path('/usr/bin/busybox')
  if not binary.exists():binary=pathlib.Path('/bin/busybox')
  shutil.copy2(binary,fs/'bin/busybox');(fs/'bin/sh').symlink_to('busybox')
  archive=r/'rootfs.tar'
  with tarfile.open(archive,'w') as tar:tar.add(fs,arcname='.')
  imported=subprocess.run(['podman','import','--quiet',str(archive)],capture_output=True,text=True,timeout=90)
  if imported.returncode==0:
   image=imported.stdout.strip().splitlines()[-1]
   check('offline_rootless_container',['podman','run','--rm','--network=none',image,'/bin/busybox','true'])
  else:results.append({'check':'offline_rootless_container','passed':False,'reason':'local image import failed'})
 except (OSError,subprocess.TimeoutExpired,IndexError):results.append({'check':'offline_rootless_container','passed':False,'reason':'unavailable or timeout'})
 finally:
  if image:subprocess.run(['podman','image','rm','--force',image],capture_output=True,timeout=30)
 p=subprocess.run(['sudo','-n','-k','true'],capture_output=True)
 results.append({'check':'no_passwordless_sudo','passed':p.returncode!=0})
print(json.dumps({'schema':1,'scope':'ordinary user smoke tests, not complete OS certification','results':results},indent=2))
sys.exit(0 if all(x['passed'] for x in results) else 1)
