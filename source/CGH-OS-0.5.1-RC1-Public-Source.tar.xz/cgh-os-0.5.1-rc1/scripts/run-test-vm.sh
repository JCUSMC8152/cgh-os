#!/bin/bash
# Use only an official checksum-verified disposable cloud-image copy.
set -euo pipefail
: "${CGH_VM_DISK:?Set CGH_VM_DISK to the disposable qcow2 image}"
: "${CGH_VM_SEED:?Set CGH_VM_SEED to a cloud-init ISO with a temporary public SSH key}"
command -v qemu-system-x86_64 >/dev/null
exec qemu-system-x86_64 -machine q35 -accel tcg,thread=multi -cpu max \
 -smp 2 -m 4096 -drive "file=$CGH_VM_DISK,format=qcow2,if=virtio" \
 -drive "file=$CGH_VM_SEED,format=raw,media=cdrom" \
 -netdev user,id=net0,hostfwd=tcp:127.0.0.1:2229-:22 \
 -device virtio-net-pci,netdev=net0,romfile= -display none \
 -serial file:cgh-vm-serial.log -monitor none
