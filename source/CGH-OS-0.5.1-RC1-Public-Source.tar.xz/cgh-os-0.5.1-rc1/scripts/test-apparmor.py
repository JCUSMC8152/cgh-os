#!/usr/bin/env python3
"""Controlled denial test in a disposable QEMU guest only."""
import os,pathlib,subprocess,tempfile,sys,json
if os.geteuid()!=0:raise SystemExit('Root required in the disposable VM.')
product=pathlib.Path('/sys/class/dmi/id/product_name').read_text()
if not any(x in product.lower() for x in ['qemu','kvm','standard pc']):raise SystemExit('Refusing outside the disposable VM.')
name='cgh_acceptance_'+str(os.getpid())
with tempfile.TemporaryDirectory(prefix='cgh-aa-') as td:
 secret=pathlib.Path(td)/'secret';secret.write_text('CGH acceptance fixture\n')
 profile=f'''#include <tunables/global>
profile {name} {{
 #include <abstractions/base>
 /usr/bin/cat rix,
 audit deny {secret} r,
}}
'''
 load=subprocess.run(['apparmor_parser','-r'],input=profile,text=True,capture_output=True)
 if load.returncode:raise SystemExit('Unable to load the test profile; enforcement not verified.')
 try:
  plain=subprocess.run(['/usr/bin/cat',str(secret)],capture_output=True)
  confined=subprocess.run(['aa-exec','-p',name,'--','/usr/bin/cat',str(secret)],capture_output=True)
  passed=plain.returncode==0 and confined.returncode!=0 and b'Permission denied' in confined.stderr and str(secret).encode() in confined.stderr
  print(json.dumps({'apparmor_controlled_denial_passed':passed}))
  sys.exit(0 if passed else 1)
 finally:subprocess.run(['apparmor_parser','-R'],input=profile,text=True,capture_output=True)
