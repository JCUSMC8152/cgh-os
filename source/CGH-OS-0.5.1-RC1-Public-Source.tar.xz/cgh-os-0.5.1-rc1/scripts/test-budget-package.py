#!/usr/bin/python3
import configparser,hashlib,json,os,subprocess,tempfile,time
from pathlib import Path
root=Path(__file__).resolve().parents[1]
with tempfile.TemporaryDirectory() as td:
 temp=Path(td); package=root/'artifacts/cgh-budget_0.4.0~milestone2_all.deb'
 subprocess.run(['dpkg-deb','-x',str(package),str(temp)],check=True)
 for name in ('budget.py','budget_store.py'):
  assert (root/'src'/name).read_bytes()==(temp/'usr/share/cgh-os'/name).read_bytes()
 desktop=configparser.ConfigParser(); desktop.read(temp/'usr/share/applications/com.crawfordgroupholdings.CGHBudget.desktop')
 assert desktop['Desktop Entry']['Exec']=='/usr/bin/python3 /usr/share/cgh-os/budget.py'
 assert (temp/'usr/share/icons/hicolor/scalable/apps'/ (desktop['Desktop Entry']['Icon']+'.svg')).exists()
 deps=subprocess.check_output(['dpkg-deb','-f',str(package),'Depends'],text=True).strip()
 assert all(x in deps for x in ('python3','python3-gi','gir1.2-gtk-3.0'))
 env=dict(os.environ,XDG_DATA_HOME=str(temp/'user-data'))
 proc=subprocess.Popen(['/usr/bin/python3',str(temp/'usr/share/cgh-os/budget.py')],env=env,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
 try:
  time.sleep(1.5); assert proc.poll() is None,proc.communicate()
  assert (temp/'user-data/cgh-os/budget/budget.sqlite3').is_file()
 finally: proc.terminate(); stdout,stderr=proc.communicate(timeout=5)
 result={'package_sha256':hashlib.sha256(package.read_bytes()).hexdigest(),'source_matches':True,'desktop_exec_and_icon':True,'dependencies':deps,'packaged_process_launch':True,'stderr':stderr.decode(),'scope':'Exec launched from extracted package prefix on host Xvfb, not GNOME menu in a new ISO'}
 print(json.dumps(result,indent=2))
