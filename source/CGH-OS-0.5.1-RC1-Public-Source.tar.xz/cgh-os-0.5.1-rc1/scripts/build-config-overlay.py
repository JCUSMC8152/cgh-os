#!/usr/bin/env python3
"""Apply audited source configuration to a built live ISO; no device writes."""
import pathlib,subprocess,tempfile,shutil,json,hashlib,sys,os
repo=pathlib.Path(__file__).resolve().parents[1]
if len(sys.argv)!=3:raise SystemExit('Usage: build-config-overlay.py BASE.iso NEW.iso')
base=pathlib.Path(sys.argv[1]).resolve();out=pathlib.Path(sys.argv[2]).resolve()
metadata=json.loads((repo/'docs/recovered-file-metadata.json').read_text())
for name,target in metadata['symlinks'].items():
 p=repo/name
 if not p.is_symlink() or os.readlink(p)!=target:raise SystemExit('Source symlink metadata lost: '+name)
for name in metadata['executables']:
 if not os.stat(repo/name).st_mode & 0o111:raise SystemExit('Source executable permission lost: '+name)
if not base.is_file() or base.suffix.lower()!='.iso':raise SystemExit('Base must be a regular ISO file.')
if out.exists() or out.suffix.lower()!='.iso':raise SystemExit('Output must be a new ISO filename.')
def digest(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for b in iter(lambda:f.read(8*1024*1024),b''):h.update(b)
 return h.hexdigest()
with tempfile.TemporaryDirectory(prefix='cgh-config-build-') as td:
 t=pathlib.Path(td);root=t/'root';shutil.copytree(repo/'config/includes.chroot',root,symlinks=True)
 subprocess.run(['dconf','compile',str(root/'etc/dconf/db/local'),str(root/'etc/dconf/db/local.d')],check=True)
 subprocess.run(['gtk-update-icon-cache','--force','--ignore-theme-index',str(root/'usr/share/icons/CGH-Ribbon')],check=True)
 tests=root/'usr/share/cgh-os/tests';tests.mkdir(parents=True,exist_ok=True)
 for name in ['test-icons-runtime.py','runtime-user-tests.py','test-apparmor.py','test-firewall.py','test-restic.sh','test-luks-file.sh','test-everyday-cli.py','test-user-vm.py']:
  shutil.copy2(repo/'scripts'/name,tests/name)
 files={str(p.relative_to(root)):digest(p) for p in sorted(root.rglob('*')) if p.is_file() and not p.is_symlink()}
 info={'schema':1,'product':'CGH OS','version':'0.4.0 Milestone 02 Budget live candidate','source_commit':subprocess.check_output(['git','-C',str(repo),'rev-parse','HEAD'],text=True).strip(),'input_iso_sha256':digest(base),'configuration_file_sha256':files,'configuration_file_modes':{str(p.relative_to(root)):oct(p.stat().st_mode & 0o777) for p in root.rglob('*') if p.is_file() and not p.is_symlink()},'configuration_symlinks':{str(p.relative_to(root)):os.readlink(p) for p in root.rglob('*') if p.is_symlink()},'method':'Debian package-integrated live root plus root-owned configuration squashfs module','scope':'No installer or persistence; no public-release signature'}
 (root/'usr/share/cgh-os/build-info.json').write_text(json.dumps(info,indent=2)+'\n')
 (t/'filesystem.module').write_text('filesystem.squashfs\ncgh-config.squashfs\n')
 subprocess.run(['mksquashfs',str(root),str(t/'cgh-config.squashfs'),'-all-root','-noappend','-comp','zstd','-processors','1','-no-progress'],check=True)
 subprocess.run(['xorriso','-indev',str(base),'-outdev',str(out),'-boot_image','any','replay','-map',str(t/'cgh-config.squashfs'),'/live/cgh-config.squashfs','-map',str(t/'filesystem.module'),'/live/filesystem.module','-map',str(repo/'preview/grub/grub.cfg'),'/boot/grub/grub.cfg','-map',str(repo/'preview/isolinux/live.cfg'),'/isolinux/live.cfg','-map',str(repo/'preview/isolinux/menu.cfg'),'/isolinux/menu.cfg','-commit','-end'],check=True)
 out.with_suffix('.iso.sha256').write_text(digest(out)+'  '+out.name+'\n')
print('CGH_CONFIG_IMAGE_BUILT',out)
