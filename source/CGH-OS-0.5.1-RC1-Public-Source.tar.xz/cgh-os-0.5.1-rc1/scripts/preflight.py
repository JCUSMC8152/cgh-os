#!/usr/bin/env python3
import json,os,platform,pathlib,shutil
print(json.dumps({'architecture':platform.machine(),'memory_kib':next((x.split()[1] for x in pathlib.Path('/proc/meminfo').read_text().splitlines() if x.startswith('MemTotal:')),None),'uefi':pathlib.Path('/sys/firmware/efi').exists(),'kvm_device':pathlib.Path('/dev/kvm').exists(),'virtualization_flags':any(x in pathlib.Path('/proc/cpuinfo').read_text().split() for x in ['vmx','svm']),'build_tools':{x:shutil.which(x) for x in ['lb','debootstrap','qemu-system-x86_64']},'root':os.geteuid()==0},indent=2))
