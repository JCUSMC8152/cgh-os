#!/usr/bin/env python3
"""Build-root assertions; not hardware certification."""
import pathlib,subprocess,json,sys
root=pathlib.Path(sys.argv[1]).resolve()
assert root != pathlib.Path('/') and (root/'etc/debian_version').is_file()
def installed(name):
 return subprocess.check_output(['chroot',str(root),'dpkg-query','-W','-f=${Version}',name],text=True).strip()
results=[]
def record(name,passed,detail=''):
 results.append({'check':name,'passed':bool(passed),'detail':detail})
for name in ['clamav','clamav-base','clamav-freshclam','libclamav12']:
 version=installed(name)
 record(name+'_minimum_1.4.6',subprocess.run(['dpkg','--compare-versions',version,'ge','1.4.6']).returncode==0,version)
for name,minimum in [('firefox-esr','153.6.0esr-1~deb13u1'),('thunderbird','1:153.6.0esr-1~deb13u1'),('imagemagick-7-common','8:7.1.1.43+dfsg1-1+deb13u13'),('libmagickcore-7.q16-10','8:7.1.1.43+dfsg1-1+deb13u13'),('libmagickwand-7.q16-10','8:7.1.1.43+dfsg1-1+deb13u13')]:
 version=installed(name)
 record(name+'_release_security_floor',subprocess.run(['dpkg','--compare-versions',version,'ge',minimum]).returncode==0,version)
record('tracepath_package_registered',bool(installed('iputils-tracepath')))
config=(root/'etc/clamav/freshclam.conf').read_text()
record('no_absent_clamd_notification',not any(x.strip().startswith('NotifyClamd ') for x in config.splitlines()))
unit=root/'etc/systemd/system/clamav-freshclam.service'
record('updater_not_masked',not(unit.is_symlink() and str(unit.readlink())=='/dev/null'))
record('updater_enabled',(root/'etc/systemd/system/multi-user.target.wants/clamav-freshclam.service').is_symlink())
record('single_updater_mode',not any((root/p).is_symlink() for p in ['etc/systemd/system/multi-user.target.wants/clamav-freshclam-once.service','etc/systemd/system/timers.target.wants/clamav-freshclam-once.timer']))
private=[]
for pattern in ['root/.ssh/*','root/.gnupg/*','home/*/.ssh/*','home/*/.local/share/cghremote/*','etc/ssh/ssh_host_*_key','etc/NetworkManager/system-connections/*']:
 private.extend(str(p.relative_to(root)) for p in root.glob(pattern) if p.is_file())
record('no_private_access_material',not private,private)
record('no_known_build_proxy',not(root/'etc/apt/apt.conf.d/99build-proxy').exists())
print(json.dumps({'schema':1,'scope':'build-root assertions; not runtime or hardware certification','results':results},indent=2))
sys.exit(0 if all(x['passed'] for x in results) else 1)
