#!/bin/bash
set -euo pipefail
[[ "${CGH_ALLOW_SUPERSEDED_PREVIEW:-}" == yes ]] || { echo "The 0.1.0 preview is superseded; use the integrated candidate workflow." >&2; exit 1; }
cd "$(dirname "$0")/.."
: "${CGH_BASE_ISO:?Set CGH_BASE_ISO to the original Debian 13.7 GNOME live ISO}"
: "${CGH_OUTPUT_ISO:?Set CGH_OUTPUT_ISO to a new output path}"
[[ ! -e "$CGH_OUTPUT_ISO" ]] || { echo 'Output exists; choose a new path.' >&2; exit 1; }
printf '%s  %s\n' e94859a83b305cae5125dc9c6080ced040c59d099ea7381e7f300fd1dba87a17 "$CGH_BASE_ISO" | sha256sum -c -
mkdir -p .build
mksquashfs preview/overlay .build/cgh-preview.squashfs -noappend -all-root -comp xz -processors 2 -no-progress
xorriso -indev "$CGH_BASE_ISO" -outdev "$CGH_OUTPUT_ISO" \
 -boot_image any replay -volid CGH_OS_PREVIEW \
 -map .build/cgh-preview.squashfs /live/cgh-preview.squashfs \
 -map preview/filesystem.module /live/filesystem.module \
 -map preview/isolinux/live.cfg /isolinux/live.cfg \
 -map preview/isolinux/menu.cfg /isolinux/menu.cfg \
 -map preview/isolinux/isolinux.cfg /isolinux/isolinux.cfg \
 -map preview/grub/grub.cfg /boot/grub/grub.cfg \
 -map preview/info /.disk/info \
 -map preview/overlay/usr/share/cgh-os/PREVIEW.txt /CGH-README.txt \
 -rm /md5sum.txt -- -commit -end
sha256sum "$CGH_OUTPUT_ISO"
