#!/bin/bash
set -euo pipefail
work=$(mktemp -d)
trap 'rm -rf -- "$work"' EXIT
export RESTIC_REPOSITORY="$work/repo"
export RESTIC_PASSWORD_FILE="$work/password"
head -c 48 /dev/urandom | base64 > "$RESTIC_PASSWORD_FILE"
chmod 600 "$RESTIC_PASSWORD_FILE"
mkdir "$work/source" "$work/restore"
printf 'CGH backup restore acceptance\n' > "$work/source/test.txt"
restic init >/dev/null
restic backup "$work/source" >/dev/null
restic restore latest --target "$work/restore" >/dev/null
cmp "$work/source/test.txt" "$work/restore$work/source/test.txt"
echo CGH_BACKUP_RESTORE_PASS
