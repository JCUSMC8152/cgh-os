#!/bin/bash
# Run only inside the disposable QEMU builder with /build mounted.
set -Eeuo pipefail
grep -Eq 'QEMU|KVM' /sys/devices/virtual/dmi/id/{sys_vendor,product_name}
mountpoint -q /build
umount --help | grep -q -- --recursive
exec > >(tee /build/installable-build.log /dev/ttyS0) 2>&1
trap 'rc=$?; echo "CGH_INSTALLABLE_BUILD_EXIT:$rc"; curl -fsS -T /build/installable-build.log http://10.0.2.2:18772/build.log || true' EXIT
export DEBIAN_FRONTEND=noninteractive
ip link set lo up
cd /build/source
git apply --check /build/changes.patch
git apply /build/changes.patch
git -c user.name='CGH Development' -c user.email='development@crawfordgroupholdings.com' add -A
git -c user.name='CGH Development' -c user.email='development@crawfordgroupholdings.com' commit -m 'Integrate CGH OS installable candidate and wallpaper fix'
bash scripts/check.sh > /build/installable-source-checks.log 2>&1
cat /build/installable-source-checks.log
BASE=/build/installable-base.iso
curl -fS http://10.0.2.2:18772/iso -o "$BASE"
echo 'badd8926984407823443bd540318849c70dd162646c829d83f5f31a91e702cf2  /build/installable-base.iso' | sha256sum -c -
mkdir -p /build/iso-extracted
xorriso -osirrox on -indev "$BASE" -extract /live/filesystem.squashfs /build/iso-extracted/filesystem.squashfs -extract /live/cgh-config.squashfs /build/iso-extracted/cgh-config.squashfs
R=/build/installable-root
test ! -e "$R"
unsquashfs -processors 2 -no-progress -d "$R" /build/iso-extracted/filesystem.squashfs
unsquashfs -processors 2 -no-progress -f -d "$R" /build/iso-extracted/cgh-config.squashfs
rm /build/iso-extracted/*.squashfs
mkdir -p "$R/proc" "$R/sys" "$R/dev" "$R/dev/pts"
mount -t proc proc "$R/proc"
mount --rbind /sys "$R/sys"; mount --make-rslave "$R/sys"
mount --rbind /dev "$R/dev"; mount --make-rslave "$R/dev"
rm -f "$R/etc/resolv.conf"
cp /etc/resolv.conf "$R/etc/resolv.conf"
printf '#!/bin/sh\nexit 101\n' > "$R/usr/sbin/policy-rc.d"
chmod 755 "$R/usr/sbin/policy-rc.d"
cat > "$R/etc/apt/sources.list" <<'APT'
deb https://deb.debian.org/debian trixie main non-free-firmware
deb https://deb.debian.org/debian trixie-updates main non-free-firmware
deb https://deb.debian.org/debian-security trixie-security main non-free-firmware
APT
chroot "$R" apt-get update
chroot "$R" apt-get install -y --no-install-recommends --reinstall calamares calamares-settings-debian
mapfile -t packages < config/package-lists/installable.list.chroot
chroot "$R" apt-get install -y --no-install-recommends "${packages[@]}"
# Small X11 test tools allow isolated installer acceptance in a virtual display.
chroot "$R" apt-get install -y --no-install-recommends xvfb xdotool
# Restore upstream installer binaries before applying CGH configuration.
test "$(chroot "$R" dpkg-query -W -f='${Status}' calamares)" = 'install ok installed'
test "$(od -An -tx1 -N4 "$R/usr/bin/calamares" | tr -d ' \n')" = 7f454c46
cp -a config/includes.chroot/. "$R/"
# These old live-preview wrappers are not install paths.
for name in install-debian debian-installer-launcher; do
    if test -f "$R/usr/bin/$name" && grep -q 'cgh-os/welcome.py' "$R/usr/bin/$name"; then rm "$R/usr/bin/$name"; fi
done
rm -f "$R/usr/share/applications/install-debian.desktop"
chmod 755 "$R/usr/local/bin/cgh-install" "$R/usr/local/bin/cgh-test-log"
chroot "$R" dconf update
chroot "$R" gtk-update-icon-cache -f -t /usr/share/icons/CGH-Ribbon
chroot "$R" visudo -c
chroot "$R" python3 -m py_compile /usr/share/cgh-os/{budget,budget_store,workspace,workspace_store}.py /usr/lib/calamares/modules/cgh-{bootprep,finalize}/main.py
# Install reproducible synthetic application checks alongside the existing tools.
cp scripts/test-icons-runtime.py "$R/usr/share/cgh-os/tests/"
mkdir -p "$R/usr/share/cgh-os/acceptance/scripts"
ln -s /usr/share/cgh-os "$R/usr/share/cgh-os/acceptance/src"
cp scripts/test-budget-ui.py scripts/test-workspace-ui.py scripts/test-installed-persistence.py scripts/runtime-user-tests.py "$R/usr/share/cgh-os/acceptance/scripts/"
chroot "$R" dpkg-query -W -f='${Package}\t${Version}\t${Architecture}\n' > /build/installable-packages.tsv
chroot "$R" update-initramfs -u -k all
chroot "$R" apt-get clean
rm -f "$R/etc/resolv.conf"
ln -s /run/NetworkManager/resolv.conf "$R/etc/resolv.conf"
rm -f "$R/usr/sbin/policy-rc.d" "$R/var/lib/systemd/random-seed"
printf '' > "$R/etc/machine-id"
rm -f "$R/etc/ssh/ssh_host_"*
find "$R/var/log" -type f -exec truncate -s 0 {} +
KERNEL=$(find "$R/boot" -maxdepth 1 -name 'vmlinuz-*' | sort -V | tail -1)
VERSION=${KERNEL##*vmlinuz-}
cp "$KERNEL" /build/cgh-installable-vmlinuz
cp "$R/boot/initrd.img-$VERSION" /build/cgh-installable-initrd.img
umount -R "$R/dev"; umount -R "$R/sys"; umount "$R/proc"
rm -rf "$R/tmp/"* "$R/var/tmp/"*
python3 - <<'PY'
import json,pathlib,hashlib,subprocess
r=pathlib.Path('/build/installable-root')
info={'version':'0.5.0 Installable Candidate','base':'Debian 13','parent_iso_sha256':'badd8926984407823443bd540318849c70dd162646c829d83f5f31a91e702cf2','build_source_commit':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'acceptance':'NOT YET INSTALLATION TESTED','installer':'Calamares with Debian settings and CGH cleanup/boot-preparation modules','files':{}}
for name in ['usr/bin/calamares','etc/calamares/settings.conf','etc/dconf/db/local.d/02-cgh-background','usr/share/cgh-os/budget.py','usr/share/cgh-os/workspace.py']:
 info['files'][name]=hashlib.sha256((r/name).read_bytes()).hexdigest()
(r/'usr/share/cgh-os/build-info.json').write_text(json.dumps(info,indent=2)+'\n')
pathlib.Path('/build/installable-build-info.json').write_text(json.dumps(info,indent=2)+'\n')
PY
mksquashfs "$R" /build/installable-filesystem.squashfs -noappend -comp zstd -Xcompression-level 3 -processors 2 -no-progress
printf 'filesystem.squashfs\n' > /build/installable-filesystem.module
OUT=/build/CGH-OS-0.5.0-Installable-Candidate-amd64.iso
xorriso -indev "$BASE" -outdev "$OUT" -boot_image any replay -volid CGH_OS_050 \
    -map /build/installable-filesystem.squashfs /live/filesystem.squashfs \
    -rm /live/cgh-config.squashfs -- \
    -map /build/installable-filesystem.module /live/filesystem.module \
    -map /build/cgh-installable-vmlinuz /live/vmlinuz \
    -map /build/cgh-installable-initrd.img /live/initrd.img \
    -map preview/grub/grub.cfg /boot/grub/grub.cfg \
    -map preview/isolinux/live.cfg /isolinux/live.cfg \
    -map preview/isolinux/menu.cfg /isolinux/menu.cfg -commit -end
cd /build
sha256sum "$(basename "$OUT")" > "$OUT.sha256"
xorriso -indev "$OUT" -report_el_torito plain > /build/installable-boot-records.txt 2>&1
tar czf /build/build-evidence.tar.gz installable-source-checks.log installable-packages.tsv installable-build-info.json installable-boot-records.txt
for file in "$OUT" "$OUT.sha256" /build/build-evidence.tar.gz; do curl -fS -T "$file" "http://10.0.2.2:18772/$(basename "$file")"; done
echo CGH_INSTALLABLE_BUILD_COMPLETE
