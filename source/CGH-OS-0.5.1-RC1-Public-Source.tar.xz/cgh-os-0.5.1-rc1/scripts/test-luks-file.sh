#!/bin/bash
# Tests a temporary regular-file container, never a physical disk.
set -euo pipefail
[[ $EUID == 0 ]] || exit 1
case "$(cat /sys/class/dmi/id/product_name)" in *QEMU*|*KVM*|*'Standard PC'*) ;; *) echo 'Refusing outside disposable VM'; exit 1;; esac
work=$(mktemp -d)
map="cgh-luks-test-$$"
cleanup(){ cryptsetup close "$map" >/dev/null 2>&1 || true; rm -rf -- "$work"; }
trap cleanup EXIT
head -c 48 /dev/urandom > "$work/key"
chmod 600 "$work/key"
truncate -s 64M "$work/container"
cryptsetup luksFormat --batch-mode --type luks2 --pbkdf argon2id --pbkdf-memory 65536 --pbkdf-parallel 1 --iter-time 1000 "$work/container" "$work/key"
cryptsetup open --key-file "$work/key" "$work/container" "$map"
printf 'CGH encrypted container fixture\n' > "$work/fixture"
dd if="$work/fixture" of="/dev/mapper/$map" status=none
cryptsetup close "$map"
cryptsetup open --key-file "$work/key" "$work/container" "$map"
cmp -n "$(stat -c %s "$work/fixture")" "$work/fixture" "/dev/mapper/$map"
echo CGH_LUKS_REGULAR_FILE_ROUNDTRIP_PASS
