#!/usr/bin/python3
"""Exercise real GTK widgets/dialogs with synthetic finance data; no banking services."""
import sys,tempfile,time,json,resource,os
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'src'))
import gi
gi.require_version('Gtk','3.0'); gi.require_version('Gdk','3.0')
from gi.repository import Gtk,GLib,Gdk
from budget import Budget
from budget_store import Store
out=Path(sys.argv[1]); out.mkdir(parents=True,exist_ok=True)
checks=[]
def pump():
 while Gtk.events_pending(): Gtk.main_iteration_do(False)
def form(app,action,values):
 def accept():
  for d in Gtk.Window.list_toplevels():
   if isinstance(d,Gtk.Dialog) and d.get_visible():
    grid=d.get_content_area().get_children()[0]
    widgets=sorted([w for w in grid.get_children() if isinstance(w,(Gtk.Entry,Gtk.ComboBoxText))],key=lambda w:grid.child_get_property(w,'top-attach'))
    assert len(widgets)==len(values)
    for w,value in zip(widgets,values):
     if isinstance(w,Gtk.ComboBoxText):w.set_active_id(str(value))
     else:w.set_text(str(value))
    d.response(Gtk.ResponseType.OK); return False
  return True
 timer=GLib.timeout_add(50,accept); action(); pump()
with tempfile.TemporaryDirectory() as td:
 root=Path(td); app=Budget(root/'db'); app.register(None); app.activate(); pump()
 form(app,app.setup,['Test Household','USD']); checks.append('create budget through GTK dialog')
 form(app,app.account,['Checking','1000']); form(app,app.account,['Savings','0']); form(app,app.category,['Groceries'])
 app.period.set_text('2026-10'); form(app,app.plan,['2026-10','3000','1','400']); checks.append('accounts, category and monthly plan')
 form(app,app.transaction,['2026-10-01','income','1','3000','','','Paycheck'])
 form(app,app.transaction,['2026-10-05','expense','1','125.50','1','','Weekly groceries'])
 form(app,app.transaction,['2026-10-06','transfer','1','200','','2','Savings transfer']); checks.append('income expense and transfer dialogs')
 form(app,app.bill,['Electricity','2026-11-03','85']); checks.append('bill dialog')
 assert app.store.summary('2026-10')['spending']==12550
 assert app.store.summary('2026-10')['income']==300000
 app.query.set_text('groceries'); app.refresh(); assert len(app.views['Transactions'][0])==1
 app.views['Transactions'][1].get_selection().select_path(0)
 form(app,lambda:app.transaction(True),['2026-10-05','expense','1','120','1','','Corrected groceries']); checks.append('search and correction')
 app.query.set_text(''); app.refresh()
 app.tabs.set_current_page(1); pump()
 # Capture the actual GTK window, not a mockup.
 time.sleep(.3); pump()
 window=app.window.get_window(); pix=Gdk.pixbuf_get_from_window(window,0,0,app.window.get_allocated_width(),app.window.get_allocated_height()); pix.savev(str(out/'budget-categories.png'),'png',[],[])
 app.tabs.set_current_page(0); pump(); pix=Gdk.pixbuf_get_from_window(window,0,0,app.window.get_allocated_width(),app.window.get_allocated_height()); pix.savev(str(out/'budget-transactions.png'),'png',[],[])
 # Drive the actual GTK save chooser once, then use deterministic paths for workflow tests.
 def accept_chooser():
  for d in Gtk.Window.list_toplevels():
   if isinstance(d,Gtk.FileChooserDialog) and d.get_visible():
    d.set_current_folder(str(root)); d.set_current_name('chooser-test.json')
    GLib.timeout_add(150,lambda:(d.response(Gtk.ResponseType.OK),False)[1]); return False
  return True
 GLib.timeout_add(50,accept_chooser)
 assert app.choose('Test save chooser')==str(root/'chooser-test.json')
 checks.append('real GTK save chooser')
 # Actual preview dialog, deterministic file path selection.
 def preview():
  for d in Gtk.Window.list_toplevels():
   if isinstance(d,Gtk.Dialog) and d.get_visible(): d.response(Gtk.ResponseType.OK); return False
  return True
 app.choose=lambda *a,**k:str(root/'export.json'); GLib.timeout_add(50,preview); app.export()
 assert json.loads((root/'export.json').read_text())['entries']; checks.append('actual export preview and save')
 app.choose=lambda *a,**k:str(root/'backup'); app.backup()
 paths=iter([str(root/'backup'),str(root/'restored')]); app.choose=lambda *a,**k:next(paths)
 GLib.timeout_add(50,preview); app.restore(); assert app.store.path==root/'restored'; checks.append('backup restore and open restored file')
 app.views['Bills'][1].get_selection().select_path(0); app.toggle_bill(); assert app.store.rows('SELECT paid FROM bills')[0]['paid']==1; checks.append('mark bill paid without financial double counting')
 app.store.close(); app.store=Store(root/'restored'); app.refresh(); assert app.store.summary('2026-10')['spending']==12000; checks.append('reopen data store and restore view')
 # Monotonic idle interval with main loop active.
 cpu=time.process_time(); wall=time.monotonic(); loop=GLib.MainLoop(); GLib.timeout_add(2000,lambda:(loop.quit(),False)[1]); loop.run()
 result={'checks':checks,'count':len(checks),'idle_wall_seconds':time.monotonic()-wall,'idle_cpu_seconds':time.process_time()-cpu,'peak_rss_kib':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,'rss_kib':int(next(l.split()[1] for l in Path('/proc/self/status').read_text().splitlines() if l.startswith('VmRSS:'))),'environment':os.environ.get('CGH_TEST_ENVIRONMENT','Host GTK3 on Xvfb; no GNOME/QEMU or physical hardware acceptance')}
 app.window.destroy(); pump(); (out/'ui-results.json').write_text(json.dumps(result,indent=2)+'\n'); print(json.dumps(result))
