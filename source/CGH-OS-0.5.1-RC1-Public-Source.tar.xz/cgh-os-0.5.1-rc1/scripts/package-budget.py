#!/usr/bin/env python3
"""Build a rootless, dependency-declared Debian package without network access."""
from pathlib import Path
import os
import shutil
import subprocess
import tempfile

repo = Path(__file__).resolve().parents[1]
out = repo / 'artifacts'
out.mkdir(exist_ok=True)
with tempfile.TemporaryDirectory() as temp:
    root = Path(temp)
    def put(source, destination, mode=0o644):
        target = root / destination
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(source, target)
        target.chmod(mode)
    for name in ('budget.py', 'budget_store.py'):
        put(repo/'src'/name, 'usr/share/cgh-os/'+name)
    for directory, name in [('applications','com.crawfordgroupholdings.CGHBudget.desktop'), ('icons/hicolor/scalable/apps','com.crawfordgroupholdings.CGHBudget.svg')]:
        put(repo/'config/includes.chroot/usr/share'/directory/name, 'usr/share/'+directory+'/'+name)
    put(repo/'LICENSE', 'usr/share/doc/cgh-budget/copyright')
    control = root/'DEBIAN'
    control.mkdir()
    (control/'control').write_text('''Package: cgh-budget
Version: 0.4.0~milestone2
Architecture: all
Maintainer: Crawford Group Holdings <development@localhost>
Depends: python3, python3-gi, gir1.2-gtk-3.0
Section: utils
Priority: optional
Description: CGH private personal budgeting
 Manual accounts, budgets, transactions, exports and tested backups.
''')
    # Stable contents, mtimes and ownership make repeated builds byte-identical.
    for path in sorted(root.rglob('*'), reverse=True):
        os.utime(path, (1793232000,1793232000))
    env = dict(os.environ, SOURCE_DATE_EPOCH='1793232000')
    subprocess.run(['dpkg-deb','--root-owner-group','--build',str(root),str(out/'cgh-budget_0.4.0~milestone2_all.deb')], check=True, env=env)
