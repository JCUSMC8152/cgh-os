#!/usr/bin/python3
"""GTK test bench. Requires GTK3 and a display; uses temporary data, no network requests."""
import json
import os
from pathlib import Path
import resource
import sys
import tempfile
import time
from unittest.mock import patch
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'src'))
import gi
gi.require_version('Gtk','3.0')
from gi.repository import Gtk, Gio, GLib, Gdk
import workspace

out=Path(os.environ.get('CGH_TEST_OUTPUT','test-results/milestone-01')).resolve()
out.mkdir(parents=True,exist_ok=True)
temp=tempfile.TemporaryDirectory()
root=Path(temp.name)
os.environ['XDG_DATA_HOME']=str(root/'data')
folder=root/'Example project';folder.mkdir()
(folder/'hello.py').write_text('print("One System")\n')
export_path=root/'portable.json'
results={'scale':os.environ.get('GDK_SCALE','1'),'host':os.environ.get('CGH_TEST_ENVIRONMENT','Ubuntu cloud container, Xvfb; not CGH OS guest or physical hardware'),'checks':[]}
real_run=Gtk.Application.run

def pump():
    while Gtk.events_pending():Gtk.main_iteration_do(False)

def dialog_run(dialog):
    title=dialog.get_title()
    if title=='Name project':
        dialog.get_content_area().get_children()[0].set_text('Learning Python')
    if title.startswith('Review export'):
        results['checks'].append('Export preview constructed')
    return Gtk.ResponseType.OK

def chooser_filename(dialog):
    return str(folder if dialog.get_action()==Gtk.FileChooserAction.SELECT_FOLDER else export_path)

def exercise(app):
    try:
        pump()
        active_cpu_start=time.process_time()
        active_wall_start=time.monotonic()
        with patch.object(Gtk.Dialog,'run',dialog_run), patch.object(Gtk.FileChooserDialog,'get_filename',chooser_filename):
            app.new_project()
            assert app.current[1]=='Learning Python'
            app.notes.get_buffer().set_text('Build an offline Python example.\nProject files stay in their existing folder.\nExport metadata before leaving a live session.')
            app.activate_action('save',None)
            assert not app.dirty
            app.task_entry.set_text('Run hello.py in the terminal');app.task_entry.emit('activate')
            app.task_entry.set_text('Read the local developer guide');app.task_entry.emit('activate')
            app.task_box.get_children()[0].set_active(True)
            assert app.store.tasks(app.current[0])[0][2]==1
            app.search.set_text('Python');app.refresh()
            assert len(app.rows.get_children())==1
            app.search.set_text('no match');app.refresh()
            assert not app.rows.get_children()
            app.search.set_text('');app.refresh()
            app.rows.select_row(app.rows.get_row_at_index(0))
            with patch.object(Gio.AppInfo,'launch_default_for_uri') as launch:
                app.open_folder();assert launch.call_args[0][0]==folder.as_uri()
            app.export()
            assert json.loads(export_path.read_text())['projects'][0]['tasks'][0]['done'] is True
        app.store.db.execute('PRAGMA query_only=ON')
        app.notes.get_buffer().insert_at_cursor('\nUnsaved failure check')
        with patch.object(app,'error') as error:
            assert app.close_window() is True
            assert error.called
        app.store.db.execute('PRAGMA query_only=OFF')
        app.save()
        results['checks'].append('Save failure keeps window open; retry succeeds')
        pump()
        win=app.window.get_window()
        pix=Gdk.pixbuf_get_from_window(win,0,0,win.get_width(),win.get_height())
        pix.savev(str(out/('workspace-'+results['scale']+'x.png')),'png',[],[])
        results['checks'] += ['New project dialog and folder link','Ctrl+S action saves notes','Enter adds tasks and checkbox saves completion','Search and empty result','GIO folder launch routing (intercepted)','Preview and file export']
        results['active_workflow_cpu_seconds']=round(time.process_time()-active_cpu_start,5)
        results['active_workflow_wall_seconds']=round(time.monotonic()-active_wall_start,5)
        results['rss_kib']=int(next(line.split()[1] for line in Path('/proc/self/status').read_text().splitlines() if line.startswith('VmRSS:')))
        # Settled idle CPU over a two-second GLib interval.
        start=time.process_time()
        def finish():
            results['idle_cpu_seconds_over_2s']=round(time.process_time()-start,5)
            results['peak_rss_kib']=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss
            results['checks'].append('Clean close saves and closes database')
            assert app.close_window() is False
            app.quit()
            return False
        GLib.timeout_add(2000,finish)
    except Exception as error:
        results['error']=repr(error)
        app.quit()
    return False

def run(app,argv):
    GLib.timeout_add(500,exercise,app)
    return real_run(app,argv)

with patch.object(Gtk.Application,'run',run):
    workspace.main()
# Reopen storage after GTK application shutdown.
from workspace_store import Store
with_store=Store()
assert with_store.projects()[0][1]=='Learning Python'
assert 'offline' in with_store.projects()[0][3]
with_store.close()
results['checks'].append('Reopen after application shutdown')
(out/('ui-'+results['scale']+'x.json')).write_text(json.dumps(results,indent=2)+'\n')
print(json.dumps(results,indent=2))
temp.cleanup()
if 'error' in results:raise SystemExit(1)
