#!/bin/bash
set -euo pipefail
cd "$(dirname "$0")/.."
python3 -m py_compile src/*.py src/cgh-pack scripts/*.py
for file in scripts/*.sh config/includes.chroot/usr/local/sbin/cgh-live-credentials; do bash -n "$file"; done
sh -n auto/config
for file in config/hooks/normal/*.chroot; do sh -n "$file"; done
python3 src/cgh-pack plan developer
python3 src/cgh-pack plan homelab
python3 -m unittest discover -s tests -v
