#!/usr/bin/env python3
import subprocess,pathlib,tempfile,json,sys
results=[]
def run(name,args,input=None,expect=0,timeout=180):
 try:
  p=subprocess.run(args,input=input,capture_output=True,text=True,timeout=timeout)
  results.append({'check':name,'passed':p.returncode==expect,'returncode':p.returncode})
  return p
 except (OSError,subprocess.TimeoutExpired):
  results.append({'check':name,'passed':False,'reason':'unavailable or timeout'});return None
with tempfile.TemporaryDirectory(prefix='cgh-everyday-test-') as d:
 r=pathlib.Path(d);text='CGH OS document round trip fixture 746291'
 (r/'fixture.txt').write_text(text+'\n')
 run('office_create_odt',['libreoffice','-env:UserInstallation=file://'+str(r/'office-profile'),'--headless','--convert-to','odt','--outdir',str(r),str(r/'fixture.txt')])
 run('office_export_pdf',['libreoffice','-env:UserInstallation=file://'+str(r/'office-profile'),'--headless','--convert-to','pdf','--outdir',str(r),str(r/'fixture.odt')])
 p=run('pdf_text_extract',['pdftotext',str(r/'fixture.pdf'),'-'])
 results.append({'check':'document_text_round_trip','passed':p is not None and text in p.stdout})
 # Standard harmless antivirus test string, sent only to the local scanner.
 eicar='X5O!P%@AP[4\\PZX54(P^)7CC)7}$EICAR-STANDARD-ANTIVIRUS-TEST-FILE!$H+H*'
 assert len(eicar.encode('ascii'))==68, 'Invalid antivirus fixture'
 run('antivirus_test_signature',['clamscan','--no-summary','-'],input=eicar,expect=1,timeout=300)
 run('antivirus_clean_fixture',['clamscan','--no-summary',str(r/'fixture.txt')],timeout=300)
 pw='CGH disposable vault fixture 746291'
 run('password_vault_create',['keepassxc-cli','db-create','-p',str(r/'test.kdbx')],input=pw+'\n'+pw+'\n')
 run('password_vault_open',['keepassxc-cli','ls',str(r/'test.kdbx')],input=pw+'\n')
run('encrypted_backup_and_restore',['bash','/usr/share/cgh-os/tests/test-restic.sh'])
print(json.dumps({'scope':'local disposable fixtures','results':results},indent=2))
sys.exit(0 if all(x['passed'] for x in results) else 1)
