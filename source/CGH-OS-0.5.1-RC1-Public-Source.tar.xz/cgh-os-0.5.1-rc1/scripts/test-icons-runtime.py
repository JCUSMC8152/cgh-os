import gi,json,pathlib,sys,subprocess,time
sys.path.insert(0,'/usr/share/cgh-os')
gi.require_version('Gtk','3.0')
from gi.repository import Gtk,Gio
ok,_=Gtk.init_check();assert ok,'GTK display unavailable'
settings=Gtk.Settings.get_default();theme=Gtk.IconTheme.get_default()
assert settings.get_property('gtk-icon-theme-name')=='CGH-Ribbon'
results={'theme':settings.get_property('gtk-icon-theme-name'),'icons':{},'desktop_entries':{}}
map=json.loads(pathlib.Path('/usr/share/cgh-os/icon-map.json').read_text())
for name,aliases in map.items():
 for alias in ['cgh-'+name]+aliases:
  for size in [24,32,48,128]:
   info=theme.lookup_icon(alias,size,0);assert info is not None,alias
   assert '/CGH-Ribbon/' in info.get_filename(),(alias,info.get_filename())
   assert info.load_icon().get_width()>0
  results['icons'][alias]='resolved and loaded at 24/32/48/128'
for app in ['cgh-control-center.desktop','firefox-esr.desktop','org.gnome.Nautilus.desktop','libreoffice-writer.desktop','org.gnome.Software.desktop']:
 entry=Gio.DesktopAppInfo.new(app);assert entry,app
 icon=entry.get_icon();info=theme.lookup_by_gicon(icon,48,0);assert info and '/CGH-Ribbon/' in info.get_filename(),(app,str(icon))
 results['desktop_entries'][app]=info.get_filename()
from control_center import Center
w=Center();w.show_all()
while Gtk.events_pending():Gtk.main_iteration_do(False)
assert w.get_icon_name()=='cgh-control-center'
assert {'CGH Budget', 'CGH Workspace'} <= set(w.tool_tiles)
assert len(w.tool_tiles)==36
assert len({tile.icon_name for tile in w.tool_tiles.values()})==36
results['tool_tiles']=36
results['unique_tool_icons']=36
results['control_center']='constructed and rendered without missing icon errors'
pathlib.Path('/tmp/cgh-icon-results.json').write_text(json.dumps(results,indent=2))
print('CGH_ICON_PROBE_PASS',len(results['icons']),'icon names, 4 sizes, 5 desktop entries',flush=True)
w.destroy()
