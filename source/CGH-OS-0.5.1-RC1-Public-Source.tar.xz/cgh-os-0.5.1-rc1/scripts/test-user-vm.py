#!/usr/bin/env python3
import libvirt,tempfile,pathlib,subprocess,json,time
c=libvirt.open('qemu:///session');d=None;results=[]
with tempfile.TemporaryDirectory(prefix='cgh-vm-test-') as td:
 p=pathlib.Path(td)/'fixture.qcow2';subprocess.run(['qemu-img','create','-f','qcow2',str(p),'128M'],check=True,stdout=subprocess.DEVNULL)
 xml=f'''<domain type="qemu"><name>cgh-disposable-acceptance</name><memory unit="KiB">131072</memory><vcpu>1</vcpu><os><type arch="x86_64">hvm</type></os><devices><emulator>/usr/bin/qemu-system-x86_64</emulator><disk type="file" device="disk"><driver name="qemu" type="qcow2"/><source file="{p}"/><target dev="vda" bus="virtio"/></disk></devices></domain>'''
 try:
  d=c.createXML(xml,0);results.append({'check':'isolated_user_vm_running','passed':d.isActive()==1})
  d.snapshotCreateXML('<domainsnapshot><name>cgh-fixture-snapshot</name></domainsnapshot>',0)
  results.append({'check':'vm_snapshot_created','passed':'cgh-fixture-snapshot' in d.snapshotListNames()})
  d.destroy();d=None;results.append({'check':'vm_deleted','passed':'cgh-disposable-acceptance' not in [x.name() for x in c.listAllDomains()]})
 finally:
  if d is not None and d.isActive():d.destroy()
c.close();print(json.dumps({'scope':'128 MiB transient VM without a guest OS or network; software emulation','results':results},indent=2))
