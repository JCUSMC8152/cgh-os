#!/bin/bash
set -euo pipefail
cd "$(dirname "$0")/.."
[[ $EUID == 0 ]] || { echo 'Build requires root in a disposable Debian 13 VM.' >&2; exit 1; }
. /etc/os-release
[[ "$ID" == debian && "$VERSION_ID" == 13 ]] || { echo 'Use a disposable Debian 13 build VM.' >&2; exit 1; }
command -v lb >/dev/null
mkdir -p artifacts
lb config
lb build 2>&1 | tee artifacts/build.log
cp live-image-amd64.hybrid.iso artifacts/CGH-OS-0.5.0-Installable-Candidate-amd64.iso
dpkg-query -W live-build debootstrap > artifacts/build-tools.txt
cp live-image-amd64.packages artifacts/packages.txt
(cd artifacts; sha256sum *.iso > SHA256SUMS)
echo 'Unsigned development artifact. Boot/install/security verification required.'
