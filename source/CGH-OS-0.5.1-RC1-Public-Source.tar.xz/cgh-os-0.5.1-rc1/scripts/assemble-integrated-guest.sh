#!/bin/bash
# Disposable Debian build guest only; never run on the owner's laptop.
set -Eeuo pipefail
trap 'rc=$?; echo "CGH_BUILD_FAILED:$rc line:$LINENO"; exit "$rc"' ERR
case "$(systemd-detect-virt 2>/dev/null || true)" in
 qemu|kvm|microsoft|oracle|vmware) ;;
 *) echo 'Refusing to modify a non-VM build host.' >&2; exit 1 ;;
esac
export DEBIAN_FRONTEND=noninteractive
mkdir -p /out
mount -t 9p -o trans=virtio,version=9p2000.L cghoutput /out
exec > >(tee /out/integrated-build.log /dev/ttyS0) 2>&1
echo CGH_INTEGRATED_BUILD_START
apt-get update
apt-get install -y --no-install-recommends squashfs-tools xorriso python3-yaml ca-certificates
mkdir -p /mnt/base
mount -o ro /dev/sr1 /mnt/base
if [[ ! -f /root/cgh-root/etc/debian_version ]]; then
 unsquashfs -processors 2 -no-progress -d /root/cgh-root /mnt/base/live/filesystem.squashfs
fi
R=/root/cgh-root
install -d "$R/proc" "$R/sys" "$R/dev" "$R/dev/pts"
mount -t proc proc "$R/proc"
mount --rbind /sys "$R/sys"; mount --make-rslave "$R/sys"
mount --rbind /dev "$R/dev"; mount --make-rslave "$R/dev"
if [[ -f /etc/apt/apt.conf.d/99build-proxy ]]; then
 cp /etc/apt/apt.conf.d/99build-proxy "$R/etc/apt/apt.conf.d/99build-proxy"
 cp /usr/local/share/ca-certificates/cgh-build-proxy.crt "$R/usr/local/share/ca-certificates/cgh-build-proxy.crt"
fi
printf '#!/bin/sh\nexit 101\n' > "$R/usr/sbin/policy-rc.d"; chmod 755 "$R/usr/sbin/policy-rc.d"
# Replace live-medium package sources with signed stable network repositories.
rm -f "$R/etc/apt/sources.list.d/"*.list "$R/etc/apt/sources.list.d/"*.sources
cat > "$R/etc/apt/sources.list" <<'APT'
deb https://deb.debian.org/debian trixie main non-free-firmware
deb https://deb.debian.org/debian trixie-updates main non-free-firmware
deb https://deb.debian.org/debian-security trixie-security main non-free-firmware
APT
chroot "$R" update-ca-certificates
chroot "$R" apt-get update
chroot "$R" apt-get -y full-upgrade
mapfile -t packages < /root/work/cgh-os/config/package-lists/integrated.list.chroot
chroot "$R" apt-get install -y --no-install-recommends "${packages[@]}" gnome-terminal python3-gi gir1.2-gtk-3.0
cp -a /root/work/cgh-os/config/includes.chroot/. "$R/"
install -d "$R/usr/share/cgh-os/tests"
cp /root/work/cgh-os/scripts/test-icons-runtime.py /root/work/cgh-os/scripts/runtime-user-tests.py /root/work/cgh-os/scripts/test-apparmor.py /root/work/cgh-os/scripts/test-firewall.py /root/work/cgh-os/scripts/test-luks-file.sh /root/work/cgh-os/scripts/test-restic.sh /root/work/cgh-os/scripts/test-everyday-cli.py /root/work/cgh-os/scripts/test-user-vm.py "$R/usr/share/cgh-os/tests/"
cp /root/work/cgh-os/LICENSE "$R/usr/share/cgh-os/LICENSE"
# Rebuild config after overlay files are present.
for hook in /root/work/cgh-os/config/hooks/normal/*.hook.chroot; do
 cp "$hook" "$R/tmp/cgh-build-hook"; chroot "$R" /bin/sh /tmp/cgh-build-hook
done
# Disable installer applications in this live-only acceptance candidate.
for exe in calamares install-debian debian-installer-launcher; do
 if [[ -f "$R/usr/bin/$exe" ]]; then
  printf '#!/bin/sh\nexec python3 /usr/share/cgh-os/welcome.py\n' > "$R/usr/bin/$exe"; chmod 755 "$R/usr/bin/$exe"
 fi
done
# Runtime sudo component is disabled in both boot menus. Reject inherited bypasses.
if grep -R -n -E '^[^#].*NOPASSWD' "$R/etc/sudoers" "$R/etc/sudoers.d"; then
 echo 'Unexpected passwordless sudo policy; refusing candidate.'; exit 1
fi
# Installed base contains no live-session account; runtime creates it.
chroot "$R" visudo -c
chroot "$R" python3 -m venv /tmp/cgh-test-venv
chroot "$R" /tmp/cgh-test-venv/bin/python -c 'print("CGH_VENV_PASS")'
chroot "$R" node -e 'if (2+2!==4) process.exit(1); console.log("CGH_NODE_PASS")'
printf '#include <stdio.h>\nint main(){puts("CGH_C_PASS");return 0;}\n' > "$R/tmp/cgh-test.c"
chroot "$R" gcc /tmp/cgh-test.c -o /tmp/cgh-test
chroot "$R" /tmp/cgh-test
cp /root/work/cgh-os/scripts/test-restic.sh "$R/tmp/cgh-restic-test"
chroot "$R" bash /tmp/cgh-restic-test
chroot "$R" dpkg-query -W -f='${Package}\t${Version}\t${Architecture}\n' > /out/installed-packages.tsv
chroot "$R" dpkg-query -W -f='${Package}\t${Version}\n' > /root/cgh-packages.txt
chroot "$R" python3 -c 'import gi;gi.require_version("Gtk","3.0");from gi.repository import Gtk;print("CGH_GTK_IMPORT_PASS")'
# Remove all build-only transport trust and configuration before producing an image.
rm -f "$R/etc/apt/apt.conf.d/99build-proxy" "$R/usr/local/share/ca-certificates/cgh-build-proxy.crt"
chroot "$R" update-ca-certificates --fresh
rm -f "$R/usr/sbin/policy-rc.d" "$R/tmp/cgh-build-hook" "$R/tmp/cgh-test.c" "$R/tmp/cgh-test" "$R/tmp/cgh-restic-test"
rm -rf "$R/tmp/cgh-test-venv"
chroot "$R" apt-get clean
rm -f "$R/etc/ssh/ssh_host_"* "$R/var/lib/systemd/random-seed"
printf '' > "$R/etc/machine-id"
# Final initramfs includes security/config changes, not temporary proxy trust.
chroot "$R" update-initramfs -u -k all
kernel=$(find "$R/boot" -maxdepth 1 -name 'vmlinuz-*' | sort -V | tail -1)
version=${kernel##*vmlinuz-}
cp "$kernel" /root/cgh-vmlinuz
cp "$R/boot/initrd.img-$version" /root/cgh-initrd.img
umount -R "$R/dev"; umount -R "$R/sys"; umount "$R/proc"
rm -rf "$R/tmp/"* "$R/var/tmp/"*
find "$R/var/log" -type f -exec truncate -s 0 {} +
echo CGH_ROOT_CONFIGURED
mksquashfs "$R" /root/cgh-filesystem.squashfs -noappend -comp zstd -Xcompression-level 6 -processors 2 -no-progress
cp /root/work/cgh-os/preview/grub/grub.cfg /root/cgh-grub.cfg
cp /root/work/cgh-os/preview/isolinux/live.cfg /root/cgh-live.cfg
sed -i 's/0.1.0/0.2.0/g;s/Live Preview/Integrated Test/g' /root/cgh-grub.cfg /root/cgh-live.cfg
printf 'filesystem.squashfs\n' > /root/cgh-filesystem.module
printf 'CGH OS 0.2.0 integrated test candidate; not a public release\n' > /root/cgh-info
umount /mnt/base
xorriso -indev /dev/sr1 -outdev /out/CGH-OS-0.2.0-Integrated-Test-amd64.iso \
 -boot_image any replay -volid CGH_OS_TEST \
 -map /root/cgh-filesystem.squashfs /live/filesystem.squashfs \
 -map /root/cgh-filesystem.module /live/filesystem.module \
 -map /root/cgh-packages.txt /live/filesystem.packages \
 -map /root/cgh-vmlinuz /live/vmlinuz -map /root/cgh-initrd.img /live/initrd.img \
 -map /root/cgh-grub.cfg /boot/grub/grub.cfg \
 -map /root/cgh-live.cfg /isolinux/live.cfg \
 -map /root/work/cgh-os/preview/isolinux/menu.cfg /isolinux/menu.cfg \
 -map /root/work/cgh-os/preview/isolinux/isolinux.cfg /isolinux/isolinux.cfg \
 -map /root/cgh-info /.disk/info -rm /md5sum.txt -- -commit -end
(cd /out; sha256sum CGH-OS-0.2.0-Integrated-Test-amd64.iso > SHA256SUMS)
echo CGH_INTEGRATED_BUILD_COMPLETE
