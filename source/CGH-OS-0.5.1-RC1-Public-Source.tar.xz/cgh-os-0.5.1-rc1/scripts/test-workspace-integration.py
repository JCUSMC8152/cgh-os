#!/usr/bin/python3
"""Check the actual Control Center Workspace route and icon in a GTK test display."""
import json
import sys
from pathlib import Path
from unittest.mock import patch
repo=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(repo/'src'))
import gi
gi.require_version('Gtk','3.0')
from gi.repository import Gtk, Gio
import control_center
icons=Gtk.IconTheme.get_default()
icons.append_search_path(str(repo/'config/includes.chroot/usr/share/icons'))
Gtk.Settings.get_default().set_property('gtk-icon-theme-name','CGH-Ribbon')
center=control_center.Center()
tile=center.tool_tiles['CGH Workspace']
assert tile.get_accessible().get_name()=='CGH Workspace'
assert tile.icon_name=='cgh-workspace'
assert icons.load_icon(tile.icon_name,64,0).get_width()==64
with patch.object(control_center.subprocess,'Popen') as launch:
    tile.emit('clicked')
    assert launch.call_args[0][0]==['/usr/bin/python3','/usr/share/cgh-os/workspace.py']
entry=Gio.DesktopAppInfo.new_from_filename(str(repo/'config/includes.chroot/usr/share/applications/com.crawfordgroupholdings.CGHWorkspace.desktop'))
assert entry.get_name()=='CGH Workspace'
assert entry.get_commandline()=='/usr/bin/python3 /usr/share/cgh-os/workspace.py'
assert 'projects' in entry.get_keywords()
(repo/'test-results/milestone-01/desktop-integration.json').write_text(json.dumps({'control_center_construction':'pass','workspace_tile_launch':'pass; subprocess intercepted','distinct_icon_load':'pass','desktop_entry_metadata':'pass; real GNOME Shell launch pending'},indent=2)+'\n')
print('Control Center construction, accessible Workspace tile, launch route, icon and desktop metadata: pass')
center.destroy()
