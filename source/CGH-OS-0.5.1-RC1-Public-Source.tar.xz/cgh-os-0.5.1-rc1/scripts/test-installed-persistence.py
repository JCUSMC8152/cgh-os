#!/usr/bin/python3
"""Create synthetic records, then verify them after an actual installed-system reboot."""
import argparse
import json
import os
from pathlib import Path
import subprocess
import sys

sys.path.insert(0, '/usr/share/cgh-os')
from budget_store import Store as BudgetStore
from workspace_store import Store as WorkspaceStore

p = argparse.ArgumentParser()
p.add_argument('mode', choices=['create', 'verify'])
p.add_argument('fixture', type=Path)
a = p.parse_args()
if os.geteuid() == 0:
    raise SystemExit('Run as the installed desktop user, without sudo.')
fstype = subprocess.check_output(['findmnt', '-n', '-o', 'FSTYPE', '/'], text=True).strip()
if fstype in ('overlay', 'tmpfs', 'squashfs'):
    raise SystemExit('This test requires an installed root filesystem.')
boot_id = Path('/proc/sys/kernel/random/boot_id').read_text().strip()
machine_id = Path('/etc/machine-id').read_text().strip()
if a.mode == 'create':
    a.fixture.mkdir(mode=0o700)  # Refuse existing fixtures; never replace user data.
    b = BudgetStore(a.fixture / 'budget.sqlite3')
    b.setup('Synthetic reboot test', 'USD')
    account = b.account('Checking', '1000')
    savings = b.account('Savings', '0')
    category = b.category('Test expenses')
    b.entry('2026-10-29', 'income', account, '2000', memo='Synthetic income')
    b.entry('2026-10-29', 'expense', account, '125', category=category, memo='Synthetic expense')
    b.entry('2026-10-29', 'transfer', account, '200', target=savings, memo='Synthetic transfer')
    expected_budget = b.export()
    b.close()
    folder = a.fixture / 'Project'
    folder.mkdir()
    (folder / 'sample.txt').write_text('CGH OS installed data survives reboot.\n')
    w = WorkspaceStore(a.fixture / 'workspace.sqlite3')
    project = w.create('Synthetic reboot project', str(folder))
    w.save_notes(project, 'Verify the same project after reboot.')
    task = w.add_task(project, 'Read saved file')
    w.set_done(task, True)
    expected_workspace = w.export()
    w.close()
    expected = {'first_boot_id': boot_id, 'machine_id': machine_id,
                'budget': expected_budget, 'workspace': expected_workspace}
    target = a.fixture / 'expected.json'
    fd = os.open(target, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
    with os.fdopen(fd, 'w') as f:
        json.dump(expected, f, indent=2)
    print(json.dumps({'phase': 'create', 'status': 'pass', 'fixture': str(a.fixture), 'root_filesystem': fstype}))
else:
    expected = json.loads((a.fixture / 'expected.json').read_text())
    assert expected['first_boot_id'] != boot_id, 'No actual reboot detected'
    assert machine_id and expected['machine_id'] == machine_id, 'Installed identity changed'
    b = BudgetStore(a.fixture / 'budget.sqlite3')
    assert b.export() == expected['budget'], 'Budget data changed or was lost'
    assert b.summary('2026-10')['spending'] == 12500
    assert {x['name']: x['balance'] for x in b.balances()} == {'Checking': 267500, 'Savings': 20000}
    b.close()
    w = WorkspaceStore(a.fixture / 'workspace.sqlite3')
    assert w.export() == expected['workspace'], 'Workspace data changed or was lost'
    w.close()
    assert (a.fixture / 'Project/sample.txt').read_text() == 'CGH OS installed data survives reboot.\n'
    assert (a.fixture / 'budget.sqlite3').stat().st_mode & 0o777 == 0o600
    assert (a.fixture / 'workspace.sqlite3').stat().st_mode & 0o777 == 0o600
    print(json.dumps({'phase': 'verify', 'status': 'pass', 'actual_reboot': True,
                      'budget': 'preserved', 'workspace': 'preserved', 'file': 'preserved',
                      'private_database_modes': '0600', 'root_filesystem': fstype}))
