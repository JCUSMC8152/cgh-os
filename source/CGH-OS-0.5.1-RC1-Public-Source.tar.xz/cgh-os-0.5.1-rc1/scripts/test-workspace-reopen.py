#!/usr/bin/python3
"""Verify that a new application process restores an existing project's UI."""
import os,sys,json,tempfile
from pathlib import Path
from unittest.mock import patch
repo=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(repo/'src'))
import gi
gi.require_version('Gtk','3.0')
from gi.repository import Gtk,GLib,Gdk
import workspace
from workspace_store import Store
with tempfile.TemporaryDirectory() as td:
 os.environ['XDG_DATA_HOME']=td
 store=Store();pid=store.create('Saved project',td);store.save_notes(pid,'Notes survive restart');task=store.add_task(pid,'Completed task');store.set_done(task,True);store.close()
 real_run=Gtk.Application.run
 result={}
 def check(app):
  try:
   assert app.current[1]=='Saved project'
   assert app.title.get_text()=='Saved project'
   buffer=app.notes.get_buffer();assert buffer.get_text(*buffer.get_bounds(),True)=='Notes survive restart'
   assert app.task_box.get_children()[0].get_active()
   assert app.details.get_sensitive()
   assert 'Folder linked' in app.status.get_text()
   result['startup_reopen']='pass: selection, notes, tasks, editable details and honest status restored'
   window=app.window.get_window()
   pix=Gdk.pixbuf_get_from_window(window,0,0,window.get_width(),window.get_height())
   if pix:pix.savev(str(repo/'test-results/milestone-01/desktop-acceptance/startup-reopen.png'),'png',[],[])
  except Exception as error:result['error']=repr(error)
  app.quit();return False
 def run(app,argv):
  GLib.timeout_add(500,check,app)
  return real_run(app,argv)
 with patch.object(Gtk.Application,'run',run):workspace.main()
 print(json.dumps(result))
 out=repo/'test-results/milestone-01/desktop-acceptance/startup-reopen.json';out.write_text(json.dumps(result,indent=2)+'\n')
 if 'error' in result:raise SystemExit(1)
