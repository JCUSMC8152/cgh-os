#!/usr/bin/env python3
"""Dual-stack temporary virtual-link test. Never disables the firewall."""
import os,pathlib,subprocess,time,json,sys
if os.geteuid()!=0:raise SystemExit('Root required in the disposable acceptance VM.')
product=pathlib.Path('/sys/class/dmi/id/product_name').read_text().lower()
if not any(x in product for x in ['qemu','kvm','standard pc']):raise SystemExit('Refusing outside the disposable VM.')
def run(a,check=True):return subprocess.run(a,capture_output=True,text=True,check=check,timeout=20)
if not run(['ufw','status']).stdout.startswith('Status: active'):raise SystemExit('Firewall inactive: acceptance fails.')
suffix=str(os.getpid())[-6:];ns='cgh-test-'+suffix;v='cgh'+suffix+'a';peer='cgh'+suffix+'b'
ns_created=False;link_created=False;results=[]
try:
 run(['ip','netns','add',ns]);ns_created=True
 run(['ip','link','add',v,'type','veth','peer','name',peer]);link_created=True
 run(['ip','link','set',peer,'netns',ns]);run(['ip','link','set',v,'up']);run(['ip','-n',ns,'link','set',peer,'up']);run(['ip','-n',ns,'link','set','lo','up'])
 for version,src,dst,prefix,port in [(4,'10.203.77.2','10.203.77.1','30',31991),(6,'fd74:6367:6801::2','fd74:6367:6801::1','64',31992)]:
  family='AF_INET' if version==4 else 'AF_INET6';opt=[] if version==4 else ['-6'];flags=[] if version==4 else ['nodad']
  run(['ip',*opt,'addr','add',dst+'/'+prefix,'dev',v,*flags]);run(['ip','-n',ns,*opt,'addr','add',src+'/'+prefix,'dev',peer,*flags])
  ruleargs=['allow','in','on',v,'from',src,'to',dst,'port',str(port),'proto','tcp'];rule=False;server=None
  def connects():
   code=f'import socket;s=socket.socket(socket.{family});s.settimeout(2);s.connect(({dst!r},{port}));s.close()'
   return run(['ip','netns','exec',ns,'python3','-c',code],False).returncode==0
  try:
   code=f'import socket;s=socket.socket(socket.{family});s.setsockopt(socket.SOL_SOCKET,socket.SO_REUSEADDR,1);s.bind(({dst!r},{port}));s.listen();\nwhile True:\n c,a=s.accept();c.close()'
   server=subprocess.Popen(['python3','-c',code],stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL);time.sleep(.5)
   denied_before=not connects();run(['ufw',*ruleargs]);rule=True;allowed=connects()
   run(['ufw','--force','delete',*ruleargs]);rule=False;denied_after=not connects()
   results.append({'protocol':'IPv'+str(version),'deny_allow_deny_passed':denied_before and allowed and denied_after})
  finally:
   if rule:run(['ufw','--force','delete',*ruleargs],False)
   if server:server.terminate();server.wait(timeout=5)
 print(json.dumps({'scope':'isolated virtual link','results':results}))
 sys.exit(0 if all(x['deny_allow_deny_passed'] for x in results) else 1)
finally:
 if link_created:run(['ip','link','del',v],False)
 if ns_created:run(['ip','netns','del',ns],False)
