import gi,subprocess
gi.require_version("Gtk","3.0")
from gi.repository import Gtk
w=Gtk.Window(title="Welcome to CGH OS — Live Preview")
w.set_default_size(760,560)
b=Gtk.Box(orientation=Gtk.Orientation.VERTICAL,spacing=14,margin=24);w.add(b)
b.pack_start(Gtk.Label(label="CGH OS",xalign=0),False,False,0)
b.pack_start(Gtk.Label(label="One system for everyday life, building, learning, and exploring.",wrap=True,xalign=0),False,False,0)
scroll=Gtk.ScrolledWindow();scroll.set_policy(Gtk.PolicyType.NEVER,Gtk.PolicyType.AUTOMATIC)
view=Gtk.TextView();view.set_editable(False);view.set_cursor_visible(False);view.set_wrap_mode(Gtk.WrapMode.WORD_CHAR)
view.get_buffer().set_text(open("/usr/share/cgh-os/PREVIEW.txt").read());scroll.add(view);b.pack_start(scroll,True,True,0)
x=Gtk.Button(label="Open CGH Control Center");x.connect("clicked",lambda _:subprocess.Popen(["python3","/usr/share/cgh-os/control_center.py"]));b.pack_start(x,False,False,0)
x=Gtk.Button(label="Close and explore the desktop");x.connect("clicked",lambda _:w.destroy());b.pack_start(x,False,False,0)
w.connect("destroy",Gtk.main_quit);w.show_all();Gtk.main()
