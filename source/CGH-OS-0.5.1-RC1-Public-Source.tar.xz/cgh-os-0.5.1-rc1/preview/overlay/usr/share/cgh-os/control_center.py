#!/usr/bin/env python3
"""Unprivileged GTK launcher. No shell commands or embedded web server."""
import subprocess
import gi
gi.require_version("Gtk", "3.0")
from gi.repository import Gtk
TOOLS = {
 "Everyday": [("Files", ["nautilus"]), ("Documents", ["libreoffice"]), ("Passwords", ["keepassxc"]), ("Backups", ["deja-dup"])],
 "System": [("Settings", ["gnome-control-center"]), ("Software and updates", ["gnome-software"]), ("Disks — review before changing", ["gnome-disks"])],
 "Build and explore": [("Terminal", ["gnome-terminal"]), ("Virtual machines (optional pack)", ["virt-manager"])]}
class Center(Gtk.Window):
 def __init__(self):
  super().__init__(title="CGH OS • Control Center")
  self.set_default_size(800, 600)
  box=Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=14, margin=24)
  scroll=Gtk.ScrolledWindow()
  scroll.set_policy(Gtk.PolicyType.NEVER,Gtk.PolicyType.AUTOMATIC)
  scroll.add(box)
  self.add(scroll)
  box.pack_start(Gtk.Label(label="One system for everyday life, building, learning, and exploring.", wrap=True), False, False, 0)
  for category, entries in TOOLS.items():
   box.pack_start(Gtk.Label(label=category, xalign=0), False, False, 0)
   for title, argv in entries:
    button=Gtk.Button(label=title)
    button.connect("clicked", self.launch, argv)
    box.pack_start(button, False, False, 0)
  box.pack_start(Gtk.Label(label="Live preview • Changes reset at shutdown • Optional packs: cgh-pack plan developer | homelab", wrap=True),False,False,0)
 def launch(self, button, argv):
  try: subprocess.Popen(argv)
  except OSError:
   d=Gtk.MessageDialog(transient_for=self, modal=True, message_type=Gtk.MessageType.INFO, buttons=Gtk.ButtonsType.OK, text="This tool is unavailable. Install its optional capability pack first.")
   d.run(); d.destroy()
if __name__ == "__main__":
 win=Center(); win.connect("destroy",Gtk.main_quit); win.show_all(); Gtk.main()
