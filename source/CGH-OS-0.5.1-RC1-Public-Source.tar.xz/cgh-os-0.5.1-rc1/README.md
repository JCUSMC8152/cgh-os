Current build: **0.3.1 Milestone 01**, original Workspace and executed guest checks. See [the verification report](docs/MILESTONE-01.md), including the emulated-graphics limitation.

Current original-app milestone: see [Milestone 01](docs/MILESTONE-01.md).

Current Developer integration: see [0.2.3 verification record](docs/DEVELOPER-0.2.3.md).

# CGH OS — integrated security and tool-suite candidate
One system for everyday life, building, learning, and exploring.

**The 0.1.0 USB preview is superseded. Do not prepare it for owner testing.**
The 0.2.0 candidate includes the Everyday, Developer, Home Lab and security
manifests, authenticated administrator access, first-session passphrase setup,
privacy defaults, and runtime acceptance probes. Its release gate is in
`docs/INTEGRATED-ACCEPTANCE.md`; implementation is not proof of enforcement.

The active image build uses `scripts/assemble-integrated-guest.sh` inside a
fully isolated Debian 13 VM. It starts from the signed official Debian live
base, installs updates and all tools, removes temporary build transport trust,
and creates a live-only candidate. The source's conventional live-build recipe
is another build path and must be independently boot-tested before use.

Source-only checks: `./scripts/check.sh`. Runtime probes are under `scripts/`;
privileged firewall, AppArmor and LUKS tests refuse non-VM systems. Source tests
do not establish that the integrated ISO is ready. See `docs/STATUS.md`.

## Build in a disposable Debian 13 VM
Allocate provisionally 4 vCPUs, 8 GiB RAM, 40 GiB free disk. These are build
planning estimates, not measured end-user requirements.

```sh
sudo apt-get update
sudo apt-get install live-build debootstrap squashfs-tools xorriso isolinux   syslinux-common grub-pc-bin grub-efi-amd64-bin mtools dosfstools
./scripts/check.sh
sudo ./scripts/build.sh
```

Build requires root with mount/chroot capabilities and network access. This cloud
workspace has uid 0 but no Linux capabilities, no KVM, and no build tools; root
identity alone is insufficient. CGHMain has Windows but WSL is not installed.

The first build must resolve package availability, validate live-build options,
and inspect logs. The recipe is not a validated installer or Secure Boot image.
Upstream signatures do not establish authenticity of a CGH ISO. No release key
is included. SHA256SUMS detects corruption, not malicious substitution unless
obtained through an authenticated, independently verified channel.

## Capability packs
```sh
cgh-pack plan developer
sudo cgh-pack install developer
cgh-pack plan homelab
sudo cgh-pack install homelab
sudo cgh-pack remove developer
```
APT asks before proceeding. Removal retains user files and does not autoremove.
Packs use only configured Debian repositories. Package starts are suppressed
during the transaction; known virtualization daemons/sockets are disabled after
successful installation. Validate inactive services after installation AND reboot.
Do not treat this prototype as a sandbox for hostile workloads.

## Checks
`./scripts/check.sh` checks Python and shell syntax, allowed pack arguments,
planning behavior, source/image consistency, and absence of selected server
packages from Everyday. It does not validate a running operating system.

## License
Original CGH code: MIT (LICENSE). Debian and bundled packages retain their own
licenses. A release must ship source/license notices as required by each package;
this repository's MIT license does not relicense those packages.
