# Integrated candidate acceptance — not yet passed

Do not ask the owner to rewrite a USB for the old 0.1.0 preview. The next owner
handoff must contain the installed Everyday, Developer, Home Lab and security
packages, not merely launcher definitions.

Required VM evidence:
- Current authenticated Debian indexes and installed package inventory.
- No build proxy, temporary CA, test credentials or owner data in the image.
- UFW active, IPv4/IPv6 policy inspected, controlled deny/allow network test.
- AppArmor active and an actual enforcement/denial test.
- No passwordless sudo in the distributed user session; no public default password.
- Deliberate credential setup and successful screen lock/unlock.
- SSH/virtualization/discovery services disabled until explicitly configured.
- Python venv + pytest; Node program; C compilation; rootless Podman workload.
- Isolated VM creation; no automatic network exposure.
- Restic backup, restore and matching file hashes.
- Browser/office/PDF/password/backup/printing settings GUI smoke tests.
- Control center small display, keyboard navigation and screen-reader smoke test.
- Complete ISO boot, integrity hashes and installed software/license inventory.
- Recovery/update-interruption and encryption workflows clearly distinguished
  from normal live-session tests. Anything untested must remain an explicit gap.

A live image without persistence loses updates/settings at shutdown. Encrypted
persistence, installation encryption, Secure Boot and physical hardware tests
must not be called complete based on source configuration alone.

Emulator finding: the old QEMU `-cpu max` run produced llvmpipe/desktop crashes.
Use a conservative CPU model while reproducing; it does not establish the
physical laptop will fail. Do not label the old preview ready for a broad test.

Source audit found that live-config 11.0.5 uses separate `sudo` and `policykit`
components. Both are disabled in the candidate boot parameters. The credential
service also removes the known sudo_on_live.rules bypass as defense in depth.
This correction still requires a runtime authorization test before handoff.

The standard live-config `noautologin` flag is set for both graphical and console
sessions. This prevents a locked desktop being bypassed through an automatically
logged-in text console. The owner chooses a private session passphrase, then
logs into the desktop normally. Runtime TTY and lock/unlock checks are required.
