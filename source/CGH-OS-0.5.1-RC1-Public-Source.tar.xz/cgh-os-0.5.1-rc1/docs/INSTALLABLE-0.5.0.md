# CGH OS 0.5.0 Installation Candidate

Status: build and installation acceptance in progress; not yet approved for the HP internal drive.

Parent: the exact CGH OS 0.4.0 Milestone02 ISO, SHA-256 badd8926984407823443bd540318849c70dd162646c829d83f5f31a91e702cf2. The single installable filesystem merges the parent Debian root and current CGH configuration. It retains Budget, Workspace, Developer and Home Lab tools and the approved Orbit artwork. Wallpaper uses aspect-preserving zoom.

Calamares and calamares-settings-debian come from signed Debian 13 package repositories. The modified settings.conf and users.conf are derived from calamares-settings-debian 13.0.13-1 under ISC; see CALAMARES-SETTINGS-UPSTREAM-COPYRIGHT. Original CGH modules are covered by the project license. Upstream package notices remain in the image.

The installer requires administrator authentication, no initial partition choice is selected, and a final confirmation is enabled. CGH cleanup removes the live password service, live installer launchers and their service dependencies from the installed target. It preserves applications and personal files. Target boot preparation uses bundled BIOS/UEFI GRUB files without downloading a bootloader. A private user account must be created during installation; root remains locked. Minimum user password length is 14 characters.

The development builder is a temporary Alpine VM only. Its noapic workaround addresses a reproduced QEMU/Alpine IO-APIC timer panic. It is not a CGH OS boot setting and does not change the Debian foundation.

Fresh source acceptance: 57 tests passed, including five target-cleanup safety fixtures. Installer PolicyKit XML parses and helper/build shell syntax checks pass. These are not installation acceptance.

Remaining gates: final ISO build/readback, a complete Calamares installation on a disposable virtual disk, boot with the ISO removed, named-user login, persistent data after reboot, application workflows and security diagnostics. BIOS/UEFI/Secure Boot/encryption claims must follow recorded runtime evidence, not the presence of boot records or files.

## ChatGPT and remote testing

Official ChatGPT Linux preview documentation lists Debian 13 x64 support: https://learn.chatgpt.com/docs/linux/linux-app . Download the official x64 .deb and install using apt after OS installation; the owner signs in. No ChatGPT account, token or third-party installer is embedded. Linux Computer Use is not supported in that preview according to the same documentation.

The current CGH Remote tool controls Windows CGHMain only. No Linux agent enrollment or remote connection to the HP has been verified. A separate supported connection is required after the HP is installed. The existing Windows connection can potentially broker a key-authenticated, LAN-restricted SSH connection to the HP; this must be configured and verified on the actual devices, without reusing device identities or shipping access keys in the ISO. Do not describe this as completed Linux CGH Remote support.

## Log collection

The image includes cgh-test-log (ordinary user), plus synthetic acceptance scripts under /usr/share/cgh-os/acceptance/scripts. Run the log collector without sudo and review the generated private report before sharing. Installed storage persists across reboot; independent backups are still needed.
