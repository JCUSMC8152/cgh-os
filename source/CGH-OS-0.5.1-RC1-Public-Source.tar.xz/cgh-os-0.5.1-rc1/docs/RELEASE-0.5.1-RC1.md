# CGH OS 0.5.1 RC1
Pre-release installation candidate based on Debian 13 and GNOME.
Support scope: Intel/AMD 64-bit PCs, with live hardware validation before installation. Tested physical model: HP Pavilion dm4. This does not certify all PCs.
Secure Boot, encrypted installation, dual boot, Bluetooth without a detected controller, printers/scanners and external displays need separate evidence.
Never include an owner account, CGH Remote identity, Wi-Fi profile, private signing key or ChatGPT credential in an image.
The installer can erase the selected drive. Back up independently and verify the target and final confirmation.
Fixes: Debian DNS package naming, tracepath registration, automatic signature updates, ClamAV 1.4.6 from signed Debian trixie proposed updates, no NotifyClamd for the on-demand scanner.
The proposed packages are selected explicitly and verified against signed indices; globally enabled repositories stay on normal Debian 13 sources. Archive exact indices, package hashes and corresponding source. Review current Debian security status before each rebuild; a minimum version is not a vulnerability guarantee.
Release gates: exact-image checksum/signature validation, fresh installation on disposable storage, disk-only reboot/persistence, runtime tests, privacy inspection, source/license inventory and documented recovery.
Security reports: admin@crawfordgroupholdings.com. Include version, reproduction and impact; exclude passwords and private records. No response-time or support-duration promise.
Public distribution must include corresponding source delivery and upstream license notices. Private diagnostic logs are not public release materials.

Dependency freeze: refresh Firefox ESR and Thunderbird to Debian 153.6.0 ESR security builds and ImageMagick to deb13u13, including every installed matching Firefox locale package. The cached builder is not evidence of current security updates. Regenerate package inventory and SBOM after changes, compare source versions against the current Debian security tracker, and archive all exceptions with evidence. Proposed-update fixes may not yet be reflected in stable-suite tracker status; verify exact CVEs against the authenticated source changelog rather than treating a newer version as a blanket exception.

Updater mode: enable the continuous freshclam updater and disable the newly packaged one-shot boot service and daily timer to avoid concurrent updater/log locks. This selection does not add a listening scanner daemon.
