# CGH OS Milestone 02 — CGH Budget

October 28, 2026. Private application/source candidate 0.4.0~milestone2.
**The application package is built and tested. A new bootable ISO has NOT been built or boot-tested.**

## Delivered original functionality

CGH Budget is original Crawford Group Holdings, LLC software under the repository's MIT license. It uses the project's existing Python 3, GTK 3 and SQLite stack. There is no bank connection, account login, subscription, AI component, telemetry, advertising, payment initiation, financial recommendation or application network API. Debian/GNOME, GTK, PyGObject and SQLite remain third-party components with their own ownership and licenses. The approved Orbit art and tagline are unchanged.

Create one budget per SQLite file, choosing USD, EUR, GBP, CAD, AUD, JPY or KWD. Currency is immutable after creation; all amounts in a file share that currency. Create manually maintained accounts with opening balances and spending categories. Set monthly income and category plans; record income, expenses and transfers; inspect category actuals and remaining budgets, account balances, and one-time upcoming/overdue bills. Search transaction memos or dates and correct selected entries. Data is saved transactionally at each successful action. Ctrl+F focuses search; Ctrl+N opens a transaction; entry fields support Enter to save dialogs.

Transfers move funds between distinct accounts and never count as income or spending. Opening balances are not income. Bill tracking is separate from transactions: toggling paid does not create an expense, preventing double counting; record the expense separately. Amounts become integer currency units using Decimal input validation; aggregate calculations use Python integers to avoid SQLite integer overflow or promotion to floating point. Dates are ISO calendar dates, independent of machine time zone; month filtering covers leap days and year changes. The user selects the displayed month.

Records can be previewed and exported as UTF-8 versioned JSON. Export contains names, amounts, dates and memos; it is sensitive, not a redacted sharing format. SQLite backups use SQLite's backup API. Restore checks version, integrity, foreign keys, record shapes and monetary/date invariants, reconstructs the canonical schema (discarding backup-supplied triggers), and requires a new destination. It opens the restored copy in the current application and preserves the previous database. The normal launcher opens the default file on the next start; launch a restored copy with `--database /path/to/restored.sqlite3` when reopening it. JSON export is for inspection/interchange, not the backup-restore format.

New database directories use 0700 and database, export and backup files use 0600. Existing parent directory permissions are not changed. Data/backups are **not encrypted**. Export and backup publication refuses existing destinations. These controls do not protect data from someone who controls the same logged-in account or root. There is no daemon, listening service, root helper, automatic upload or credential collection. This is a recordkeeping tool, not professional financial advice.

## Audit and integration

Recovered the exact referenced Milestone 01 source (Library version 15), then cloned its included recovery bundle. Parent implementation commit: `c87689c` (record final 0.3.1 cold-boot workflow/startup regression and graphics limits). No remote URL or historical upstream repository was invented. The prior source/build history remains in the new recovery bundle.

The existing report records 34 source tests and 11 guest checks on 0.3.1. Its included JSON summary confirms those recorded counts and VM-only softpipe use. These historical results are not represented as newly executed guest checks. Existing Workspace source is unchanged; its host GTK workflow and startup regression were rerun.

Budget had no existing implementation/name in the recovered project. The new model and GUI follow Workspace's split between independent storage and GTK interface. Navigation/search/empty/error widgets use standard GTK controls. A cross-application component framework was not introduced for this focused milestone; export/backup use a no-clobber helper specific to Budget. Integration is an Everyday Control Center tile, stable application ID `com.crawfordgroupholdings.CGHBudget`, Finance desktop entry and distinct ledger/coin SVG icon. Source and ISO overlay copies are checked for equality. No custom D-Bus interface or background integration was added.

The overlay builder and boot labels are prepared for 0.4.0 Milestone 02, but that recipe is unexecuted here. The package declares `python3`, `python3-gi`, and `gir1.2-gtk-3.0`, already used by the baseline. Original MIT licensing and third-party notices remain intact.

Schema 1 is the first Budget schema. There is no preexisting Budget schema to upgrade; initial creation is tested. Unknown populated databases and future schema versions are refused. No claim is made that a future migration has been implemented or tested.

## Reproduce and use

Extract on Linux with `unzip` to preserve executable permissions and symlinks. The ZIP contains a source tree and `artifacts/CGH-OS-Milestone02-Recovery.bundle`. To recover a proper Git checkout:

```sh
git clone cgh-os/artifacts/CGH-OS-Milestone02-Recovery.bundle cgh-os-build
cd cgh-os-build
bash scripts/check.sh
python3 scripts/package-budget.py
```

Install on a compatible Debian/GNOME test system:

```sh
sudo apt install ./artifacts/cgh-budget_0.4.0~milestone2_all.deb
```

Launch **CGH Budget** from the application menu, or:

```sh
/usr/bin/python3 /usr/share/cgh-os/budget.py
/usr/bin/python3 /usr/share/cgh-os/budget.py --database /path/to/restored.sqlite3
```

Default database: `$XDG_DATA_HOME/cgh-os/budget/budget.sqlite3`, falling back to `~/.local/share/cgh-os/budget/budget.sqlite3`. Removing the package retains user data.

Workflow: create budget → add account(s) and category → select month → monthly plan → transactions (category only for expense, target only for transfer) → inspect tabs → add one-time bills → search/correct → preview/export → back up to a new filename → restore backup to another new filename. Currency amounts omit symbols in cells; the active currency code is displayed above them. Before ending a nonpersistent live session, explicitly back up to storage that survives reboot.

Run actual GTK tests on a compatible Linux machine with GTK/PyGObject and Xvfb:

```sh
xvfb-run -a /usr/bin/python3 scripts/test-budget-ui.py test-results/milestone-02/ui
GDK_SCALE=2 xvfb-run -a /usr/bin/python3 scripts/test-budget-ui.py test-results/milestone-02/ui-2x
xvfb-run -a /usr/bin/python3 scripts/test-budget-package.py
```

The tests use synthetic data and programmatically fill real GTK dialogs. The actual save chooser is exercised once. Subsequent backup/export destination paths are supplied by the harness; the export preview and restore confirmation are actual dialogs. Screenshots are actual GTK windows, not design mockups. The package smoke test maps the desktop Exec into an extracted package prefix and starts a separate GUI process; it does not certify GNOME menu launch inside a new ISO.

On a build machine with enough storage and baseline ISO, follow existing `docs/MILESTONE-01.md` for prerequisites, then from a clean committed checkout:

```sh
python3 scripts/build-config-overlay.py /path/to/CGH-OS-0.3.1-Milestone01-amd64.iso /path/to/CGH-OS-0.4.0-Milestone02-amd64.iso
```

The script writes a checksum only after an actual successful image build. Allow space for the approximately 4.9 GiB input, output and build scratch. No new ISO checksum is supplied in this delivery because no such image exists.

## Executed evidence

- 52 source tests pass: 34 preserved tests plus 18 Budget tests. `scripts/check.sh` also compiles Python and checks shell syntax.
- Budget: 10 graphical workflow check groups at normal scale and the same 10 at 200% scale. Creation, account/category/planning, income/expense/transfer dialogs, bills, search/correction, real save chooser, preview/export, backup/restore/open, bill paid status and reopened data are covered.
- Separate-process storage reopen, exact fractions, currencies with 0/2/3 decimal places, invalid/future/unknown/corrupt data, leap day/year boundaries, foreign keys, restrictive modes, no-clobber export/restore, failed export preservation, backup trigger removal, high-precision rejection and aggregate integer overflow protection pass.
- Workspace's existing host GTK workflow (10 check groups) and startup-selection regression pass. Its GIO launch is intercepted in that harness; the previous guest's real Nautilus launch was not rerun.
- Final Budget .deb built twice byte-identically. Package source hashes, desktop Exec/icon, dependency declaration and a separate packaged GUI process launch pass; process stderr was empty.
- Missing-PyGObject launch exits with an actionable dependency message. The app contains no network API; all synthetic workflows run without contacting a financial service. This is not a packet-capture audit or full offline GNOME image test.
- Screenshots at normal and 200% scaling were inspected for visible tables, controls and legibility. Keyboard shortcuts are implemented; screen-reader/manual keyboard-only acceptance remains outstanding.

Final package SHA-256:
`0b9ba8d07dd093a5a823476c4303841e6b5903b115bab372a0e7f73f9367354c`

### Resource sample

Host Ubuntu container, GTK3/Xvfb, tiny synthetic fixture; not the HP laptop or a CGH OS guest. Normal scale RSS 79,932 KiB (78.1 MiB), peak 81,072 KiB (79.2 MiB). At 200%, RSS 100,424 KiB (98.1 MiB), peak 112,104 KiB (109.5 MiB). Two-second idle intervals consumed 0.00339 and 0.00324 process CPU seconds respectively. These short samples do not establish battery life, large-data performance, total desktop memory or 8 GB physical-system behavior. No background Budget work runs while the application is closed.

## Graphics investigation and acceptance limits

The recovered final summary explicitly records GNOME Shell SIGSEGV with llvmpipe under QEMU TCG and successful guest workflow checks using VM-only softpipe. The recovered final guest JSON has an older host-description string saying 0.3.0 despite its final-031 location; the report, summary and hash identify the intended 0.3.1 record. Treat this metadata inconsistency as an evidence limitation, not a fresh reproduction. The bundle does not provide a sufficient renderer crash backtrace to assign root cause.

This workspace has no QEMU executable, `/dev/kvm` or `/dev/dri`, and only roughly 2.3 GiB free after test dependency setup, less than the baseline ISO alone. GTK was made available through locally extracted test dependencies; the host package installation was not used for acceptance. Xvfb validates GTK widget behavior, not GNOME Shell/Mutter/Mesa or physical graphics. No renderer environment override was added to CGH OS. The crash remains unresolved; neither emulator-only causation nor hardware failure has been established.

A new integrated ISO build, readback, checksum, cold boot, ordinary-user guest test and final desktop visual acceptance remain pending. The next focused milestone is performing these on a sufficiently provisioned host, comparing default llvmpipe/accelerated graphics and recording a crash backtrace where applicable, then testing that exact image on the HP laptop. Do not add more apps before that acceptance step.

The current application retains data after restart on the same filesystem. Live-USB reboot persistence, installation, UEFI runtime, Secure Boot, Mac support, suspend/resume and broad hardware compatibility remain unverified. Extended financial datasets, encrypted backups, CSV import, recurring bills, savings goals, account/category renaming/deletion and transaction deletion are outside this first scope. Communications, weather, personal inventory and cross-application overview were intentionally not implemented in this focused milestone.

No public deployment or physical disk/USB write was performed.
