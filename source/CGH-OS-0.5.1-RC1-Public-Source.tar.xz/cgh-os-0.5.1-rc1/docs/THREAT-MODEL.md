# Threat model and security acceptance

| Threat | Intended control | Current evidence / gap |
|---|---|---|
| Stolen laptop/USB | LUKS encryption, lock, offline recovery key | Installer/persistence encryption untested |
| Hostile network | Inbound deny; no remote server; TLS repositories | UFW recipe written; packet tests pending |
| Malicious desktop app | Standard user; permissions; Wayland; AppArmor | Runtime profiles and app isolation pending; no universal sandbox claim |
| Compromised dependency | Signed upstream repositories; inventory | Build inventory code exists; SBOM/license audit pending |
| Untrusted development code | venv/rootless containers or isolated VM | Container is not a security boundary equivalent to a VM |
| Shared computer | Separate users; protected secrets; lock | Installed user workflow pending |
| Update breakage | Backups, recovery ISO; future rollback | Restore/interrupted-update tests pending |
| Remote access abuse | No default server; authentication if enabled | CGH Remote intentionally absent |
| Private data disclosure | No CGH telemetry; local launcher | Whole-system traffic capture and diagnostics redaction pending |

Live sudo is a known separate trust boundary. A live USB is not hardened storage
merely because the base OS has security packages installed. Secure Boot and disk
encryption address different threats. Encryption does not protect an unlocked
session; VPN/DNS encryption does not guarantee anonymity.

Before release: audit setuid files, capabilities, enabled units, listening ports,
APT origins, browser policies, GNOME privacy, core dumps/log retention, SSH keys,
machine-id regeneration, entropy, and all live-only sudo/autologin files.
Keep AppArmor enabled; investigate denials rather than disabling it globally.
No passwordless admin rules, release keys, or owner secrets may ship.
