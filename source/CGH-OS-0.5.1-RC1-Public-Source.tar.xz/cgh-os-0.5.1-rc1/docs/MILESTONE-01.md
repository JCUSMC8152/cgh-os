# CGH OS Development Milestone 01 — Workspace

October 28, 2026. Private development candidate, not a public release.

## Baseline audit

Recovered the existing source archive, Library version 13 (its historical filename
still says 0.1.0), and the 0.2.3 Developer ISO. The source was committed locally
before edits, providing a reversible content baseline. Archive-recorded executable
bits and symbolic links were subsequently restored and regression checked; the
first test build exposed their loss during ZIP extraction and was discarded. The archive does not contain the
original Git history or a remote repository URL; the new baseline commit is a
recovery checkpoint, not the historical upstream commit.

The saved ISO's configuration layer was extracted: Control Center, Developer,
Home Lab, security status and Welcome files match the recovered baseline byte for
byte. Its build-info records source commit
`f63d97daa512cb7e02d969378ad69436bac6cb67`. Its module order is
`filesystem.squashfs` then `cgh-config.squashfs`. BIOS and UEFI catalog entries
exist; catalog presence alone does not prove either firmware boots.

- Debian/GNOME provide kernel, boot, desktop, GTK, NetworkManager, systemd,
  settings, notifications and file handling. These remain upstream components.
- LibreOffice, Firefox, Thunderbird, Geany, Git, Podman, QEMU, ClamAV, restic
  and the other bundled tools are third-party software, retaining their licenses.
- Original CGH Python code includes Control Center, capability-pack planning,
  Developer workflow helpers, Home Lab helpers, security observations and file
  scanner UI. Several routes are wrappers around third-party programs; they are
  not independently authored replacements for those programs.
- Control Center: category sidebar and distinct tool icons already implemented;
  primarily a launcher with real security observations. Global search, cohesive
  system state, and shared visual components remain incomplete.
- Welcome: static guide and Control Center launcher. It does not yet implement
  hardware/network discovery or first-run progress tracking.
- Developer: project-local environments, loopback previews and API/SQLite helpers
  exist. Home Lab has explicit interactive checks and service operations. This
  milestone preserves them; it does not certify their privileged behavior.
- No CGH Workspace or full CGH System Health app existed in this source baseline.
- Source and `config/includes.chroot` duplicate executable files. The legacy
  `preview/overlay` contains an older launcher; build-preview.sh explicitly gates
  that superseded path. It was not expanded. New tests enforce current Workspace
  and Control Center source/config equality.
- The active integrated overlay build and conventional live-build recipe differ.
  The conventional recipe is not newly certified. Installer launchers are hidden
  in the existing configuration; installation and USB persistence are not added.
- Prior test records remain historical evidence, not newly rerun guest results.
  The owner's Test 01 on one HP Linux laptop with 8 GB RAM succeeded. It is not
  universal compatibility certification; Mac support is unverified.

## Implemented workflow and architecture

Original CGH Workspace uses the existing Python 3 / GTK 3 runtime. A GTK 4 /
libadwaita migration would add a runtime and require migrating existing apps;
there is no need for that expansion to deliver this workflow. GTK controls use
system theme, scaling, accessibility semantics and standard keyboard navigation.

Create a named project by linking an existing folder. Write notes, save with
Ctrl+S, add tasks with Enter and mark completion. Search project names, paths,
notes and task text. Open the linked folder through GIO, respecting the user's
file manager. Review an export before saving versioned UTF-8 JSON. Existing
project files are never copied or moved. Export includes notes, tasks and paths,
not the linked files. JSON can be read by other tools; automatic import/restore
is a future milestone, not an existing feature.

`workspace.py` is the unprivileged Gtk.Application interface.
`workspace_store.py` is a standard-library SQLite storage layer. It uses
`$XDG_DATA_HOME/cgh-os/workspace/projects.sqlite3` (fallback
`~/.local/share/cgh-os/workspace/projects.sqlite3`), schema 2, transactions,
parameterized queries, a private database and atomic private JSON exports.
Schema 1 notes migrate to schema 2 tasks with a SQLite backup first. Newer
schemas are refused. No daemon, root operation, network request, account,
credential store, AI dependency or telemetry is introduced.

Notes save explicitly, when switching projects and on normal window close.
Save failures keep the window open. Forced process termination can lose unsaved
notes. Missing linked drives retain project metadata and produce a clear open
error. SQLite/storage errors show a dialog. Search does not discard unsaved
notes. Large workspaces are not load-tested; search currently scans local data.
There is no project/task deletion or renaming UI in this first milestone.

GNOME integration: application ID
`com.crawfordgroupholdings.CGHWorkspace`, searchable desktop entry, dedicated
folder/notepad icon, GIO folder opening, Ctrl+N/Ctrl+S/Ctrl+F, and an Everyday
Control Center tile. No file association is claimed for JSON because import is
not implemented. No notifications or background startup are needed.

The approved PNG is preserved verbatim, including the miniature orb tagline.
It becomes the default wallpaper with `scaled` positioning so the art/tagline
are not cropped. CGH Ribbon remains the icon-theme name; prominent Control
Center and Welcome labels now say CGH OS. No vector logo master is claimed.

## Reproduce

Extract the source ZIP on Linux with `unzip` so executable bits and symbolic
links survive. Do not use Python `ZipFile.extractall` for this archive: it drops
those attributes. Build-time metadata checks fail closed if they were lost.
From the recovered `cgh-os` directory:

```sh
bash scripts/check.sh
python3 scripts/package-workspace.py
sha256sum artifacts/cgh-workspace_0.3.1~milestone1_all.deb
```

The package builds without root or network using Python 3 and dpkg-deb. It declares
python3, python3-gi and gir1.2-gtk-3.0. The integrated ISO includes these dependencies
through the preexisting package manifest; configuration files deliver Workspace
without reinstalling packages. The standalone .deb adds Workspace on a compatible
Debian/GNOME machine with `sudo apt install ./artifacts/cgh-workspace_0.3.1~milestone1_all.deb`.
Run the desktop entry, or `/usr/bin/python3 /usr/share/cgh-os/workspace.py`.
Removing the package retains per-user data; exporting/backing it up remains the
user's choice. No package maintainer scripts or privileged app helpers are added.

For local GUI verification, install GTK3/PyGObject and Xvfb on a test machine:

```sh
xvfb-run -a /usr/bin/python3 scripts/test-workspace-ui.py
GDK_SCALE=2 xvfb-run -a /usr/bin/python3 scripts/test-workspace-ui.py
```

The GUI test uses temporary folders/data, programmatically accepts dialogs, and
intercepts the external file-manager launch. It tests real GTK widgets and data
operations, not physical mouse use or a full GNOME login session.

The ZIP includes Git history as a recovery bundle rather than a .git directory.
For the ISO builder, from the extracted cgh-os directory restore a checkout:

```sh
git clone artifacts/CGH-OS-Milestone01-Recovery.bundle ../cgh-os-build
cd ../cgh-os-build
```

The existing active ISO build requires squashfs-tools, xorriso,
gtk-update-icon-cache, dconf-cli, Git and a clean implementation checkout:

```sh
python3 scripts/build-config-overlay.py /path/to/CGH-OS-0.2.3-Developer-amd64.iso /path/to/CGH-OS-0.3.1-Milestone01-amd64.iso
sha256sum -c /path/to/CGH-OS-0.3.1-Milestone01-amd64.iso.sha256
```

The builder now compiles the dconf defaults into the configuration module (the
existing first-session credential service also runs dconf update). Boot entry
labels identify Milestone 01; kernel/initrd paths and boot arguments are unchanged.
This reads the old ISO, replaces its configuration module and replays existing
boot records into a new file. It never writes a block device, partitions a disk,
changes host networking or configures security. Keep the original ISO and source
checkpoint to revert. A raw full-build alternative remains documented in README;
it must be independently validated. The .deb is reproducible, but this does not
claim bit-for-bit reproducibility of the complete Debian ISO.

## Executed build and verification — 0.3.1

The final 0.3.1 ISO was built, checksummed, independently read back and cold-booted
in QEMU 8.2.2 / SeaBIOS / q35 / TCG with CPU max, 4 vCPUs, 4096 MiB RAM and
VirtIO VGA. No NIC or writable disk was attached. A separate read-only test CD
and local serial channels belong to the test harness; they are not enabled by
the OS. Private password setup and graphical authentication completed.

The final ISO's own installed application, running as UID 1000 in the GNOME
Wayland session, passed 11 programmatic workflow checks: project linking,
notes/save, tasks/completion, search/empty results, a real GIO request starting
Nautilus, export preview/file save, failed-write close protection and retry,
clean close, reopen and a separate-process read of the saved project. Export
JSON was collected, the database was 0600, the original linked hello.py was
unchanged and the guest's only network interface was loopback. The installed
application hash matches final source and image readback.

The 0.3.1 startup fix selects the first saved project, restoring notes, tasks and
an honest status instead of presenting an empty details pane. A real GTK startup
regression check verifies selection, notes, completion, editable details and
status. 34 source tests also pass. The .deb built twice with identical SHA-256.
Source ZIP extraction and tests preserve the original executable bits and masks.
The desktop entry validates and the configuration readback verifies 563 file
hashes, 563 modes, 45 symbolic links and the corrected 0.3.1 boot menu banner.
All eleven download parts were individually verified; concatenation matches the
ISO. The assembler also checks integrity and refuses an existing output.

### Important graphical test limitation

The default llvmpipe renderer crashed GNOME Shell with SIGSEGV in this TCG setup.
The kernel identified llvmpipe worker threads; the underlying cause has not been
conclusively assigned to QEMU, Mesa or configuration. Guest application tests
therefore used GALLIUM_DRIVER=softpipe and LP_NUM_THREADS=1 in the disposable
VM only, for GDM and the user session. These settings are not shipped as OS
defaults. No login or security setting was weakened.

An earlier longer guest run visually showed Welcome, Orbit wallpaper, Workspace
with populated notes/tasks and the distinct app icon. The final cold-boot test
verifies real GTK widgets, callbacks, storage and GIO routing programmatically;
its early screenshots did not finish painting all application windows under the
slow software renderer. Do not treat these captures as complete final-image
visual acceptance or claim that the Files window contents were visually verified.
The full desktop needs another physical HP test with the new image, or testing
with a working accelerated VM graphics environment. This remains a private test
candidate, not a public release or universal hardware compatibility certification.

The controller initially waited for an acknowledgement after requesting VM exit.
The 11 checks and final artifact record had already passed, and QEMU exited 0;
the controller's teardown wait timed out. Its cleanup handling now accepts the
quit request without waiting for an acknowledgement from the exited process.
This harness correction does not change the ISO or application test results.

### Resource measurements

Final guest app RSS: 80.8 MiB; peak RSS: 83.3 MiB. The nominal 30-second idle interval consumed 0.365 process CPU seconds. Active workflow: 5.142 process CPU seconds over 21.150 wall seconds.

Guest MemTotal − MemAvailable was 1.21 GiB before the app and 1.48 GiB after the workflow with GNOME and the launched tools. These are tiny-fixture software-emulated VM samples, not physical 8 GB laptop
measurements, full-system CPU benchmarks or battery estimates. App RSS comes
from /proc/self/status; CPU uses process_time over a GLib timer; peak RSS uses
getrusage. MemAvailable accounts for reclaimable memory, so it differs from
simply subtracting MemFree. The original HP 8 GB Test 01 applies to the previous
image, not this candidate.

### Reproduce the guest checks

Use a fresh disposable VM. The guest probe is
`scripts/test-workspace-guest.py`; copy it into the guest separately and run it
as the ordinary desktop user in the active session. It requires the application
installed at /usr/share/cgh-os. It creates test fixtures under ~/cgh-acceptance
and retains them so the file manager can finish opening them. Use a fresh test
output directory/user for another run. The application and linked user files
are not moved. The harness programmatically accepts dialogs; GIO really launches
the file manager. Screen captures under Wayland may need the VM's external
capture function. The original Xvfb GUI tests still cover normal/200% scaling.

`scripts/test-workspace-reopen.py` is a dedicated startup regression check on
the source checkout and can be run with xvfb-run. Full probe results and collected
export JSON are under test-results/milestone-01/desktop-acceptance/final-iso-031.
Keyboard event logs and temporary credentials are excluded from deliverables.

### Remaining limits

No installer, live-USB reboot persistence or Mac support was added or tested.
UEFI catalog entries are present, but UEFI runtime and Secure Boot signing are
not verified. Screen-reader use, extended load, suspend/resume, physical network
and storage hardware need separate tests. Data survives app restart on the
current filesystem; that does not establish live-USB reboot persistence.
The source archive includes a recovery bundle/patch; the prior known-working
ISO remains the rollback baseline. No physical disk or USB was written and no
public release was performed.

Final ISO SHA-256:

`2b0862def251ef021d3ba36f4fed1d2855a509dc70229cf0985a3ea1c1f7ef3c`
