# CGH OS 0.2.1 Ribbon

CGH OS 0.2.1 Ribbon — rebuild and test record
Date: October 26, 2026 (America/New_York)

Image: CGH-OS-0.2.1-Ribbon-amd64.iso
Size: 5221384192 bytes
SHA-256: cb3920b7da2f23418d51db03b46f9d789bbf0ab1cf5842ca015f1fd15a9c487f
Image source commit: a704b9da1a108ec39f0ca43903d3bf94c4bc6ef8
Base image SHA-256: aaa3174098f9bf91b8cca5a3041a411cd5ea4e349ebcf0eb5f9139e7a2a8a987

Build method: preserved the package-integrated 0.2.0 tool suite and rebuilt its root-owned configuration squashfs layer with the Ribbon theme, application mappings, GTK window identities and 0.2.1 visual version labels. Boot records were replayed by xorriso. No physical host drive was attached or written.

PASSED
- Source Python/shell syntax and all 10 existing tests.
- Final ISO BIOS boot, private live-password setup and ordinary-user console authentication.
- Final ISO graphical login: active GNOME Wayland session.
- Final ISO CGH Ribbon theme selected by default.
- All 39 icon names/aliases resolved from CGH-Ribbon and decoded at 24, 32, 48 and 128 pixels (156 loads).
- All five pinned desktop entries resolved to CGH Ribbon icons: Control Center, Firefox, Files, Writer and Software.
- Control Center constructed and displayed with custom button icons.
- Actual Wayland protocol reported xdg_toplevel.set_app_id("cgh-control-center"), correcting the generic Python running-window identity.
- Lock defaults remain lock-enabled=true and disable-lock-screen=false. This is a settings observation, not a new lock/unlock cycle test.
- Final ISO UEFI firmware boot reached the Linux live system and systemd services. Secure Boot was not enabled; this was a boot smoke test, not a second graphical-session test.
- All 11 download parts and assembled-image checksum verified after the final correction.

VISUAL INTEGRATION CHECKS
Files and Settings opened and displayed successfully during the first Ribbon image test. Final-image Control Center rendering and icon decoding were then rechecked after the running-window fix. The core icon artwork and third-party application binaries did not change between those tests.

TEST ENVIRONMENT
QEMU 8.2.2 software emulation (TCG), q35, 2 vCPUs, 3 GiB RAM for the desktop. The separate UEFI boot smoke used OVMF and 1 GiB RAM. These allocations are test configurations, not hardware recommendations. Software emulation produced slow desktop startup and portal timeouts; this is not a native-speed benchmark.

SCOPE
This is a live test image: session changes reset at shutdown. No installation or persistent storage is provided. Physical Linux Mint laptop testing, Secure Boot signing, full application acceptance and a repeat of every earlier security/tool-suite test were not performed in this icon rebuild. Existing 0.2.0 test evidence remains separate.
