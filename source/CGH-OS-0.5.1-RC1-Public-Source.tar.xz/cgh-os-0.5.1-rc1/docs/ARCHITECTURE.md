# Foundation decision — provisional implementation choice

| Foundation | Advantages | Costs for this project |
|---|---|---|
| Debian 13 + GNOME + live-build | Maintained live tooling, broad package archive, conventional administration; upstream release lifecycle documented | Updates are not transactional; rollback and custom installer integration need separate work |
| Fedora Atomic desktop | Image deployments and system rollback; container-oriented development | Custom image delivery/signing pipeline; shorter release cadence; persistent live USB and customized installation need separate validation |
| Ubuntu LTS derivative | Large hardware ecosystem and maintained desktop | Branding/redistribution review, packaging channel decisions, image customization and upgrade testing |

Choose Debian 13 + GNOME for the first executable recipe, not as a declaration
that it offers maximum security. GNOME/Wayland is preferred over X11 for normal
sessions; actual session selection and assistive technology must be tested.
Debian Installer is retained rather than writing a partitioner. No unattended
disk preseed exists. Encryption and dual boot are not yet validated.

System: upstream signed APT packages; AppArmor; UFW; unattended security updates.
Applications: upstream packages initially. Flatpak/portal permissions remain a
later integration; no third-party store is added automatically. No claim is made
that Debian-packaged desktop apps are sandboxed.
Developer: venv/pipx, rootless Podman, per-project dependencies. No Docker socket.
Home Lab: opt-in virtualization tools. Remote desktop/server not installed.
Control center: unprivileged native GTK launcher using fixed argv, no shell,
local web server, telemetry, or cloud dependency. It exposes existing tools;
it is not yet an integrated policy/settings engine.

## Live versus installed trust
The stock live session may grant passwordless sudo, as common live images do.
Treat live sessions as disposable and physically accessible. The installed
system MUST be tested to ensure live sudo/autologin rules are removed, a real
password exists, root login policy is correct, and the firewall remains enabled.
Never label installed account hardening complete before that test.

## Recovery
No atomic update or bootable snapshot rollback is implemented. Use independent
backups and verified recovery media. Snapshot integration must account for
filesystem, encryption, bootloader, and database consistency before inclusion.

## Network disclosures
APT mirrors, time synchronization, firmware metadata and application network
requests may occur. GNOME connectivity checks and browser defaults must be
captured and documented in a running image; privacy verification is pending.
No CGH analytics, account service, remote access agent, or AI service is added.

## Official references (consulted 2026-10-25)
- https://www.debian.org/releases/trixie/
- https://www.debian.org/CD/live/
- https://live-team.pages.debian.net/live-manual/html/live-manual/index.en.html
- https://www.debian.org/releases/trixie/installmanual
- https://fedoraproject.org/atomic-desktops/
- https://www.fedoraproject.org/atomic-desktops/silverblue/
