# CGH Ribbon system integration

CGH Ribbon contains 39 SVG designs, including the original 12 concepts and 27 additional application, action and folder designs. The Control Center maps each of its 17 tools to a different name and different SVG artwork. Security uses four separate action tiles. System aliases cover office applications and the standard Home, Desktop, Documents, Downloads, Music, Pictures, Videos, Templates and Public locations.

The Control Center uses sidebar sections and a responsive icon-tile grid. Tiles retain text names, keyboard focus and activation, accessible names, descriptions and visible unavailable states. Administrator verification, local scans and diagnostics export retain their original behavior and permission requirements.

The theme is under config/includes.chroot/usr/share/icons/CGH-Ribbon. Its index declares Applications, Places and MimeTypes directories, with scalable masters and 24/32/48 pixel tiers. GNOME defaults select the theme through dconf and schema overrides. Adwaita and hicolor remain fallbacks for icons outside this initial system set. Third-party application names and ownership remain unchanged.

The icon-map.json file records system aliases. CGH running windows identify themselves with matching application identities so their dock icons remain branded. Welcome and File Scanner have their own icons rather than sharing the Control Center emblem.

See APP-GRID-0.2.2.md for validation scope, the final-image checksum, documentation-only remaster details and source recovery verification. Physical hardware and complete workflows in every bundled app remain separate acceptance work. This change adds no dock extension, installer or persistence.
