# Ownership and maintenance
Upstream owns kernel, Debian packages and their security fixes. CGH owns custom
configuration, launcher, pack manager, image integration, release artifacts,
documentation, and testing. Debian package support can vary; review security
tracker coverage for each included package rather than promising all packages
have identical support.

Proposed process: daily upstream security review, weekly integration smoke test,
monthly candidate rebuild, expedited critical fixes after assessment. This is
an operating proposal, not an active schedule or support commitment.

Public release requires a staffed vulnerability contact, signing-key custody and
rotation, authenticated distribution, supported-version policy, redistribution
review, and tested recovery. No support duration has been promised.

Costs: sustained engineering, bandwidth/storage, CI build minutes, test hardware,
release signing operations, and incident response. Existing/free infrastructure
may cover prototypes but does not eliminate maintenance cost. No paid service
has been provisioned.

## User recovery guidance
Keep independent copies of important files. Keep encryption recovery secrets
off the computer. Test restores before relying on backups. Snapshots on the same
disk do not protect against disk loss. An OS rollback does not automatically
restore documents or database state.

## Scope still to implement
Encrypted USB creation UI; installer branding and preflight integration;
authenticated ISO signing; runtime SBOM/license export;
pack GUI; service exposure UI; tested rollback; default workload resource enforcement; optional web shortcuts; opt-in CGH Remote; optional AI.
