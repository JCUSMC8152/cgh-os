# Release validation protocol

All items below are pending unless STATUS explicitly records evidence.
Use disposable virtual disks only. Keep host disks out of the guest.

1. Build: archive tool versions, source commit, package inventory, logs and hashes;
   rebuild to compare outputs and document timestamps/mirror drift.
2. Boot: QEMU software emulation and KVM separately; UEFI and BIOS; Secure Boot
   with verification enabled; confirm menu, graphical session, accessibility.
3. Live disk safety: attach a disposable data disk and compare checksums before
   and after boot. Confirm no automatic writable internal-volume mounts.
4. Install: blank virtual disk; guided encrypted install; boot after removing ISO;
   verify users, sudo policy, root access, lock, firewall, services and updates.
5. Dual boot: a licensed disposable Windows guest; save recovery keys; test both
   boot paths. Do not run this test on owner hardware without specific approval.
6. Network: test IPv4/IPv6 inbound blocking; outbound DNS/TLS; offline behavior;
   inventory sockets and services before/after each pack and after reboot.
7. Packs: install/remove/reinstall; interrupted APT; conflicting policy-rc.d;
   application launch; no automatic remote access; unprivileged Podman workflow.
8. Recovery: create independent encrypted backup; delete test files; restore and
   compare hashes. Interrupted update and full recovery using disposable disks.
9. Negative tests: full disk, low RAM, network loss, broken mirror, failed units,
   incorrect passwords. Record user-visible response and data integrity.
10. Accessibility: Orca, keyboard-only installation and desktop, 200% scaling,
    contrast, reduced motion, language/input changes. Automated checks are not
    substitutes for screen-reader testing.
11. Privacy: observe traffic from a clean boot, offline/online and idle; redact
    logs; verify no CGH endpoints or silent external AI calls.
12. Performance: measure boot, RAM/storage, responsiveness, battery/sleep on real
    devices. Planning estimates are not minimum hardware requirements.

Evidence record: build SHA256, source commit, exact VM/physical model, firmware,
CPU/RAM/storage/GPU/Wi-Fi, timestamp, commands/actions, expected/actual result,
logs, defects. Never label a VM result as physical-device verification.
