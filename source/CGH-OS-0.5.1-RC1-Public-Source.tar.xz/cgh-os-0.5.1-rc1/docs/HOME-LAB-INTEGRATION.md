# Home Lab integration

Ten launchers are part of the Control Center image configuration: Virtual machines, Containers, Network Explorer, Connection Diagnostics, Server Connections, Lab System Monitor, Storage & Backups, Local Services, Developer Workbench, and Lab Guides.

Console tools open visibly in GNOME Terminal. VMs use the libvirt user session; containers use rootless Podman. Memory, free storage and KVM availability are shown before either starts. Network Explorer only reads local state. Diagnostics accepts an explicit host and optionally one TCP port. SSH uses the existing OpenSSH configuration. Service mutations are restricted to user services. Backups and disk health open the installed applications. Guides are bundled HTML and work offline.

Nine new distinct SVG pictograms complement the existing virtual-machine icon. All are included in the CGH Ribbon theme at scalable, 24, 32, 48 and 128 sizes. The lab monitor has its own icon because the Developer menu already uses the general system monitor.

Validation: scripts/check.sh passes, including 16 tests covering source parity, package inclusion, asset presence, host input handling, diagnostics arguments and user-service scope. GTK rendering, live package execution and bootable ISO rebuild remain unverified for this change. The previously published ISO does not gain these changes until rebuilt. Windows guest media/licenses are not bundled.
