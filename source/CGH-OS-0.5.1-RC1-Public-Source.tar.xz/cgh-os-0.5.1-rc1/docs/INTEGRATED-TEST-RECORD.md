# CGH OS 0.2.0 integrated candidate test record

Date: 2026-10-25. Scope: private engineering candidate, live session only.
Physical laptops/desktops have not been tested. No installer, persistent USB,
full-disk encryption, transactional rollback or release-signing claim is made.

## Build inputs

- Official Debian Live 13.7.0 amd64 GNOME base.
- Base SHA256: e94859a83b305cae5125dc9c6080ced040c59d099ea7381e7f300fd1dba87a17.
- Debian checksum signature verified using fingerprint
  DF9B9C49EAA9298432589D76DA87E80D6294BE9B.
- Debian trixie, trixie-updates and trixie-security signed package sources.
- Installed package/version/architecture inventory: installed-packages.tsv.
- New kernel: 6.12.113+deb13-amd64.
- QEMU 8.2.2 TCG, q35, qemu64, 2 vCPUs, 4096 MiB RAM; no KVM and no
  physical host block devices passed through.

## Completed before boot

| Check | Result | Scope |
| --- | --- | --- |
| Python/shell syntax + ten source tests | Passed | Source only |
| Python venv creation/execution | Passed | Build root |
| JavaScript execution | Passed | Build root |
| C compilation/execution | Passed | Build root |
| Restic encrypted backup, restore, content comparison | Passed | Temporary build-root files |
| GTK imports | Passed | Build root |
| ClamAV main/daily/bytecode database validation | Passed | Official downloaded database files |
| sudoers syntax/no NOPASSWD source policy | Passed | Build root; live runtime still separate |
| Final initramfs regeneration after removing temporary trust | Completed | Build root |

The base disc remained mounted during the first packaging attempt, so xorriso
refused exclusive access. The mount was released, packaging resumed against
the same configured filesystem, and the reproducible script was corrected.
Neither this failure nor a subsequent successful build proves bootability.

The manifest contains 69 explicit package requests. The installed inventory
contains 3,075 records, including inherited desktop translations and dependencies.
The apparent `dnsutils` name difference was resolved: installed `bind9-dnsutils`
provides the `dnsutils` virtual package. Package counts do not prove usability.

## Runtime gate

Pending: first passphrase and login, console authentication, lock/unlock,
password-required elevation, controlled AppArmor denial, IPv4/IPv6 firewall
deny/allow/deny, rootless offline OCI workload, desktop/office smoke tests,
virtual machine tools, malware scan, encrypted disposable container test,
firmware boot modes and accessibility smoke tests.

Record failures and fixes here before describing this ISO as ready for the
owner's consolidated laptop test. Installation/update interruption/recovery
and real hardware workflows require additional implementation and validation.

## Boot finding: credential console

The BIOS candidate booted kernel 6.12.113 and mounted its live root. The
credential gate started, but boot messages obscured its prompt and password
input behaved incorrectly. The desktop remained blocked (fail closed).
A temporary acceptance revision adds a root-owned squashfs configuration
overlay containing the credential helper, quits Plymouth before password input,
restores sane terminal settings, and suppresses routine boot status. That
revision must pass actual setup before handoff. Its source build recipe contains
the same helper change; the overlay is a traceable repair to the candidate,
not evidence that the revised flow passed.

The build VM was terminated by the cloud's 8 GiB aggregate memory limit after
image packaging while boot VMs overlapped. The ISO had already completed its
xorriso write; its bytes were hashed independently on the host. No physical
disks were attached. Test VM allocation was reduced to 3 GiB; this does not
establish a recommended physical RAM requirement.

## Runtime evidence in the configured BIOS candidate

Passed: private password setup; blank/short/mismatched rejection; normal user
console authentication; no passwordless sudo; Python venv/execution; JavaScript;
C build/execution; GTK import; qcow2 creation; offline rootless OCI workload;
AppArmor controlled denial (strengthened probe also checks the denied fixture
path in stderr); UFW IPv4/IPv6 deny/allow/deny on an isolated link; ordinary-user
transient 128 MiB VM creation, snapshot and deletion; document text → ODT → PDF
→ extracted-text equality; password-vault create/open; encrypted restic backup
and matching restore; disposable regular-file LUKS2 content round trip.

The rootless runtime initially failed because kernel overlay storage cannot be
used over the live overlay root without an additional mount program. Explicit
VFS copying storage passed the full offline workload. This mode uses more
space; it is appropriate to small live tests, not a performance recommendation.
The image source now contains that configuration.

The antivirus probe initially contained one extra character, so its negative
result was a fixture defect. The corrected official 68-byte EICAR fixture was
detected (return 1) and a clean document passed (return 0). Both were scanned
locally; the fixture was not executed. Reference: https://www.eicar.org/download-anti-malware-testfile/.
The complete corrected everyday probe passed.

Observed runtime listeners: CUPS on loopback IPv4/IPv6 port 631 only. No SSH
server binary is installed; remote inbound SSH configuration/revocation is
therefore not implemented or verified. The attempted loopback SSH probe was
unavailable, not passed. The SSH client is included for remote administration.

GUI login, welcome and Control Center rendering passed under software emulation.
The lock audit found inherited Calamares schema defaults disabling screen lock,
plus the upstream live-config screensaver component. Explicit overrides and
component exclusion are now in source. The repaired image must be rebooted and
a real lock/unlock cycle verified before handoff. Runtime adjustment alone did
not prove the already-running GNOME Shell reloaded its cached lockdown policy.

Evidence fixtures are under test-results/0.2.0. They distinguish the manually
configured runtime from the final remastered image, whose full hash and boot
checks must be recorded separately. Physical-device tests remain unperformed.

The inherited restriction was identified in
96_calamares-settings-debian.gschema.override. A later schema override now sets
locking enabled, lockdown disabled, a five-minute idle timeout and curated
favorite applications without an installer. The live credential gate compiles
schemas/dconf before the first desktop, and resets inherited per-user lock
overrides. Text getty templates require that gate; tty1 is reserved for it.
A fresh boot is required to validate the complete configuration.
