# Current CGH OS status — 2026-10-25

The 0.1.0 USB preview is superseded. Do not ask the owner to prepare or test it.
Its tooling was incomplete and the QEMU maximum-CPU rendering run later showed
llvmpipe/desktop crashes. A conservative emulator CPU is now used.

Implemented in source: all four package manifests; native launcher with actual
availability checks; redacted security observations; UFW/AppArmor/update/service
configuration; private live-password gate; disabled passwordless live-sudo
component; browser/desktop privacy defaults; build and acceptance scripts.
Ten source-level tests pass. Syntax checks pass. Runtime enforcement is not
established by those source tests.

Build environment: a Debian 13 VM under QEMU TCG. Its temporary build-only proxy
and CA allow signed Debian package retrieval; APT index update succeeded with
exit 0. The integrated candidate builder is running against an official signed
Debian 13.7 base. Temporary transport settings must be removed before image
creation. No CGHMain OS, firmware or physical disk changes were made.

Not ready for owner USB testing: the integrated ISO, runtime security probes,
rootless containers, complete GUI flows, encryption workflows, backup/restore,
accessibility, Secure Boot, update/recovery and physical hardware still require
specific evidence. See INTEGRATED-ACCEPTANCE.md. No overall security guarantee
or public release is claimed.

Build-root verification now passed: Python virtual environment, Node execution,
C compilation/execution, restic backup + restored-file equality, and GTK imports.
FreshClam downloaded daily, main and bytecode databases and each database test
passed. The installed-package inventory has been generated. These are build-root
checks; full boot/runtime acceptance is still pending.
