# Debian 13 test VM — 2026-10-25
Host: transient Ubuntu cloud workspace, no KVM. QEMU 8.2.2 TCG software emulation.
Guest: official Debian 13 generic amd64 cloud image, 2 vCPU, 4 GiB RAM,
40 GiB sparse virtual disk, BIOS boot. No host physical disks attached.
Network: user-mode NAT; final VM has no host port forwarding. Serial-console control only. No public listener.
SSH uses a temporary key stored outside the repository and deliverables.

The original cloud image SHA512 matched the checksum downloaded over HTTPS:
70ef6adc1c16155f8d575731b37d0f976d1c60b6144ac3f57914a3f4b30b202b69584d5d143aa39da0f0fe81df9e5b698909c0d94c7d91c6f6c4bb6581ead5f0
This is TLS/checksum verification; independent detached-signature verification
was not completed. Resizing the writable test copy changes its file hash.

Debian kernel and systemd boot observed via serial output. This is a build/test
host, not a successfully booted CGH OS image. No graphical desktop, installer,
Secure Boot, encryption or physical-device results follow from this boot.

Reproduce with an official image, verified before modifying, temporary cloud-init
SSH seed, and scripts/run-test-vm.sh. Treat root SSH access as isolated test-host
configuration, never as a configuration for the distributed CGH OS desktop.
Cloud workspace processes and virtual disks can disappear after inactivity;
these are not an always-on remote lab. No CGHMain reboot or OS change was made.

## Guest validation results
Observed Debian 13.7 with kernel 6.12.113+deb13-amd64.
Cloud-init extracted the CGH source into /root/work/cgh-os.
All four safety tests, Python compilation, shell syntax and pack planning passed:
CGH_SOURCE_TEST_EXIT:0. A tmpfs mount and unmount inside the guest succeeded:
CGH_MOUNT_CAPABILITY_OK. Cloud-init reached CGH_VM_TEST_COMPLETE.
No full CGH ISO, graphical session or installed-system security test is complete.

## Build-network limitation
Guest APT could not resolve deb.debian.org through QEMU user networking.
Retry through the workspace HTTP proxy via QEMU's host gateway failed with
connection refused. APT with Error-Mode=any exited 100. No package indexes or
build dependencies were downloaded in the guest. ISO build has not started.
The VM remains usable through its serial console for offline/source tests.
