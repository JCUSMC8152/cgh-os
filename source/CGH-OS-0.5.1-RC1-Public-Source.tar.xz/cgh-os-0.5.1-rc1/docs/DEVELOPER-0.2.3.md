# CGH OS 0.2.3 Developer integration

October 26, 2026 — America/New_York

All eleven Developer tools are integrated into the source and rebuilt live image:
Code Editor, Terminal, Git & Repositories, Python Workspace, Web Development,
Build Tools, API Tester, Database Tools, Logs & Diagnostics, Developer Settings,
and Documentation & Examples. System Monitor remains available under System.

The Control Center now has 34 tools with 34 different icons. Eleven matching
Development desktop entries are included. Nine new Ribbon designs extend the
existing editor and terminal icons at scalable, 24, 32 and 48-pixel sizes.

Git, build and database workflows use terminal interfaces. Git opens a chosen
folder and displays status without creating or changing a repository. Python
creates or reuses .venv and opens an isolated terminal. Web previews serve only
127.0.0.1 on an available port. SQLite opens an existing database read-only.
API Tester supports explicit GET/HEAD/POST/PUT/PATCH/DELETE requests, JSON
headers and text bodies, displays HTTP errors, limits response bodies to 1 MiB,
and never automatically follows redirects or stores credentials. User logs
open in journalctl. Settings stores only the default project folder. An offline
HTML guide and Python/C/JavaScript/HTML examples are included.

Verified:
- 22 source tests pass, including local GET/POST/404/302 responses, rejected
  unsafe URL/header inputs, real loopback web-preview serving, Python workspace
  isolation, distinct artwork and dependency inclusion.
- Python, C and JavaScript examples run successfully in the local test host;
  Python ran inside a real isolated virtual environment.
- GTK Control Center renders at normal and 200% scaling, with 11 Developer
  tiles, accessible names, 11 intercepted launch routes and 44 successful
  Developer icon loads across four sizes. API and settings windows construct.
- The rebuilt ISO was read back. All 551 configuration-file hashes match its
  build-info manifest. All Developer package names occur in the actual base
  filesystem package manifest. All eleven desktop entries are in the image.
- Before the concurrent Home Lab merge, the Developer image booted in QEMU
  TCG with 2 vCPUs, 3 GiB RAM and no network through private password setup to
  the graphical login screen. The final merged image separately booted through
  kernel and system initialization; graphical login was not repeated on that
  final revision. No owner computer OS changes were made.
- ISO size: 5,221,384,192 bytes.
- SHA-256: 65afdfbaaef37e984ec67a114c5a91376e058221e43a565e3ac2b56c61b86856

The image's build-info records the implementation commit. The later source
record adds a web-preview regression test and this verification note without
changing the image's application code.

Limits: GTK launch routing used intercepted processes in the local test bench;
complete real application workflows in the booted guest have not all been run.
UEFI runtime, Secure Boot signing, physical laptop compatibility, persistence
and an installer were not tested or added. This is an unsigned live test build.
Copy work out before shutdown. No third-party account credentials are bundled.

Concurrent Home Lab update was reconciled from source version 11 before final
source writeback. Its ten tools, nine icons, source tests and package declarations
are preserved. The merged configuration module is included in the final image.
The base image already contains ping. The supplementary tracepath executable and
its copyright/license files were extracted from Debian's iputils-tracepath
3:20240905-3 package after matching its SHA-256 against the HTTPS Debian trixie
package index. This executable is bundled in the configuration layer; it is not
represented as a separately installed package in the base filesystem package
manifest. Package metadata is recorded in TRACEPATH-PACKAGE-METADATA.json.
The full-build package list includes iputils-tracepath for normal installation.
The merged Control Center passed local GTK construction, icon loads and all
eleven intercepted Developer launch routes. Final image readback verified 551
configuration hashes, eleven Developer tools and ten Home Lab tools.
