# Test 02 — HP wallpaper scaling correction

October 29, 2026. Based on CGH OS 0.4.0 Milestone 02.

Owner finding: the desktop used the full HP screen width, but the wallpaper did not. The owner confirmed wallpaper scaling and reports everything else appears to work correctly. This is owner-reported acceptance, not an independently executed full hardware test.

Changed GNOME's default background picture-options from scaled to zoom. Zoom fills the display while preserving the image aspect ratio. Both light and dark background URIs already select the same approved Orbit artwork. No artwork was changed.

The image is 1536×1024. At 1366×768 (16:9), zoom shows approximately source rows 80–944; the logo and tagline remain inside this region. The same composition fits 16:10 and 4:3 displays. Extreme ultrawide screens may crop more; these are not certified here. Physical visual confirmation on HP remains pending.

For the current HP live session, run as the ordinary desktop user, without sudo:

```sh
gsettings set org.gnome.desktop.background picture-options 'zoom'
```

The change takes effect immediately. It may disappear on reboot because the existing USB is nonpersistent. This source correction becomes the default when a new ISO is built from this source; the existing ISO and USB have not been rewritten by this correction.

Undo for the current session, if needed:

```sh
gsettings set org.gnome.desktop.background picture-options 'scaled'
```
