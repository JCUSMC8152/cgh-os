# CGH OS 0.2.2 app grid

CGH OS 0.2.2 Ribbon — implementation and test record
Date: October 26, 2026 (America/New_York)

DELIVERED CHANGES
- Replaced the Control Center's horizontal tool rows with an app grid.
- Added sidebar sections: Everyday, Developer, Home Lab, System and Security.
- Gave all 17 tools different artwork and explicit icon mappings; no generic-emblem fallback is used for these tools.
- Added four different security-action icons and tiles.
- Extended the theme to office programs and standard folders, plus distinct welcome and file-scanner identities.
- The theme now has 39 designs, with scalable and small-size variants. Adwaita/hicolor remain fallbacks for icons outside this set.

VERIFIED BEFORE THE EXECUTION ENVIRONMENT RESET
- Local GTK rendering at normal and 200% display scaling.
- Window wrapping at widths of 1060 and 680 pixels, without horizontal tile clipping.
- Accessible tool names and keyboard activation of Terminal.
- Correct launch routes for Email, PDF reader and a user-session virtual machine, using intercepted launches in the local UI test bench.
- Ten existing source/security tests passed.
- Fresh BIOS live-image boot, password setup, console authentication and graphical login in QEMU TCG with 2 vCPUs and 3 GiB RAM.
- The booted theme loaded 96 distinct mapped icon names at 24, 32, 48 and 128 pixels: 384 icon loads.
- All five pinned desktop entries resolved from CGH Ribbon.
- The actual Control Center contained 17 tiles and 17 distinct tool icons.
- The Wayland running-window identity remained cgh-control-center.
- The app grid and distinct standard-folder icons were visually inspected in the running VM.
- All 11 initial image parts were verified against the assembled-image checksum. The documentation correction changed only parts 01 and 11, which were replaced successfully.
- Hybrid BIOS and UEFI boot records were inspected. UEFI runtime was not repeated for this UI-only version.

FINAL DOCUMENTATION CORRECTION
The VM-tested image had source commit 3edc1ede2ddb16521f4904e2170b919ed5c802da. The offline guide was then corrected to describe the sidebar and tile navigation (source commit 0d2ce61b3d344d46681720c9c11e85dc3ee76431). Readback comparison verified that code, icons, symlinks and base image were unchanged; only guide.html and generated build metadata differed. The final download checksum below covers that documentation-corrected image.

RECOVERY VERIFICATION
The execution environment disconnected after visual validation and image upload. The saved final image parts remained intact. The final configuration layer was recovered from part 11, whose SHA-256 matches the assembler manifest. All 434 configuration-file hashes in its build-info manifest were verified; all 427 nongenerated source-overlay files were restored and verified. The code and icon artwork in the restored source therefore match the saved image. The source tests passed again after recovery, and all 17 tool SVGs were independently checked for different names and different content hashes. Raw VM screenshot files were not retained across the reset; the test observations above are recorded from the tool output and visual inspections performed before it.

SCOPE
These checks cover the icon/theme and Control Center change. Complete workflows in every bundled application, physical laptop testing, Secure Boot signing and full security recertification were not performed. This remains a temporary live test session with no installer or persistence.

FINAL IMAGE
CGH-OS-0.2.2-Ribbon-amd64.iso
5221384192 bytes
SHA-256: 2f68d359b1825050d44dfa6d842ab3fd65f00cf71df4c84d24605a626efd9f16
