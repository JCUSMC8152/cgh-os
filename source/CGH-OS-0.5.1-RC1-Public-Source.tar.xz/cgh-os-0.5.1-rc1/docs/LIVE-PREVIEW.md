# CGH OS 0.1.0 live preview

This preview takes a different build path from the initial full live-build recipe:
a checksum- and signature-verified official Debian 13.7 GNOME live image is
remastered with a separate small CGH squashfs layer using live-boot's module list.
It is NOT the completed security-hardened CGH OS distribution.

Base SHA256: e94859a83b305cae5125dc9c6080ced040c59d099ea7381e7f300fd1dba87a17
Debian checksum signature validated against fingerprint:
DF9B9C49EAA9298432589D76DA87E80D6294BE9B
Key fingerprint independently matched Debian's HTTPS verification page.
Custom output is not signed by Debian or by a CGH release key.

Custom ISO SHA256: d425b18352323c474ff5e9a4986a3ceab6d5531330589666a8877ee8aa39a486
Build recipe: scripts/build-preview.sh. Custom files: preview/overlay.
Build tools: xorriso 1.5.6; squashfs-tools 4.6.1, obtained from authenticated
Ubuntu package metadata in the build workspace; no chroot was required.
BIOS/UEFI hybrid boot metadata replayed from upstream via xorriso. BIOS boot
started successfully in QEMU and reached the live root, live-config and GDM.
UEFI and Secure Boot runtime verification remain pending.

The installer boot options are removed. Calamares/install-debian launchers are
hidden and replaced with a preview notice; deliberately using other disk tools
can still change disks. No persistence is configured. No internal disks were
attached in the VM test. No claim is made that firmware or live boot prevents
users from manually mounting internal laptop drives.

The preview includes GNOME, Firefox and LibreOffice from Debian plus the CGH
welcome/control-center code and wallpaper. Developer/Home Lab packs are not
preinstalled. Some full-recipe Everyday tools are not in the upstream base; the
launcher reports unavailable tools rather than claiming they are installed.
The full-recipe firewall/privacy hooks have NOT been applied to this preview.
Do not use this development image for sensitive work.

Delivery: image split into eight parts below the 512 MiB file limit; assembly
script verifies all part hashes and final ISO hash. A complete assembly test
reproduced the exact ISO SHA256. No device-writing code is included: the owner
selects the USB in Linux Mint USB Image Writer. At least an 8 GB USB is advised.
The USB contents are erased when the image is written. Simply copying the ISO
file onto the USB is not sufficient.

Official references:
https://www.debian.org/CD/verify.html
https://www.debian.org/CD/faq/
https://sources.debian.org/src/live-boot/1%3A20250815/manpages/en/live-boot.7
