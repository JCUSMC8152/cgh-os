import json
import unittest
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
class ReleasePackageNames(unittest.TestCase):
 def test_debian13_dns_package(self):
  packs=json.loads((ROOT/'packs.json').read_text())
  self.assertIn('bind9-dnsutils',packs['homelab'])
  self.assertNotIn('dnsutils',packs['homelab'])
  build=set((ROOT/'config/package-lists/integrated.list.chroot').read_text().split())
  self.assertIn('bind9-dnsutils',build)
  self.assertNotIn('dnsutils',build)

 def test_antivirus_updater_not_masked_as_a_server(self):
  hook=(ROOT/'config/hooks/normal/0920-cgh-services.hook.chroot').read_text()
  mask_list=hook.split('for unit in ',1)[1].split('; do',1)[0].split()
  self.assertNotIn('clamav-freshclam.service',mask_list)
  self.assertIn('systemctl unmask clamav-freshclam.service',hook)
  enable=next(x for x in hook.splitlines() if x.startswith('systemctl enable '))
  self.assertIn('clamav-freshclam.service',enable)
