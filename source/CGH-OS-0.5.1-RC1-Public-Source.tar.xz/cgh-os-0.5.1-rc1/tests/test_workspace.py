import json
import os
from pathlib import Path
import sqlite3
import subprocess
import sys
import tempfile
import unittest
from unittest.mock import patch
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'src'))
from workspace_store import Store, atomic_export


class WorkspaceTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.root = Path(self.temp.name)
        self.folder = self.root/'existing files'
        self.folder.mkdir()
        (self.folder/'keep.txt').write_text('unchanged')
        self.path = self.root/'data/workspace.sqlite3'
        self.store = Store(self.path)

    def tearDown(self):
        self.store.close()
        self.temp.cleanup()

    def test_complete_offline_workflow_restart_search_export(self):
        pid = self.store.create('Learning project',self.folder)
        self.store.save_notes(pid,'Build an offline example — café')
        task = self.store.add_task(pid,'Read Python guide')
        self.store.set_done(task,True)
        self.store.close()
        self.store = Store(self.path)
        self.assertEqual(self.store.projects('café')[0][0],pid)
        self.assertEqual(self.store.projects('python')[0][0],pid)
        self.assertEqual(self.store.projects('%'),[])
        export = self.root/'portable.json'
        atomic_export(export,self.store.export())
        result=json.loads(export.read_text())
        self.assertEqual(result['schema'],2)
        self.assertEqual(result['projects'][0]['tasks'],[{'title':'Read Python guide','done':True}])
        self.assertEqual((self.folder/'keep.txt').read_text(),'unchanged')
        self.assertEqual(list(self.folder.iterdir()),[self.folder/'keep.txt'])
        self.assertEqual(export.stat().st_mode & 0o777,0o600)
        self.assertEqual(self.path.stat().st_mode & 0o777,0o600)

    def test_missing_folder_preserves_metadata(self):
        pid=self.store.create('External drive',self.folder)
        self.store.save_notes(pid,'Keep these notes')
        (self.folder/'keep.txt').unlink()
        self.folder.rmdir()
        self.assertEqual(self.store.projects()[0][3],'Keep these notes')
        self.assertIn('External drive',self.store.export())
        with self.assertRaises(FileNotFoundError):
            self.store.create('Missing',self.folder)

    def test_validation_and_foreign_key(self):
        with self.assertRaises(ValueError):self.store.create(' ',self.folder)
        with self.assertRaises(ValueError):self.store.create('File',self.folder/'keep.txt')
        with self.assertRaises(ValueError):self.store.add_task(1,' ')
        with self.assertRaises(sqlite3.IntegrityError):self.store.add_task(999,'Orphan')

    def test_export_failure_preserves_previous_file(self):
        path=self.root/'export.json';path.write_text('previous')
        with patch('workspace_store.os.replace',side_effect=PermissionError('read-only')):
            with self.assertRaises(PermissionError):atomic_export(path,'new')
        self.assertEqual(path.read_text(),'previous')
        self.assertEqual(list(self.root.glob('.cgh-export-*')),[])

    def test_export_does_not_follow_symlink(self):
        path=self.root/'link';path.symlink_to(self.folder/'keep.txt')
        atomic_export(path,'export')
        self.assertFalse(path.is_symlink())
        self.assertEqual((self.folder/'keep.txt').read_text(),'unchanged')

    def test_database_symlink_rejected(self):
        path=self.root/'link';path.symlink_to(self.path)
        with self.assertRaises(ValueError):Store(path)

    def test_newer_schema_not_modified(self):
        other=self.root/'future.sqlite'
        with sqlite3.connect(other) as db:db.execute('PRAGMA user_version=99')
        before=other.read_bytes()
        with self.assertRaises(ValueError):Store(other)
        self.assertEqual(before,other.read_bytes())

    def test_migration_keeps_notes_and_private_backup(self):
        old=self.root/'old.sqlite'
        with sqlite3.connect(old) as db:
            db.execute('CREATE TABLE projects (id INTEGER PRIMARY KEY,name TEXT NOT NULL,folder TEXT NOT NULL,notes TEXT NOT NULL DEFAULT "")')
            db.execute('INSERT INTO projects VALUES (1,"Existing","/missing","Preserved")')
            db.execute('PRAGMA user_version=1')
        migrated=Store(old)
        self.assertEqual(migrated.projects()[0][3],'Preserved')
        migrated.add_task(1,'Next task')
        migrated.close()
        backup=old.with_name(old.name+'.v1-backup')
        self.assertEqual(backup.stat().st_mode & 0o777,0o600)
        with sqlite3.connect(backup) as db:
            self.assertEqual(db.execute('PRAGMA user_version').fetchone()[0],1)
            self.assertEqual(db.execute('SELECT notes FROM projects').fetchone()[0],'Preserved')

    def test_write_failure_is_reported(self):
        pid=self.store.create('Example',self.folder)
        self.store.db.execute('PRAGMA query_only=ON')
        with self.assertRaises(sqlite3.OperationalError):self.store.save_notes(pid,'not saved')
        self.assertEqual(self.store.projects()[0][3],'')

    def test_build_sources_match(self):
        repo=Path(__file__).resolve().parents[1]
        for name in ['workspace.py','workspace_store.py','control_center.py']:
            for base in ['config/includes.chroot/usr/share/cgh-os']:
                self.assertEqual((repo/'src'/name).read_bytes(),(repo/base/name).read_bytes())

    def test_recovered_symlink_metadata(self):
        repo=Path(__file__).resolve().parents[1]
        metadata=json.loads((repo/'docs/recovered-file-metadata.json').read_text())
        for name,target in metadata['symlinks'].items():
            self.assertTrue((repo/name).is_symlink(),name)
            self.assertEqual(os.readlink(repo/name),target)

    def test_recovered_executable_metadata(self):
        repo=Path(__file__).resolve().parents[1]
        metadata=json.loads((repo/'docs/recovered-file-metadata.json').read_text())
        for name in metadata['executables']:
            self.assertTrue((repo/name).stat().st_mode & 0o111,name)
