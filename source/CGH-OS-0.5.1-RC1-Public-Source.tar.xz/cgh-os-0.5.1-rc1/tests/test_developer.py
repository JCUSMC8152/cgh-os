import hashlib
import http.server
import importlib.util
import json
from pathlib import Path
import subprocess
import tempfile
import threading
import unittest
from unittest.mock import patch
import xml.etree.ElementTree as ET

ROOT = Path(__file__).resolve().parents[1]
spec = importlib.util.spec_from_file_location('developer_tools', ROOT/'src/developer_tools.py')
dev = importlib.util.module_from_spec(spec)
spec.loader.exec_module(dev)

class Developer(unittest.TestCase):
    def test_api_local_roundtrip_and_errors_and_redirect(self):
        class Handler(http.server.BaseHTTPRequestHandler):
            def log_message(self, *args): pass
            def do_GET(self):
                self.send_response(302 if self.path == '/redirect' else 404 if self.path == '/missing' else 200)
                if self.path == '/redirect': self.send_header('Location', '/target')
                self.end_headers()
                self.wfile.write(b'hello')
            def do_POST(self):
                self.send_response(200); self.end_headers()
                self.wfile.write(self.rfile.read(int(self.headers['Content-Length'])))
        server = http.server.ThreadingHTTPServer(('127.0.0.1', 0), Handler)
        thread = threading.Thread(target=server.serve_forever, daemon=True); thread.start()
        url = f'http://127.0.0.1:{server.server_port}'
        try:
            self.assertIn('HTTP 200', dev.api_request('GET', url))
            self.assertIn('HTTP 404', dev.api_request('GET', url+'/missing'))
            self.assertIn('HTTP 302', dev.api_request('GET', url+'/redirect'))
            self.assertIn('payload', dev.api_request('POST', url, '{"Content-Type":"text/plain"}', 'payload'))
        finally:
            server.shutdown(); server.server_close(); thread.join()
    def test_web_preview_serves_selected_folder_on_loopback(self):
        import signal
        import re
        import sys
        with tempfile.TemporaryDirectory() as temp:
            folder=Path(temp);(folder/'index.html').write_text('CGH local preview test')
            process=subprocess.Popen([sys.executable,str(ROOT/'src/developer_tools.py'),'--terminal','web',str(folder)],stdout=subprocess.PIPE,stderr=subprocess.DEVNULL,text=True)
            try:
                line=process.stdout.readline()
                url=re.search(r'http://127\.0\.0\.1:\d+',line).group(0)
                self.assertIn('CGH local preview test',dev.api_request('GET',url))
            finally:
                process.send_signal(signal.SIGINT)
                process.wait(timeout=5)
                process.stdout.close()
    def test_invalid_api_input(self):
        for args in [('GET','file:///etc/passwd'), ('GET','http://user:secret@localhost'), ('TRACE','http://localhost'), ('GET','http://localhost','[]'), ('GET','http://localhost','{"X":"a\\r\\nb"}')]:
            with self.assertRaises(ValueError): dev.api_request(*args)
    def test_workspace_and_venv_isolation(self):
        with tempfile.TemporaryDirectory() as temp:
            folder = Path(temp)/'project with spaces'; folder.mkdir()
            with patch.object(dev,'CONFIG',Path(temp)/'settings/config.json'):
                dev.save_settings(str(folder)); self.assertEqual(dev.load_settings()['workspace'],str(folder))
            with patch.object(dev.venv.EnvBuilder,'create') as create, patch.object(dev.subprocess,'run') as run:
                dev.terminal_task('python',str(folder)); create.assert_called_once_with(folder/'.venv')
                self.assertEqual(run.call_args.kwargs['env']['VIRTUAL_ENV'],str(folder/'.venv'))
                self.assertEqual(run.call_args.kwargs['cwd'],folder)
            (folder/'.venv').mkdir()
            with self.assertRaises(ValueError): dev.terminal_task('python',str(folder))
    def test_all_developer_entries_have_distinct_artwork(self):
        overlay = ROOT/'config/includes.chroot'
        entries=list((overlay/'usr/share/applications').glob('cgh-dev-*.desktop'))
        self.assertEqual(len(entries),11)
        hashes=[]
        for entry in entries:
            text=entry.read_text(); icon=next(x[5:] for x in text.splitlines() if x.startswith('Icon='))
            artwork=overlay/f'usr/share/icons/CGH-Ribbon/scalable/apps/{icon}.svg'
            ET.parse(artwork);hashes.append(hashlib.sha256(artwork.read_bytes()).hexdigest())
        self.assertEqual(len(set(hashes)),11)
        self.assertEqual((ROOT/'src/developer_tools.py').read_bytes(),(overlay/'usr/share/cgh-os/developer_tools.py').read_bytes())
    def test_dependencies_in_image(self):
        packages=set((ROOT/'config/package-lists/integrated.list.chroot').read_text().splitlines())
        self.assertTrue(set(json.loads((ROOT/'packs.json').read_text())['developer']) <= packages)
        for file in ('developer_tools.py','developer-guide.html','examples/hello.py','examples/index.html'):
            self.assertTrue((ROOT/'config/includes.chroot/usr/share/cgh-os'/file).is_file())
