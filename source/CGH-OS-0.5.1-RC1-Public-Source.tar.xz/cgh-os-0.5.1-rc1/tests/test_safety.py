import unittest,subprocess,pathlib,json
R=pathlib.Path(__file__).resolve().parents[1]
class Safety(unittest.TestCase):
 def test_invalid_pack_rejected(self):
  p=subprocess.run(['python3',str(R/'src/cgh-pack'),'plan','../../etc'],capture_output=True)
  self.assertNotEqual(p.returncode,0)
 def test_plan_never_elevates(self):
  p=subprocess.run(['python3',str(R/'src/cgh-pack'),'plan','homelab'],capture_output=True,text=True)
  self.assertEqual(p.returncode,0)
  self.assertIn('qemu-system-x86',p.stdout)
 def test_image_sources_match(self):
  self.assertEqual((R/'src/cgh-pack').read_bytes(),(R/'config/includes.chroot/usr/local/bin/cgh-pack').read_bytes())
 def test_no_server_packages_in_everyday(self):
  self.assertFalse({'openssh-server','docker.io','postgresql'} & set(json.loads((R/'packs.json').read_text())['everyday']))

 def test_icon_assets_are_valid_svg(self):
  import xml.etree.ElementTree as ET
  assets=list((R/'config/includes.chroot/usr/share/icons/CGH-Ribbon').rglob('*.svg'))
  self.assertGreater(len(assets),100)
  for asset in assets:
   with self.subTest(asset=str(asset.relative_to(R))):
    self.assertEqual(ET.parse(asset).getroot().tag,'{http://www.w3.org/2000/svg}svg')
