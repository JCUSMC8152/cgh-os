import importlib.util
from pathlib import Path
import tempfile
import unittest

MODULE = Path(__file__).resolve().parents[1] / 'config/includes.chroot/usr/lib/calamares/modules/cgh-finalize/main.py'
spec = importlib.util.spec_from_file_location('cgh_finalize', MODULE)
cleanup = importlib.util.module_from_spec(spec)
spec.loader.exec_module(cleanup)


class InstalledCleanupTests(unittest.TestCase):
    def make_root(self, parent):
        root = Path(parent) / 'target'
        (root / 'etc').mkdir(parents=True)
        (root / 'etc/debian_version').write_text('13\n')
        return root

    def test_removes_live_files_and_keeps_apps_and_data(self):
        with tempfile.TemporaryDirectory() as td:
            root = self.make_root(td)
            for name in cleanup.LIVE_FILES:
                p = root / name
                p.parent.mkdir(parents=True, exist_ok=True)
                p.write_text('live fixture')
            app = root / 'usr/share/cgh-os/budget.py'
            app.parent.mkdir(parents=True, exist_ok=True)
            app.write_text('application fixture')
            home = root / 'home/test/records'
            home.parent.mkdir(parents=True)
            home.write_text('saved user data')
            cleanup.finalize(root)
            self.assertTrue(all(not (root / n).exists() for n in cleanup.LIVE_FILES))
            self.assertEqual(app.read_text(), 'application fixture')
            self.assertEqual(home.read_text(), 'saved user data')

    def test_refuses_host_root(self):
        with self.assertRaises(ValueError):
            cleanup.finalize('/')

    def test_refuses_unmarked_target(self):
        with tempfile.TemporaryDirectory() as td:
            with self.assertRaises(ValueError):
                cleanup.finalize(td)

    def test_refuses_parent_symlink_escape(self):
        with tempfile.TemporaryDirectory() as td:
            root = self.make_root(td)
            outside = Path(td) / 'outside'
            outside.mkdir()
            (root / 'usr').symlink_to(outside, target_is_directory=True)
            with self.assertRaises(ValueError):
                cleanup.finalize(root)

    def test_unlinks_service_link_without_following_it(self):
        with tempfile.TemporaryDirectory() as td:
            root = self.make_root(td)
            outside = Path(td) / 'keep'
            outside.write_text('keep me')
            link = root / cleanup.LIVE_FILES[1]
            link.parent.mkdir(parents=True)
            link.symlink_to(outside)
            cleanup.finalize(root)
            self.assertFalse(link.is_symlink())
            self.assertEqual(outside.read_text(), 'keep me')
