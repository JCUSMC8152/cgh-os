import ast,importlib.util,json,pathlib,unittest
from unittest.mock import patch
R=pathlib.Path(__file__).resolve().parents[1]
spec=importlib.util.spec_from_file_location('lab',R/'src/home_lab.py');lab=importlib.util.module_from_spec(spec);spec.loader.exec_module(lab)
class HomeLab(unittest.TestCase):
 def invoke(self,mode,answers):
  with patch('builtins.input',side_effect=answers),patch.object(lab,'run') as run:
   lab.main(mode);return [x.args[0] for x in run.call_args_list]
 def test_network_does_not_scan(self):
  self.assertEqual(self.invoke('network',[]),[['ip','-brief','address'],['ip','route'],['ip','neigh']])
 def test_diagnostics_reject_options(self):
  self.assertEqual(self.invoke('diagnostics',['1','--help']),[])
 def test_single_port_connect_scan(self):
  self.assertEqual(self.invoke('diagnostics',['4','localhost','443']),[['nmap','-sT','-Pn','-p','443','--host-timeout','15s','localhost']])
 def test_services_are_user_scoped(self):
  self.assertEqual(self.invoke('services',['4','example.service']),[['systemctl','--user','stop','example.service']])
 def test_runtime_source_matches(self):
  self.assertEqual((R/'src/home_lab.py').read_bytes(),(R/'config/includes.chroot/usr/share/cgh-os/home_lab.py').read_bytes())
 def test_menu_assets_and_packages(self):
  tree=ast.parse((R/'src/control_center.py').read_text());tools=next(ast.literal_eval(n.value) for n in tree.body if isinstance(n,ast.Assign) and any(isinstance(x,ast.Name) and x.id=='TOOLS' for x in n.targets))
  self.assertEqual(len(tools['Home Lab']),10)
  for label,args in tools['Home Lab']:self.assertEqual(args[:3],['gnome-terminal','--','/usr/bin/python3'])
  packages=set((R/'config/package-lists/integrated.list.chroot').read_text().split())
  self.assertTrue(set(json.loads((R/'packs.json').read_text())['homelab'])<=packages)
  for icon in ['containers','network','diagnostics','ssh','monitor','storage','services','workbench','guides']:
   self.assertTrue((R/('config/includes.chroot/usr/share/icons/CGH-Ribbon/scalable/apps/cgh-lab-'+icon+'.svg')).exists())
