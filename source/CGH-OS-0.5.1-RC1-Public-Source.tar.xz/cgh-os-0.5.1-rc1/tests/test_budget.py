import sys,unittest,tempfile,sqlite3,json,os
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'src'))
from budget_store import Store,money
class BudgetTests(unittest.TestCase):
 def setUp(self):
  self.temp=tempfile.TemporaryDirectory(); self.root=Path(self.temp.name); self.s=Store(self.root/'data/db'); self.s.setup('Home','USD'); self.a=self.s.account('Checking','1000'); self.b=self.s.account('Savings'); self.c=self.s.category('Food')
 def tearDown(self): self.s.close(); self.temp.cleanup()
 def test_exact(self):
  self.assertEqual(money('0.1','USD')+money('0.2','USD'),30)
  self.assertEqual(money('123','JPY'),123); self.assertEqual(money('1.234','KWD'),1234)
  for x in ('NaN','Infinity','0.001','1e100'):
   with self.assertRaises(ValueError): money(x,'USD')
 def test_transfer(self):
  self.s.entry('2026-10-01','transfer',self.a,'250',target=self.b)
  self.assertEqual([r['balance'] for r in self.s.balances()],[75000,25000]); self.assertEqual(self.s.summary('2026-10')['income'],0); self.assertEqual(self.s.summary('2026-10')['spending'],0)
 def test_plans_dates(self):
  self.s.plan('2024-02','2000',self.c,'300'); self.s.entry('2024-02-29','expense',self.a,'20',category=self.c); self.s.entry('2024-03-01','expense',self.a,'50',category=self.c)
  s=self.s.summary('2024-02'); self.assertEqual(s['spending'],2000); self.assertEqual(s['categories'][0]['remaining'],28000)
  self.s.entry('2026-12-31','income',self.a,'100'); self.assertEqual(self.s.summary('2026-12')['income'],10000); self.assertEqual(self.s.summary('2027-01')['income'],0)
 def test_invalid(self):
  for kw in ({'kind':'transfer','target':self.a},{'kind':'expense'},{'kind':'income','category':self.c},{'kind':'bogus'}):
   with self.assertRaises(ValueError): self.s.entry('2026-10-01',account=self.a,amount='1',**kw)
  for day in ('2026-02-29','2026-2-01','2026-13-01'):
   with self.assertRaises(ValueError): self.s.entry(day,'income',self.a,'1')
  with self.assertRaises(sqlite3.IntegrityError): self.s.entry('2026-10-01','income',999,'1')
  self.assertEqual(self.s.search(),[])
 def test_edit_search_reopen(self):
  key=self.s.entry('2026-10-01','expense',self.a,'10','groceries',category=self.c)
  self.s.entry('2026-10-02','expense',self.a,'12','corrected',category=self.c,entry_id=key)
  self.assertEqual(self.s.search('GROCERIES'),[]); self.assertEqual(self.s.search('correct')[0]['amount'],1200)
  s=Store(self.s.path); self.assertEqual(s.search()[0]['id'],key); s.close()
 def test_bills(self):
  key=self.s.bill('Rent','2026-11-01','900'); self.s.paid(key,True)
  self.assertEqual(self.s.rows('SELECT * FROM bills')[0]['paid'],1); self.assertEqual(self.s.summary('2026-11')['spending'],0)
 def test_export(self):
  p=self.root/'records.json'; self.s.export_to(p); self.assertEqual(json.loads(p.read_text())['format'],'cgh-budget'); self.assertEqual(p.stat().st_mode&0o777,0o600)
  with self.assertRaises(ValueError): self.s.export_to(p)
 def test_backup_restore(self):
  self.s.entry('2026-10-01','income',self.a,'100'); p=self.root/'backup'; self.s.backup(p); dest=self.root/'restored'; Store.restore(p,dest); s=Store(dest)
  self.assertEqual(s.export(),self.s.export()); s.close(); self.assertEqual(dest.stat().st_mode&0o777,0o600)
  with self.assertRaises(ValueError): Store.restore(p,self.s.path)
 def test_future_schema(self):
  p=self.root/'future'; d=sqlite3.connect(p); d.execute('PRAGMA user_version=999'); d.close()
  with self.assertRaises(ValueError): Store(p)
  with self.assertRaises(ValueError): Store.restore(p,self.root/'restored')
 def test_permissions(self):
  self.assertEqual(self.s.path.stat().st_mode&0o777,0o600); self.assertEqual(self.s.path.parent.stat().st_mode&0o777,0o700)
 def test_unrecognized(self):
  p=self.root/'unknown'; d=sqlite3.connect(p); d.execute('CREATE TABLE test(x)'); d.close()
  with self.assertRaises(ValueError):Store(p)
 def test_corrupt_backup(self):
  p=self.root/'bad'; p.write_text('not sqlite')
  with self.assertRaises(sqlite3.DatabaseError):Store.restore(p,self.root/'restored')

 def test_high_precision_not_rounded(self):
  with self.assertRaises(ValueError):money('1.00000000000000000000000000001','USD')
 def test_backup_strips_triggers(self):
  p=self.root/'backup'; self.s.backup(p)
  db=sqlite3.connect(p); db.execute("CREATE TRIGGER unwanted AFTER INSERT ON entries BEGIN DELETE FROM entries; END"); db.close()
  dest=self.root/'restored'; Store.restore(p,dest); s=Store(dest)
  self.assertEqual(s.rows("SELECT name FROM sqlite_master WHERE type='trigger'"),[]); s.close()
 def test_source_overlay(self):
  root=Path(__file__).resolve().parents[1]
  for name in ('budget.py','budget_store.py'):
   self.assertEqual((root/'src'/name).read_bytes(),(root/'config/includes.chroot/usr/share/cgh-os'/name).read_bytes())
 def test_failed_export_preserves_database(self):
  before=self.s.export()
  with self.assertRaises(OSError):self.s.export_to(self.root/'missing/file')
  self.assertEqual(before,self.s.export())
 def test_separate_process_restart(self):
  import subprocess
  self.s.entry('2026-10-01','income',self.a,'123.45')
  result=subprocess.check_output([sys.executable,'-c',"from budget_store import Store; import sys; s=Store(sys.argv[1]); print(s.summary('2026-10')['income']); s.close()",str(self.s.path)],env=dict(os.environ,PYTHONPATH=str(Path(__file__).resolve().parents[1]/'src')),text=True)
  self.assertEqual(result.strip(),'12345')

 def test_totals_never_become_float(self):
  with self.s.db:
   self.s.db.executemany("INSERT INTO entries(date,kind,account,amount,memo) VALUES('2026-10-01','income',?,9000000000000000000,'fixture')",[(self.a,),(self.a,)])
  self.assertEqual(self.s.summary('2026-10')['income'],18000000000000000000)
  self.assertEqual(self.s.balances()[0]['balance'],18000000000000100000)
