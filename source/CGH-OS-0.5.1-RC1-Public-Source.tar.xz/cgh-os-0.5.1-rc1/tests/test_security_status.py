import unittest,sys,pathlib
sys.path.insert(0,str(pathlib.Path(__file__).resolve().parents[1]/'src'))
from security_status import summarize,diagnostics
class SecurityStatus(unittest.TestCase):
 def test_permission_failure_is_unknown(self):
  result=summarize(lambda args:(1,'permission denied'),lambda p:None)
  self.assertEqual(result['firewall'],'unknown')
  self.assertEqual(result['apparmor_kernel'],'unknown')
  self.assertEqual(result['ssh_server'],'unknown')
 def test_disabled_controls_not_reported_active(self):
  def run(args):
   if args[0]=='ufw':return 0,'Status: inactive'
   return 3,'inactive'
  result=summarize(run,lambda p:'N')
  self.assertEqual(result['firewall'],'inactive')
  self.assertEqual(result['apparmor_kernel'],'disabled')
 def test_export_excludes_raw_command_output(self):
  result=diagnostics(lambda args:(1,'secret-host 192.0.2.1 private-name'),lambda p:None)
  text=str(result)
  self.assertNotIn('secret-host',text)
  self.assertNotIn('192.0.2.1',text)
  self.assertNotIn('private-name',text)

class SecureBootValues(unittest.TestCase):
 def test_only_enforced_firmware_combination_is_enabled(self):
  from security_status import secure_boot_values
  self.assertEqual(secure_boot_values(b'\x07\0\0\0\x01',b'\x07\0\0\0\0'),'enabled')
  self.assertEqual(secure_boot_values(b'\x07\0\0\0\x01',b'\x07\0\0\0\x01'),'unknown')
 def test_missing_or_malformed_cannot_claim_enabled(self):
  from security_status import secure_boot_values
  for raw in [None,b'',b'\1',b'\0\0\0\0\2']:
   self.assertEqual(secure_boot_values(raw,b'\x07\0\0\0\0'),'unknown')
 def test_explicitly_off_is_disabled(self):
  from security_status import secure_boot_values
  self.assertEqual(secure_boot_values(b'\x07\0\0\0\0',None),'disabled')
