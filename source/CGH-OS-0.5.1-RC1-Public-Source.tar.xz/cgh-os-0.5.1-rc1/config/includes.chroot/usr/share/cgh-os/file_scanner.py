#!/usr/bin/env python3
"""User-owned local-file scanning; no elevation, upload or automatic deletion."""
import gi,subprocess,threading,pathlib

gi.require_version('Gtk','3.0')
from gi.repository import Gtk,GLib
GLib.set_prgname("cgh-file-scanner")

class Scanner(Gtk.Window):
 def __init__(self):
  super().__init__(title='CGH OS — Scan a file');self.set_default_size(600,320);self.set_icon_name("cgh-file-scan")
  self.proc=None;self.closed=False
  box=Gtk.Box(orientation=Gtk.Orientation.VERTICAL,spacing=16,margin=24);self.add(box)
  note=Gtk.Label(label='Scan one file locally using ClamAV. Files stay on this computer and are never deleted by this tool.',wrap=True,xalign=0);box.pack_start(note,False,False,0)
  self.status=Gtk.Label(label='Choose a file to scan. Signatures update automatically while online. Engine updates use system package management.',wrap=True,xalign=0);box.pack_start(self.status,True,True,0)
  self.choose=Gtk.Button(label='Choose file and scan');self.choose.connect('clicked',self.select);box.pack_start(self.choose,False,False,0)
  self.cancel=Gtk.Button(label='Stop scan');self.cancel.set_sensitive(False);self.cancel.connect('clicked',lambda _:self.stop());box.pack_start(self.cancel,False,False,0)
  note=Gtk.Label(label='No known threats detected does not guarantee that a file is safe. Large files, archives and unreadable content may not be fully checked.',wrap=True,xalign=0);box.pack_start(note,False,False,0)
  self.connect('destroy',self.close)
 def select(self,_):
  d=Gtk.FileChooserDialog(title='Choose a local file',transient_for=self,action=Gtk.FileChooserAction.OPEN)
  d.add_buttons('Cancel',Gtk.ResponseType.CANCEL,'Scan',Gtk.ResponseType.OK)
  chosen=d.get_filename() if d.run()==Gtk.ResponseType.OK else None;d.destroy()
  if not chosen:return
  if not pathlib.Path(chosen).is_file():self.status.set_text('Choose a regular file that you can read.');return
  self.choose.set_sensitive(False);self.cancel.set_sensitive(True);self.status.set_text('Scanning locally… Loading signatures can take a moment.')
  def work():
   message='The scan could not be completed. Check that the file and signature databases are available.'
   try:
    self.proc=subprocess.Popen(['/usr/bin/clamscan','--no-summary','--',chosen],stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
    code=self.proc.wait(timeout=300)
    message={0:'No known threats detected in the selected file.',1:'A threat was detected. Avoid opening or sharing this file. No files were changed.'}.get(code,'The scan stopped or could not be completed. No files were changed.')
   except subprocess.TimeoutExpired:
    self.stop();message='The scan exceeded five minutes and was stopped. The result is incomplete.'
   except OSError:pass
   finally:self.proc=None
   def done():
    if self.closed:return False
    self.status.set_text(message);self.choose.set_sensitive(True);self.cancel.set_sensitive(False);return False
   GLib.idle_add(done)
  threading.Thread(target=work,daemon=True).start()
 def stop(self):
  if self.proc is not None:
   try:self.proc.terminate()
   except ProcessLookupError:pass
 def close(self,_):self.closed=True;self.stop();Gtk.main_quit()

if __name__=='__main__':
 s=Scanner();s.show_all();Gtk.main()
