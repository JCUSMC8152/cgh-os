"""Original CGH Workspace storage. MIT; Copyright 2026 Crawford Group Holdings."""
import json
import os
from pathlib import Path
import sqlite3
import tempfile

SCHEMA = 2


def atomic_export(path, content):
    """Create a private export atomically; never follow an existing destination symlink."""
    path = Path(path)
    fd, temporary = tempfile.mkstemp(prefix='.cgh-export-', dir=path.parent)
    try:
        with os.fdopen(fd, 'w', encoding='utf-8') as stream:
            stream.write(content)
            stream.flush()
            os.fsync(stream.fileno())
        os.replace(temporary, path)
    finally:
        if os.path.exists(temporary):
            os.unlink(temporary)


class Store:
    def __init__(self, path=None):
        self.path = Path(path) if path else Path(os.environ.get('XDG_DATA_HOME', Path.home() / '.local/share')) / 'cgh-os/workspace/projects.sqlite3'
        self.path.parent.mkdir(parents=True, mode=0o700, exist_ok=True)
        if self.path.is_symlink():
            raise ValueError('Workspace database must not be a symbolic link.')
        # Create with private permissions before SQLite opens it.
        fd = os.open(self.path, os.O_CREAT | os.O_RDWR | os.O_NOFOLLOW, 0o600)
        os.close(fd)
        os.chmod(self.path, 0o600)
        self.db = sqlite3.connect(self.path, timeout=3)
        try:
            version = self.db.execute('PRAGMA user_version').fetchone()[0]
            if version > SCHEMA:
                raise ValueError('This workspace was saved by a newer application. Update CGH Workspace.')
            if version and version < SCHEMA:
                backup = self.path.with_name(self.path.name + '.v1-backup')
                if backup.exists():
                    raise ValueError('Migration backup already exists. Preserve it before retrying.')
                fd = os.open(backup, os.O_CREAT | os.O_EXCL | os.O_RDWR, 0o600)
                os.close(fd)
                with sqlite3.connect(backup) as target:
                    self.db.backup(target)
            with self.db:
                if version == 0:
                    self.db.execute('CREATE TABLE projects (id INTEGER PRIMARY KEY, name TEXT NOT NULL, folder TEXT NOT NULL, notes TEXT NOT NULL DEFAULT "")')
                if version < 2:
                    self.db.execute('CREATE TABLE tasks (id INTEGER PRIMARY KEY, project_id INTEGER NOT NULL REFERENCES projects(id), title TEXT NOT NULL, done INTEGER NOT NULL DEFAULT 0 CHECK(done IN (0,1)))')
                self.db.execute('PRAGMA user_version=2')
            self.db.execute('PRAGMA foreign_keys=ON')
        except Exception:
            self.db.close()
            raise

    def close(self):
        self.db.close()

    def projects(self, query=''):
        # Literal substring search, including notes and task titles, without SQL wildcards.
        return self.db.execute('''SELECT id,name,folder,notes FROM projects p WHERE
            instr(lower(name || char(10) || notes || char(10) || folder),lower(?)) > 0
            OR EXISTS (SELECT 1 FROM tasks t WHERE t.project_id=p.id AND instr(lower(t.title),lower(?)) > 0)
            ORDER BY name COLLATE NOCASE,id''', (query, query)).fetchall()

    def create(self, name, folder):
        name = name.strip()
        if not name or len(name) > 200:
            raise ValueError('Enter a project name of 1–200 characters.')
        path = Path(folder).expanduser().resolve(strict=True)
        if not path.is_dir():
            raise ValueError('Choose an existing project folder.')
        with self.db:
            return self.db.execute('INSERT INTO projects(name,folder) VALUES (?,?)', (name, str(path))).lastrowid

    def save_notes(self, project, notes):
        with self.db:
            self.db.execute('UPDATE projects SET notes=? WHERE id=?', (notes, project))

    def tasks(self, project):
        return self.db.execute('SELECT id,title,done FROM tasks WHERE project_id=? ORDER BY id', (project,)).fetchall()

    def add_task(self, project, title):
        title = title.strip()
        if not title or len(title) > 500:
            raise ValueError('Enter a task of 1–500 characters.')
        with self.db:
            return self.db.execute('INSERT INTO tasks(project_id,title) VALUES (?,?)', (project,title)).lastrowid

    def set_done(self, task, done):
        with self.db:
            self.db.execute('UPDATE tasks SET done=? WHERE id=?', (int(bool(done)),task))

    def export(self):
        with self.db:
            projects = [{'name':name,'folder':folder,'notes':notes,'tasks':[{'title':title,'done':bool(done)} for _,title,done in self.tasks(pid)]} for pid,name,folder,notes in self.projects()]
        return json.dumps({'application':'CGH Workspace','schema':SCHEMA,'includes':'Notes, tasks and folder paths; linked files are not copied.','projects':projects}, ensure_ascii=False, indent=2) + '\n'
