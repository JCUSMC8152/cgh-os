#!/usr/bin/env python3
import gi,subprocess,shutil,pathlib,json,threading
from security_status import diagnostics
gi.require_version("Gtk","3.0")
from gi.repository import Gtk,GLib,Gdk
GLib.set_prgname("cgh-control-center")
TOOLS={
 "Everyday":[("CGH Budget",["/usr/bin/python3","/usr/share/cgh-os/budget.py"]),("CGH Workspace",["/usr/bin/python3","/usr/share/cgh-os/workspace.py"]),("Files",["nautilus"]),("Office",["libreoffice"]),("PDF reader",["evince"]),("Email",["thunderbird"]),("Calendar",["gnome-calendar"]),("Passwords",["keepassxc"]),("Backups",["deja-dup"]),("Scan documents",["simple-scan"]),("Media",["vlc"])],
 "Developer":[('Code Editor', ['geany']), ('Terminal', ['gnome-terminal']), ('Git & Repositories', ['python3', '/usr/share/cgh-os/developer_tools.py', 'git']), ('Python Workspace', ['python3', '/usr/share/cgh-os/developer_tools.py', 'python']), ('Web Development', ['python3', '/usr/share/cgh-os/developer_tools.py', 'web']), ('Build Tools', ['python3', '/usr/share/cgh-os/developer_tools.py', 'build']), ('API Tester', ['python3', '/usr/share/cgh-os/developer_tools.py', 'api']), ('Database Tools', ['python3', '/usr/share/cgh-os/developer_tools.py', 'database']), ('Logs & Diagnostics', ['python3', '/usr/share/cgh-os/developer_tools.py', 'logs']), ('Developer Settings', ['python3', '/usr/share/cgh-os/developer_tools.py', 'settings']), ('Documentation & Examples', ['xdg-open', 'file:///usr/share/cgh-os/developer-guide.html'])],
 "Home Lab":[('Virtual machines', ['gnome-terminal', '--', '/usr/bin/python3', '/usr/share/cgh-os/home_lab.py', 'vm']), ('Containers', ['gnome-terminal', '--', '/usr/bin/python3', '/usr/share/cgh-os/home_lab.py', 'containers']), ('Network Explorer', ['gnome-terminal', '--', '/usr/bin/python3', '/usr/share/cgh-os/home_lab.py', 'network']), ('Connection Diagnostics', ['gnome-terminal', '--', '/usr/bin/python3', '/usr/share/cgh-os/home_lab.py', 'diagnostics']), ('Server Connections', ['gnome-terminal', '--', '/usr/bin/python3', '/usr/share/cgh-os/home_lab.py', 'ssh']), ('Lab System Monitor', ['gnome-terminal', '--', '/usr/bin/python3', '/usr/share/cgh-os/home_lab.py', 'monitor']), ('Storage & Backups', ['gnome-terminal', '--', '/usr/bin/python3', '/usr/share/cgh-os/home_lab.py', 'storage']), ('Local Services', ['gnome-terminal', '--', '/usr/bin/python3', '/usr/share/cgh-os/home_lab.py', 'services']), ('Developer Workbench', ['gnome-terminal', '--', '/usr/bin/python3', '/usr/share/cgh-os/home_lab.py', 'workbench']), ('Lab Guides', ['gnome-terminal', '--', '/usr/bin/python3', '/usr/share/cgh-os/home_lab.py', 'guides'])],
 "System":[("System monitor",["gnome-system-monitor"]),("User guide",["xdg-open","file:///usr/share/cgh-os/guide.html"]),("Settings",["gnome-control-center"]),("Software",["gnome-software"])]}
TOOL_ICONS={"CGH Budget":"budget","CGH Workspace":"workspace","Files":"files","Office":"office","PDF reader":"pdf","Email":"email","Calendar":"calendar","Passwords":"passwords","Backups":"backup","Scan documents":"scan","Media":"media","Editor":"editor","Terminal":"terminal","System monitor":"monitor","Virtual machines":"virtual-machines","Storage health":"storage","User guide":"guide","Settings":"settings","Software":"software"}
TOOL_ICONS.update({'Code Editor': 'editor', 'Terminal': 'terminal', 'Git & Repositories': 'git', 'Python Workspace': 'python', 'Web Development': 'web', 'Build Tools': 'build', 'API Tester': 'api', 'Database Tools': 'database', 'Logs & Diagnostics': 'logs', 'Developer Settings': 'developer-settings', 'Documentation & Examples': 'developer-guide'})
DESCRIPTIONS={"CGH Budget":"Private offline budgets, manual accounts, transactions and backups. Original CGH software.","CGH Workspace":"Organize linked folders, notes and tasks locally. Original CGH software.","Files":"Browse and organize files and folders.","Office":"Open the office application suite.","PDF reader":"Read PDF documents.","Email":"Read and write email with Thunderbird.","Calendar":"Manage dates and appointments.","Passwords":"Open the offline password vault.","Backups":"Back up and restore your files.","Scan documents":"Capture documents using a connected scanner.","Media":"Play audio and video.","Editor":"Edit code and plain text.","Terminal":"Use the command line.","System monitor":"Inspect resource use and running processes.","Virtual machines":"Manage virtual machines in your user session.","Storage health":"Inspect drives and storage health.","User guide":"Read the CGH OS guide offline.","Settings":"Adjust system and privacy preferences.","Software":"Browse installed and available applications."}
DESCRIPTIONS.update({'Code Editor': 'Write code and edit project files.', 'Terminal': 'Run commands in your user session.', 'Git & Repositories': 'Choose a repository folder and use Git.', 'Python Workspace': 'Create or reuse a project-local Python environment.', 'Web Development': 'Preview a chosen project on this computer only.', 'Build Tools': 'Inspect compiler tools and open a project terminal.', 'API Tester': 'Send HTTP requests and inspect responses.', 'Database Tools': 'Inspect an existing SQLite database read-only.', 'Logs & Diagnostics': 'Inspect current-user application logs.', 'Developer Settings': 'Choose a default workspace and inspect tool paths.', 'Documentation & Examples': 'Read offline instructions and working examples.'})
SECTIONS={"Everyday":"Your files, communication and daily essentials.","Developer":"Tools for writing, running and inspecting code.","Home Lab":"Virtual machines and storage utilities.","System":"Help, preferences and application management.","Security":"Review observed controls and run local checks."}
TOOL_ICONS.update({'Containers': 'lab-containers', 'Network Explorer': 'lab-network', 'Connection Diagnostics': 'lab-diagnostics', 'Server Connections': 'lab-ssh', 'Lab System Monitor': 'lab-monitor', 'Storage & Backups': 'lab-storage', 'Local Services': 'lab-services', 'Developer Workbench': 'lab-workbench', 'Lab Guides': 'lab-guides'})
DESCRIPTIONS.update({'Containers': 'Run rootless containers and inspect local images.', 'Network Explorer': 'Inspect interfaces, routes and known local neighbors.', 'Connection Diagnostics': 'Test an address or hostname you choose.', 'Server Connections': 'Connect to saved OpenSSH hosts.', 'Lab System Monitor': 'Inspect processes, memory and sensors.', 'Storage & Backups': 'Open disk health or backup tools.', 'Local Services': 'Inspect services and manage your user services.', 'Developer Workbench': 'Open an editor or terminal and inspect developer tools.', 'Lab Guides': 'Read practical Home Lab guides offline.'})
SECTIONS["Home Lab"]="Experiment, inspect your network and manage local lab environments."
CSS=b"""
.cgh-center { background: #0b111a; color: #edf3fc; }
.cgh-center label { color: #edf3fc; }
.cgh-header { background: #101925; color: #edf3fc; border-bottom: 1px solid #354252; }
.cgh-sidebar { background: #101925; border-right: 1px solid #354252; }
.cgh-nav { background: transparent; }
.cgh-nav row { padding: 12px 14px; margin: 3px 8px; border-radius: 8px; color: #dce5f1; }
.cgh-nav row:selected { background: #293544; border-left: 3px solid #e6bd68; }
.cgh-nav row:focus { outline: 2px solid #83c7ff; outline-offset: -2px; }
.cgh-section-title { font-size: 24px; font-weight: bold; }
.cgh-muted { color: #aebed1; }
.cgh-tile { background: #152131; background-image: none; border: 1px solid #3c4e64; border-radius: 14px; padding: 16px 8px 12px; box-shadow: none; }
.cgh-tile:hover { background: #203249; border-color: #a6c8f0; }
.cgh-tile:active { background: #2b4059; }
.cgh-tile:focus { outline: 3px solid #f1c76d; outline-offset: -4px; border-color: #f1c76d; }
.cgh-tile:disabled { background: #111b28; border-color: #344050; }
.cgh-tile:disabled label { color: #9aa9bc; }
.cgh-tile-name { font-size: 14px; font-weight: 600; }
.cgh-center flowboxchild { padding: 3px; }
"""
class Center(Gtk.Window):
 def __init__(self):
  super().__init__(title="CGH OS — Control Center")
  self.set_default_size(1060,760);self.set_icon_name("cgh-control-center")
  self.get_style_context().add_class('cgh-center')
  provider=Gtk.CssProvider();provider.load_from_data(CSS)
  Gtk.StyleContext.add_provider_for_screen(Gdk.Screen.get_default(),provider,Gtk.STYLE_PROVIDER_PRIORITY_APPLICATION)
  self.css_provider=provider
  header=Gtk.HeaderBar(title='CGH OS',subtitle='Control Center');header.set_show_close_button(True)
  header.get_style_context().add_class('cgh-header');self.set_titlebar(header)
  layout=Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL);self.add(layout)
  side=Gtk.Box(orientation=Gtk.Orientation.VERTICAL,spacing=16);side.set_size_request(176,-1)
  side.get_style_context().add_class('cgh-sidebar');layout.pack_start(side,False,False,0)
  brand=Gtk.Label(label='WORKSPACE',xalign=0,margin_start=22,margin_top=24,margin_bottom=4)
  brand.get_style_context().add_class('cgh-muted');side.pack_start(brand,False,False,0)
  self.navigation=Gtk.ListBox();self.navigation.set_selection_mode(Gtk.SelectionMode.SINGLE)
  self.navigation.get_style_context().add_class('cgh-nav');side.pack_start(self.navigation,False,False,0)
  footer=Gtk.Label(label='CGH OS',xalign=0,margin_start=22,margin_bottom=22)
  footer.get_style_context().add_class('cgh-muted');side.pack_end(footer,False,False,0)
  self.stack=Gtk.Stack();self.stack.set_transition_type(Gtk.StackTransitionType.NONE)
  self.stack.set_homogeneous(False);layout.pack_start(self.stack,True,True,0)
  self.tool_tiles={};self.flows={}
  for category,tools in TOOLS.items():
   self.stack.add_named(self.tool_page(category,tools),category)
  security=self.security_page();self.stack.add_named(security,'Security')
  for category in SECTIONS:
   row=Gtk.ListBoxRow();row.page=category;row.add(Gtk.Label(label=category,xalign=0));self.navigation.add(row)
  self.navigation.connect('row-selected',self.select_section)
  self.navigation.select_row(self.navigation.get_row_at_index(0))
 def select_section(self,_,row):
  if row:self.stack.set_visible_child_name(row.page)
 def new_flow(self):
  flow=Gtk.FlowBox();flow.set_selection_mode(Gtk.SelectionMode.NONE)
  flow.set_homogeneous(True);flow.set_min_children_per_line(1);flow.set_max_children_per_line(4)
  flow.set_row_spacing(12);flow.set_column_spacing(12);flow.set_valign(Gtk.Align.START)
  return flow
 def make_tile(self,label,icon,description,available=True):
  button=Gtk.Button();button.set_relief(Gtk.ReliefStyle.NONE);button.set_size_request(148,150)
  button.get_style_context().add_class('cgh-tile')
  content=Gtk.Box(orientation=Gtk.Orientation.VERTICAL,spacing=12)
  image=Gtk.Image.new_from_icon_name('cgh-'+icon,Gtk.IconSize.DIALOG);image.set_pixel_size(64)
  content.pack_start(image,False,False,0)
  name=Gtk.Label(label=label);name.set_line_wrap(True);name.set_max_width_chars(17)
  name.set_justify(Gtk.Justification.CENTER);name.get_style_context().add_class('cgh-tile-name')
  content.pack_start(name,False,False,0)
  if not available:
   note=Gtk.Label(label='Not installed');note.get_style_context().add_class('cgh-muted');content.pack_start(note,False,False,0)
  button.add(content);button.set_sensitive(available);button.set_tooltip_text(description+(' Not installed.' if not available else ''))
  button.get_accessible().set_name(label);button.get_accessible().set_description(description)
  button.icon_name='cgh-'+icon;button.tool_name=label
  return button
 def tool_page(self,category,tools):
  scroll=Gtk.ScrolledWindow();scroll.set_policy(Gtk.PolicyType.NEVER,Gtk.PolicyType.AUTOMATIC)
  page=Gtk.Box(orientation=Gtk.Orientation.VERTICAL,spacing=14,margin=22);scroll.add(page)
  title=Gtk.Label(label=category,xalign=0);title.get_style_context().add_class('cgh-section-title');page.pack_start(title,False,False,0)
  subtitle=Gtk.Label(label=SECTIONS[category],xalign=0,wrap=True);subtitle.get_style_context().add_class('cgh-muted');page.pack_start(subtitle,False,False,0)
  flow=self.new_flow();self.flows[category]=flow;page.pack_start(flow,False,False,0)
  for label,argv in tools:
   tile=self.make_tile(label,TOOL_ICONS[label],DESCRIPTIONS[label],bool(shutil.which(argv[0])))
   tile.connect('clicked',self.launch,argv);flow.add(tile);self.tool_tiles[label]=tile
  return scroll
 def security_page(self):
  box=Gtk.Box(orientation=Gtk.Orientation.VERTICAL,spacing=12,margin=20)
  heading=Gtk.Label(label='Security',xalign=0);heading.get_style_context().add_class('cgh-section-title');box.pack_start(heading,False,False,0)
  box.pack_start(Gtk.Label(label='Observed controls — an unavailable check is never treated as protection.',wrap=True,xalign=0),False,False,0)
  grid=Gtk.Grid(column_spacing=20,row_spacing=14)
  labels={}
  names={'firewall':'Inbound firewall','apparmor_kernel':'Application isolation support','ssh_server':'Remote SSH server','security_updates_timer':'Security update schedule','root_filesystem':'Current session storage','disk_encryption':'Disk encryption','secure_boot':'Secure Boot'}
  for row,(key,title) in enumerate(names.items()):
   grid.attach(Gtk.Label(label=title,xalign=0),0,row,1,1)
   label=Gtk.Label(label='Checking…',wrap=True,xalign=0);label.set_max_width_chars(44);grid.attach(label,1,row,1,1);labels[key]=label
  box.pack_start(grid,False,False,0)
  self.last_diagnostics=None
  auth_note=Gtk.Label(label="",wrap=True,xalign=0);box.pack_start(auth_note,False,False,0)
  def refresh(button,privileged=False):
   button.set_sensitive(False)
   def worker():
    report=diagnostics();auth_failed=False
    if privileged:
     try:
      proc=subprocess.run(['pkexec','/usr/local/bin/cgh-security'],capture_output=True,text=True,timeout=90)
      if proc.returncode==0:
       candidate=json.loads(proc.stdout)
       if candidate.get('schema')==1 and isinstance(candidate.get('controls'),dict):report=candidate
       else:auth_failed=True
      else:auth_failed=True
     except (OSError,ValueError,subprocess.TimeoutExpired):auth_failed=True
    def display():
     auth_note.set_text('Administrator verification was canceled or unavailable.' if auth_failed else '')
     self.last_diagnostics=report
     for key,label in labels.items():
      value=report['controls'][key]
      if value=='unknown':value='Administrator verification needed or check unavailable'
      elif key=='apparmor_kernel' and value=='enabled':value='Kernel support active; this alone does not prove enforcement'
      elif key=='ssh_server' and value=='inactive':value='Not running'
      elif key=='secure_boot':value={'enabled':'Enabled by firmware; this does not verify every OS file','disabled':'Disabled by firmware'}.get(value,'Verification unavailable')
      label.set_text(value)
     button.set_sensitive(True)
     return False
    GLib.idle_add(display)
   threading.Thread(target=worker,daemon=True).start()
  actions=self.new_flow();box.pack_start(actions,False,False,0)
  scan=self.make_tile('Scan a file','file-scan','Scan a local file with ClamAV. Files stay on this computer.');scan.connect('clicked',self.launch,['/usr/bin/python3','/usr/share/cgh-os/file_scanner.py']);actions.add(scan)
  b=self.make_tile('Refresh status','refresh','Read the current security observations again.');b.connect('clicked',refresh);actions.add(b)
  admin=self.make_tile('Verify controls','verify','Administrator password required to verify protected controls.');admin.connect('clicked',lambda button:refresh(button,True));actions.add(admin)
  def export(_):
   if self.last_diagnostics is None:return
   d=Gtk.FileChooserDialog(title='Save basic diagnostics',transient_for=self,action=Gtk.FileChooserAction.SAVE)
   d.add_buttons('Cancel',Gtk.ResponseType.CANCEL,'Save',Gtk.ResponseType.OK);d.set_current_name('cgh-diagnostics.json');d.set_do_overwrite_confirmation(True)
   if d.run()==Gtk.ResponseType.OK:
    try:pathlib.Path(d.get_filename()).write_text(json.dumps(self.last_diagnostics,indent=2)+'\n')
    except OSError:
     e=Gtk.MessageDialog(transient_for=self,modal=True,message_type=Gtk.MessageType.ERROR,buttons=Gtk.ButtonsType.OK,text='The diagnostics file could not be saved.');e.run();e.destroy()
   d.destroy()
  e=self.make_tile('Save diagnostics','export','Save basic diagnostics without usernames, addresses or full logs.');e.connect('clicked',export);actions.add(e)
  box.pack_start(Gtk.Label(label='Protected verification requires your administrator password. Saved diagnostics exclude usernames, addresses and full logs.',wrap=True,xalign=0),False,False,0)
  refresh(b)
  scroll=Gtk.ScrolledWindow();scroll.set_policy(Gtk.PolicyType.NEVER,Gtk.PolicyType.AUTOMATIC);scroll.add(box);return scroll
 def launch(self,button,argv):
  try:subprocess.Popen(argv)
  except OSError as exc:
   d=Gtk.MessageDialog(transient_for=self,modal=True,message_type=Gtk.MessageType.ERROR,buttons=Gtk.ButtonsType.OK,text='The application could not start.');d.run();d.destroy()
if __name__=='__main__':
 w=Center();w.connect('destroy',Gtk.main_quit);w.show_all();Gtk.main()
