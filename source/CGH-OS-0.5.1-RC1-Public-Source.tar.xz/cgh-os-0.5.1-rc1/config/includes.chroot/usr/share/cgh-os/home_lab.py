#!/usr/bin/env python3
"""Interactive, unprivileged Home Lab console. No shell interpolation."""
import os,pathlib,re,shutil,subprocess,sys

def run(argv):
 if not shutil.which(argv[0]):
  print('Required tool is unavailable:',argv[0]);return
 try:subprocess.run(argv,check=False)
 except (OSError,KeyboardInterrupt) as exc:print('Stopped:',exc)

def target(prompt):
 value=input(prompt).strip()
 if not re.fullmatch(r'[A-Za-z0-9][A-Za-z0-9.:_-]{0,252}',value):
  print('Enter a hostname or IP address without command options.');return None
 return value

def resources():
 mem=next((int(x.split()[1])//1024 for x in pathlib.Path('/proc/meminfo').read_text().splitlines() if x.startswith('MemAvailable:')),0)
 print(f'Available RAM: {mem} MiB; free home storage: {shutil.disk_usage(pathlib.Path.home()).free//(1024**3)} GiB')
 print('Hardware virtualization:', 'available' if os.access('/dev/kvm',os.R_OK|os.W_OK) else 'unavailable; VMs may be slow')
 print('Allow memory and storage for both host and guest. Guest operating systems and container images are obtained separately.')
 return input('Continue? [y/N] ').lower()=='y'

def main(mode):
 print('CGH OS — Home Lab\n')
 if mode=='vm':
  if resources():run(['virt-manager','--connect','qemu:///session'])
 elif mode=='containers':
  if resources():
   print('Rootless containers. Pulling/running images can use network and storage.\n1 List containers  2 List images  3 Pull image  4 Run temporary interactive container')
   choice=input('Choice: ')
   if choice in ['1','2']:run(['podman','ps','-a'] if choice=='1' else ['podman','images'])
   elif choice in ['3','4']:
    name=input('Image reference: ').strip()
    if re.fullmatch(r'[A-Za-z0-9][A-Za-z0-9_./:@-]{0,250}',name):run(['podman','pull',name] if choice=='3' else ['podman','run','--rm','-it','--security-opt=no-new-privileges',name])
 elif mode=='network':
  print('Known neighbors are devices observed locally; this is not a complete device inventory.')
  for args in [['ip','-brief','address'],['ip','route'],['ip','neigh']]:run(args)
 elif mode=='diagnostics':
  print('1 Ping  2 DNS lookup  3 Route  4 Test TCP port on a host you own or administer')
  choice=input('Choice: ');host=target('Host/IP: ')
  if host and choice in ['1','2','3']:run({'1':['ping','-c','4',host],'2':['dig','+time=3','+tries=1',host],'3':['tracepath',host]}[choice])
  elif host and choice=='4':
   port=input('TCP port (1–65535): ')
   if port.isdigit() and 1<=int(port)<=65535:run(['nmap','-sT','-Pn','-p',port,'--host-timeout','15s',host])
 elif mode=='ssh':
  print('Saved hosts use ~/.ssh/config. Passwords are never saved by this launcher.\n1 Connect  2 Edit saved hosts')
  if input('Choice: ')=='2':
   directory=pathlib.Path.home()/'.ssh';directory.mkdir(mode=0o700,exist_ok=True)
   config=directory/'config';config.touch(mode=0o600,exist_ok=True);run(['geany',str(config)])
  else:
   host=target('Host or saved alias: ')
   if host:run(['ssh',host])
 elif mode=='monitor':
  run(['sensors']);run(['htop'])
 elif mode=='storage':
  print('1 Disk health and storage  2 Backups  3 Restic help\nBackups need a destination. A live session is temporary unless saved elsewhere.')
  args={'1':['gnome-disks'],'2':['deja-dup'],'3':['restic','help']}.get(input('Choice: '))
  if args:run(args)
 elif mode=='services':
  print('1 List user services  2 List system services  3 Start user service  4 Stop user service  5 Restart user service')
  choice=input('Choice: ')
  if choice in ['1','2']:run(['systemctl']+(['--user'] if choice=='1' else [])+['--no-pager','list-units','--type=service','--all'])
  elif choice in ['3','4','5']:
   unit=input('User service name ending .service: ').strip()
   if re.fullmatch(r'[A-Za-z0-9][A-Za-z0-9_.@-]*\.service',unit):run(['systemctl','--user',{'3':'start','4':'stop','5':'restart'}[choice],unit])
 elif mode=='workbench':
  print('1 Editor  2 Terminal  3 Tool versions')
  choice=input('Choice: ')
  if choice in ['1','2']:run(['geany'] if choice=='1' else ['gnome-terminal'])
  elif choice=='3':
   for command in ['git','python3','node','npm','podman']:run([command,'--version'])
 elif mode=='guides':run(['xdg-open','file:///usr/share/cgh-os/home-lab.html'])
 else:raise SystemExit('Unknown Home Lab tool')

if __name__=='__main__':
 try:main(sys.argv[1]);input('\nPress Enter to close. ')
 except (EOFError,KeyboardInterrupt):pass
