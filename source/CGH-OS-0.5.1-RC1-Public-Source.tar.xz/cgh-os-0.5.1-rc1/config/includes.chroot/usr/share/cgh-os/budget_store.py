"""Original CGH local budgeting model. MIT; Copyright 2026 CGH LLC."""
import calendar
import datetime as dt
import decimal
import json
import os
from pathlib import Path
import sqlite3
import tempfile

CURRENCIES = {'USD': 2, 'EUR': 2, 'GBP': 2, 'CAD': 2, 'AUD': 2, 'JPY': 0, 'KWD': 3}
SCHEMA = 1

def money(text, currency):
    if currency not in CURRENCIES: raise ValueError('Unsupported currency')
    try: value = decimal.Decimal(str(text))
    except decimal.InvalidOperation: raise ValueError('Enter a decimal amount')
    if not value.is_finite(): raise ValueError('Amount must be finite')
    if len(str(text)) > 128: raise ValueError('Amount too long')
    with decimal.localcontext() as context:
        context.prec = max(150, len(value.as_tuple().digits) + 10)
        scaled = value * (10 ** CURRENCIES[currency])
    if scaled != scaled.to_integral_value(): raise ValueError('Too many decimal places')
    if abs(scaled) > 10**14: raise ValueError('Amount too large')
    return int(scaled)

def date(value):
    parsed = dt.date.fromisoformat(value)
    if parsed.isoformat() != value: raise ValueError('Use YYYY-MM-DD')
    return value

def month(value):
    date(value + '-01')
    return value

def private_write(path, data):
    path = Path(path)
    if path.exists(): raise ValueError('Choose a new filename; existing files are preserved')
    fd, temp = tempfile.mkstemp(dir=path.parent, prefix='.cgh-budget-')
    try:
        with os.fdopen(fd, 'wb') as stream:
            stream.write(data); stream.flush(); os.fsync(stream.fileno())
        os.link(temp, path)  # no-clobber publication
    finally: os.unlink(temp)

class Store:
    def __init__(self, path=None):
        self.path = Path(path or Path(os.environ.get('XDG_DATA_HOME', Path.home()/'.local/share'))/'cgh-os/budget/budget.sqlite3')
        self.path.parent.mkdir(parents=True, exist_ok=True, mode=0o700)
        if self.path.is_symlink(): raise ValueError('Database cannot be a symbolic link')
        fd = os.open(self.path, os.O_CREAT | os.O_RDWR, 0o600); os.close(fd)
        os.chmod(self.path, 0o600)
        self.db = sqlite3.connect(self.path)
        self.db.row_factory = sqlite3.Row
        self.db.execute('PRAGMA foreign_keys=ON')
        version = self.db.execute('PRAGMA user_version').fetchone()[0]
        if version > SCHEMA:
            self.db.close(); raise ValueError('Database uses a newer schema; use a newer CGH Budget')
        if version == 0:
            # A nonempty unknown DB is never treated as a new budget.
            if self.db.execute("SELECT name FROM sqlite_master WHERE type='table'").fetchone():
                self.db.close(); raise ValueError('Unrecognized database')
            self.db.executescript('''
            CREATE TABLE budget(id INTEGER PRIMARY KEY CHECK(id=1), name TEXT NOT NULL, currency TEXT NOT NULL);
            CREATE TABLE accounts(id INTEGER PRIMARY KEY, name TEXT NOT NULL UNIQUE, opening INTEGER NOT NULL);
            CREATE TABLE categories(id INTEGER PRIMARY KEY, name TEXT NOT NULL UNIQUE);
            CREATE TABLE plans(month TEXT NOT NULL, category INTEGER NOT NULL REFERENCES categories(id), amount INTEGER NOT NULL CHECK(amount>=0), PRIMARY KEY(month,category));
            CREATE TABLE income_plans(month TEXT PRIMARY KEY, amount INTEGER NOT NULL CHECK(amount>=0));
            CREATE TABLE entries(id INTEGER PRIMARY KEY, date TEXT NOT NULL, kind TEXT NOT NULL CHECK(kind IN ('income','expense','transfer')), account INTEGER NOT NULL REFERENCES accounts(id), target INTEGER REFERENCES accounts(id), category INTEGER REFERENCES categories(id), amount INTEGER NOT NULL CHECK(amount>0), memo TEXT NOT NULL, CHECK((kind='transfer' AND target IS NOT NULL AND target<>account AND category IS NULL) OR (kind='expense' AND target IS NULL AND category IS NOT NULL) OR (kind='income' AND target IS NULL AND category IS NULL)));
            CREATE TABLE bills(id INTEGER PRIMARY KEY, name TEXT NOT NULL, due TEXT NOT NULL, amount INTEGER NOT NULL CHECK(amount>0), paid INTEGER NOT NULL DEFAULT 0 CHECK(paid IN (0,1)));
            PRAGMA user_version=1;
            ''')
    def close(self): self.db.close()
    def rows(self, sql, args=()): return [dict(r) for r in self.db.execute(sql, args)]
    def config(self):
        row = self.db.execute('SELECT * FROM budget').fetchone()
        return dict(row) if row else None
    def setup(self, name, currency):
        if not name.strip() or currency not in CURRENCIES: raise ValueError('Name and supported currency required')
        with self.db: self.db.execute('INSERT INTO budget VALUES(1,?,?)', (name.strip(),currency))
    def amount(self, value, positive=False):
        config = self.config()
        if not config: raise ValueError('Create a budget first')
        result = money(value, config['currency'])
        if positive and result <= 0: raise ValueError('Amount must be positive')
        return result
    def account(self, name, opening='0'):
        if not name.strip(): raise ValueError('Account name required')
        with self.db: return self.db.execute('INSERT INTO accounts(name,opening) VALUES(?,?)',(name.strip(), self.amount(opening))).lastrowid
    def category(self, name):
        if not name.strip(): raise ValueError('Category name required')
        with self.db: return self.db.execute('INSERT INTO categories(name) VALUES(?)',(name.strip(),)).lastrowid
    def plan(self, period, income, category, amount):
        month(period); inc=self.amount(income); amt=self.amount(amount)
        if min(inc,amt)<0: raise ValueError('Plans must be nonnegative')
        with self.db:
            self.db.execute('INSERT OR REPLACE INTO income_plans VALUES(?,?)',(period,inc))
            self.db.execute('INSERT OR REPLACE INTO plans VALUES(?,?,?)',(period,category,amt))
    def entry(self, day, kind, account, amount, memo='', category=None, target=None, entry_id=None):
        date(day); amt=self.amount(amount,True)
        if kind not in ('income','expense','transfer'): raise ValueError('Unknown transaction kind')
        if kind=='transfer':
            if target is None or target==account or category is not None: raise ValueError('Choose distinct transfer accounts; no category')
        elif target is not None or (kind=='expense' and category is None) or (kind=='income' and category is not None): raise ValueError('Invalid transaction fields')
        values=(day,kind,account,target,category,amt,memo)
        with self.db:
            if entry_id is None: return self.db.execute('INSERT INTO entries(date,kind,account,target,category,amount,memo) VALUES(?,?,?,?,?,?,?)',values).lastrowid
            if self.db.execute('UPDATE entries SET date=?,kind=?,account=?,target=?,category=?,amount=?,memo=? WHERE id=?',values+(entry_id,)).rowcount!=1: raise ValueError('Transaction no longer exists')
            return entry_id
    def search(self, query=''):
        return self.rows("SELECT * FROM entries WHERE instr(lower(memo),lower(?))>0 OR instr(date,?)>0 ORDER BY date DESC,id DESC",(query,query))
    def bill(self,name,due,amount):
        if not name.strip(): raise ValueError('Bill name required')
        date(due)
        with self.db: return self.db.execute('INSERT INTO bills(name,due,amount) VALUES(?,?,?)',(name.strip(),due,self.amount(amount,True))).lastrowid
    def paid(self, bill_id, paid):
        with self.db: self.db.execute('UPDATE bills SET paid=? WHERE id=?',(int(bool(paid)),bill_id))
    def summary(self, period):
        month(period); start=period+'-01'; y,m=map(int,period.split('-')); end=f'{y:04d}-{m:02d}-{calendar.monthrange(y,m)[1]:02d}'
        entries=self.rows('SELECT * FROM entries WHERE date BETWEEN ? AND ?',(start,end))
        totals={kind:sum(e['amount'] for e in entries if e['kind']==kind) for kind in ('income','expense')}
        plans={p['category']:p['amount'] for p in self.rows('SELECT * FROM plans WHERE month=?',(period,))}
        categories=self.rows('SELECT * FROM categories ORDER BY name')
        for c in categories:
            c['planned']=plans.get(c['id'],0)
            c['spent']=sum(e['amount'] for e in entries if e['kind']=='expense' and e['category']==c['id'])
            c['remaining']=c['planned']-c['spent']
        return {'income':totals['income'],'spending':totals['expense'],'planned_income':self.db.execute('SELECT coalesce((SELECT amount FROM income_plans WHERE month=?),0)',(period,)).fetchone()[0], 'categories':categories}
    def balances(self):
        accounts=self.rows('SELECT * FROM accounts')
        entries=self.rows('SELECT * FROM entries')
        for a in accounts:
            a['balance']=a['opening']+sum((e['amount'] if e['kind']=='income' else -e['amount']) for e in entries if e['account']==a['id'])+sum(e['amount'] for e in entries if e['target']==a['id'])
        return accounts
    def export(self):
        return {'format':'cgh-budget','schema':SCHEMA, **{t:self.rows('SELECT * FROM '+t) for t in ('budget','accounts','categories','plans','income_plans','entries','bills')}}
    def export_to(self,path): private_write(path,(json.dumps(self.export(),indent=2,ensure_ascii=False)+'\n').encode())
    def backup(self,path):
        fd,temp=tempfile.mkstemp(dir=Path(path).parent); os.close(fd)
        try:
            dest=sqlite3.connect(temp)
            try: self.db.backup(dest)
            finally: dest.close()
            private_write(path,Path(temp).read_bytes())
        finally: os.unlink(temp)
    @staticmethod
    def restore(source, destination):
        source=Path(source); destination=Path(destination)
        if destination.exists(): raise ValueError('Restore requires a new destination; current data is preserved')
        db=sqlite3.connect(source.resolve().as_uri()+'?mode=ro',uri=True)
        try:
            if db.execute('PRAGMA user_version').fetchone()[0]!=SCHEMA: raise ValueError('Unsupported backup schema')
            if db.execute('PRAGMA integrity_check').fetchone()[0]!='ok' or db.execute('PRAGMA foreign_key_check').fetchone(): raise ValueError('Invalid backup')
            # Validate shape and finance invariants by inspecting every record.
            data={t:[dict(zip([d[0] for d in cur.description],r)) for r in cur] for t in ('budget','accounts','categories','plans','income_plans','entries','bills') for cur in [db.execute('SELECT * FROM '+t)]}
            if len(data['budget'])!=1 or data['budget'][0]['currency'] not in CURRENCIES: raise ValueError('Invalid budget')
            for e in data['entries']:
                date(e['date'])
                if type(e['amount']) is not int or e['amount']<=0 or e['kind'] not in ('income','expense','transfer'): raise ValueError('Invalid entry')
                if e['kind']=='transfer' and (e['target'] is None or e['target']==e['account'] or e['category'] is not None): raise ValueError('Invalid transfer')
                if e['kind']=='expense' and (e['category'] is None or e['target'] is not None): raise ValueError('Invalid expense')
                if e['kind']=='income' and (e['category'] is not None or e['target'] is not None): raise ValueError('Invalid income')
            for p in data['plans']+data['income_plans']:
                month(p['month'])
                if type(p['amount']) is not int or p['amount']<0: raise ValueError('Invalid plan')
            for b in data['bills']:
                date(b['due'])
                if type(b['amount']) is not int or b['amount']<=0 or b['paid'] not in (0,1): raise ValueError('Invalid bill')
            for a in data['accounts']:
                if type(a['opening']) is not int or not a['name'].strip(): raise ValueError('Invalid account')
            # Rebuild canonical tables so backup-supplied triggers/views are never installed.
            fd,temp=tempfile.mkstemp(dir=destination.parent)
            os.close(fd)
            try:
                restored=Store(temp)
                try:
                    with restored.db:
                        for table, records in data.items():
                            columns=[r[1] for r in restored.db.execute('PRAGMA table_info('+table+')')]
                            for record in records:
                                if set(record)!=set(columns): raise ValueError('Invalid backup columns')
                                restored.db.execute('INSERT INTO '+table+' VALUES('+','.join('?' for _ in columns)+')',[record[c] for c in columns])
                finally: restored.close()
                private_write(destination,Path(temp).read_bytes())
            finally: os.unlink(temp)
        finally: db.close()
