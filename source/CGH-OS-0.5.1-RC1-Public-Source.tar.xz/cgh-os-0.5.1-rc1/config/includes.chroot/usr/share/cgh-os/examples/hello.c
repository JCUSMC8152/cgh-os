#include <stdio.h>
int main(void) { puts("Hello from CGH OS C!"); return 0; }
