"""Read-only observations: unknown is never treated as protection."""
import json,platform,pathlib,subprocess,shutil,os

def command(argv):
 try:
  r=subprocess.run(argv,capture_output=True,text=True,timeout=8,check=False,env={**os.environ,"LC_ALL":"C"})
  return r.returncode,r.stdout.strip()
 except (OSError,subprocess.TimeoutExpired):return None,''

def unit_state(name,run=command):
 code,value=run(['systemctl','is-active',name])
 if code is None or value not in {'active','inactive','failed','activating','deactivating'}:return 'unknown'
 return value

def secure_boot_values(secure,setup):
 def value(raw):
  if raw is None or len(raw)!=5 or raw[4] not in (0,1):return None
  return raw[4]
 sb,sm=value(secure),value(setup)
 if sb==0:return 'disabled'
 if sb==1 and sm==0:return 'enabled'
 return 'unknown'

def firmware_secure_boot():
 root=pathlib.Path('/sys/firmware/efi/efivars')
 def read(name):
  try:return (root/(name+'-8be4df61-93ca-11d2-aa0d-00e098032b8c')).read_bytes()
  except OSError:return None
 return secure_boot_values(read('SecureBoot'),read('SetupMode'))

def summarize(run=command,read=None):
 if read is None:
  def read(p):
   try:return pathlib.Path(p).read_text().strip()
   except OSError:return None
 checks={}
 rc,text=run(['ufw','status'])
 checks['firewall']='active' if rc==0 and text.startswith('Status: active') else ('inactive' if rc==0 and text.startswith('Status: inactive') else 'unknown')
 aa=read('/sys/module/apparmor/parameters/enabled')
 checks['apparmor_kernel']='enabled' if aa=='Y' else ('disabled' if aa=='N' else 'unknown')
 checks['ssh_server']=unit_state('ssh.service',run)
 checks['security_updates_timer']=unit_state('apt-daily-upgrade.timer',run)
 rc,text=run(['findmnt','-n','-o','FSTYPE','/'])
 checks['root_filesystem']=text if rc==0 and text in {'overlay','ext4','btrfs','xfs','tmpfs'} else 'unknown'
 checks['disk_encryption']='Temporary live session; persistent destinations need separate assessment' if checks['root_filesystem']=='overlay' else 'Persistent storage encryption not assessed'
 checks['secure_boot']=firmware_secure_boot()
 checks['overall']='no blanket security rating; each control needs separate evidence'
 return checks

def diagnostics(run=command,read=None):
 # Explicit allowlist. No usernames, hostnames, IPs, serials, files or full logs.
 return {'schema':1,'architecture':platform.machine(),'controls':summarize(run,read)}
if __name__=='__main__':print(json.dumps(diagnostics(),indent=2))
