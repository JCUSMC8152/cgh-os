#!/usr/bin/python3
"""Original CGH Budget GTK3 interface; MIT, Copyright 2026 CGH LLC."""
import datetime
import json
import sys
from pathlib import Path
try:
    import gi
    gi.require_version('Gtk','3.0')
    from gi.repository import Gtk, Gdk
except (ImportError,ValueError):
    sys.exit('CGH Budget requires python3-gi and gir1.2-gtk-3.0. Install the Debian package dependencies.')
from budget_store import Store, CURRENCIES

class Budget(Gtk.Application):
    def __init__(self, path=None):
        super().__init__(application_id='com.crawfordgroupholdings.CGHBudget')
        self.path=path
    def do_activate(self):
        if hasattr(self,'window'): self.window.present(); return
        self.window=Gtk.ApplicationWindow(application=self,title='CGH Budget')
        self.window.set_default_size(1000,700)
        try: self.store=Store(self.path)
        except Exception as error:
            self.error(error); self.window.destroy(); return
        outer=Gtk.Box(orientation=Gtk.Orientation.VERTICAL,spacing=10,margin=16); self.window.add(outer)
        outer.pack_start(Gtk.Label(label='CGH Budget • Private, offline personal budgeting',xalign=0),False,False,0)
        outer.pack_start(Gtk.Label(label='Manual records, not verified bank balances. Backups are private but not encrypted.\nLive-session data may be lost on reboot without persistent storage.',xalign=0),False,False,0)
        bar=Gtk.Box(spacing=8); outer.pack_start(bar,False,False,0)
        for title,action in [('Create budget',self.setup),('Account',self.account),('Category',self.category),('Monthly plan',self.plan),('Transaction',self.transaction),('Bill',self.bill)]:
            button=Gtk.Button(label=title); button.connect('clicked',lambda _,f=action:self.guard(f)); bar.pack_start(button,False,False,0)
        filters=Gtk.Box(spacing=8); outer.pack_start(filters,False,False,0)
        filters.pack_start(Gtk.Label(label='Month YYYY-MM'),False,False,0)
        self.period=Gtk.Entry(text=datetime.date.today().strftime('%Y-%m')); self.period.set_width_chars(8); filters.pack_start(self.period,False,False,0)
        self.query=Gtk.SearchEntry(placeholder_text='Search memo or date'); filters.pack_start(self.query,True,True,0)
        refresh=Gtk.Button(label='Refresh'); refresh.connect('clicked',lambda _:self.guard(self.refresh)); filters.pack_start(refresh,False,False,0)
        self.query.connect('search-changed',lambda _:self.guard(self.refresh))
        self.summary=Gtk.Label(xalign=0,selectable=True); outer.pack_start(self.summary,False,False,0)
        self.tabs=Gtk.Notebook(); outer.pack_start(self.tabs,True,True,0)
        self.views={}
        for title in ('Transactions','Categories','Accounts','Bills'):
            model=Gtk.ListStore(str,str,str,str,str,str,str,str)
            view=Gtk.TreeView(model=model)
            headers={'Transactions':['ID','Date','Kind','Amount','Account','To / category','Memo'], 'Categories':['ID','Category','Planned','Spent','Remaining'], 'Accounts':['ID','Account','Opening (manual)','Balance (manual)'], 'Bills':['ID','Bill','Due','Amount','Status']}[title]
            for i,h in enumerate(headers): view.append_column(Gtk.TreeViewColumn(h,Gtk.CellRendererText(),text=i))
            scroll=Gtk.ScrolledWindow(); scroll.add(view); self.tabs.append_page(scroll,Gtk.Label(label=title)); self.views[title]=(model,view)
        actions=Gtk.Box(spacing=8); outer.pack_start(actions,False,False,0)
        for title,action in [('Correct selected transaction',lambda:self.transaction(True)),('Toggle bill paid',self.toggle_bill),('Preview / export',self.export),('Back up',self.backup),('Restore as new budget file',self.restore)]:
            b=Gtk.Button(label=title); b.connect('clicked',lambda _,f=action:self.guard(f)); actions.pack_start(b,False,False,0)
        self.window.connect('destroy',lambda _:self.store.close())
        self.window.connect('key-press-event',self.keypress)
        self.guard(self.refresh); self.window.show_all()
    def keypress(self,widget,event):
        if event.state & Gdk.ModifierType.CONTROL_MASK:
            key=Gdk.keyval_name(event.keyval).lower()
            if key=='f': self.query.grab_focus(); return True
            if key=='n': self.guard(self.transaction); return True
        return False
    def guard(self,action):
        try: action()
        except Exception as error: self.error(error)
    def error(self,error):
        dialog=Gtk.MessageDialog(transient_for=self.window,modal=True,message_type=Gtk.MessageType.ERROR,buttons=Gtk.ButtonsType.CLOSE,text=str(error)); dialog.run(); dialog.destroy()
    def form(self,title,fields):
        dialog=Gtk.Dialog(title=title,transient_for=self.window,modal=True)
        dialog.add_buttons('Cancel',Gtk.ResponseType.CANCEL,'Save',Gtk.ResponseType.OK)
        dialog.set_default_response(Gtk.ResponseType.OK)
        grid=Gtk.Grid(column_spacing=12,row_spacing=8,margin=16); dialog.get_content_area().add(grid); widgets=[]
        for i,(label,value,choices) in enumerate(fields):
            lab=Gtk.Label(label=label,xalign=0); grid.attach(lab,0,i,1,1)
            if choices is not None:
                widget=Gtk.ComboBoxText()
                for key,text in choices: widget.append(str(key),text)
                widget.set_active_id(str(value))
            else:
                widget=Gtk.Entry(text=str(value)); widget.set_activates_default(True)
            widget.get_accessible().set_name(label); grid.attach(widget,1,i,1,1); widgets.append(widget)
        dialog.show_all(); response=dialog.run()
        result=[w.get_active_id() if isinstance(w,Gtk.ComboBoxText) else w.get_text() for w in widgets] if response==Gtk.ResponseType.OK else None
        dialog.destroy(); return result
    def choices(self,table): return [(r['id'],r['name']) for r in self.store.rows('SELECT * FROM '+table)]
    def setup(self):
        if self.store.config(): raise ValueError('This file already has a budget. Currency cannot be changed after creation.')
        v=self.form('Create budget',[('Name','Household',None),('Currency','USD',[(c,c) for c in CURRENCIES])])
        if v: self.store.setup(*v); self.refresh()
    def account(self):
        v=self.form('Account — manually entered opening balance',[('Name','',None),('Opening balance','0',None)])
        if v: self.store.account(*v); self.refresh()
    def category(self):
        v=self.form('Category',[('Name','',None)])
        if v: self.store.category(*v); self.refresh()
    def plan(self):
        c=self.choices('categories')
        if not c: raise ValueError('Create a category first')
        current=self.store.summary(self.period.get_text())
        v=self.form('Monthly plan',[('Month',self.period.get_text(),None),('Planned monthly income',self.fmt(current['planned_income']),None),('Category',c[0][0],c),('Category budget','0',None)])
        if v: self.store.plan(v[0],v[1],int(v[2]),v[3]); self.refresh()
    def selected(self,title):
        model,it=self.views[title][1].get_selection().get_selected()
        if it is None: raise ValueError('Select a row in '+title)
        return int(model[it][0])
    def fmt(self,n):
        c=self.store.config()['currency']; scale=CURRENCIES[c]
        sign='-' if n<0 else ''; n=abs(n)
        return sign+(str(n) if not scale else f'{n//10**scale}.{n%10**scale:0{scale}d}')
    def transaction(self,edit=False):
        accounts=self.choices('accounts'); cats=[('', 'None')]+self.choices('categories')
        if not accounts: raise ValueError('Create an account first')
        key=self.selected('Transactions') if edit else None
        record=next((e for e in self.store.search() if e['id']==key),None) if edit else None
        r=record or {'date':datetime.date.today().isoformat(),'kind':'expense','account':accounts[0][0],'target':'','category':'','amount':0,'memo':''}
        v=self.form('Correct transaction' if edit else 'Transaction — choose category only for expense; target only for transfer', [('Date YYYY-MM-DD',r['date'],None),('Kind',r['kind'],[(x,x) for x in ('income','expense','transfer')]),('Account',r['account'],accounts),('Amount',self.fmt(r['amount']),None),('Category',r['category'] or '',cats),('Transfer target',r['target'] or '',[('','None')]+accounts),('Memo',r['memo'],None)])
        if v: self.store.entry(v[0],v[1],int(v[2]),v[3],v[6],int(v[4]) if v[4] else None,int(v[5]) if v[5] else None,r['id'] if record else None); self.refresh()
    def bill(self):
        v=self.form('One-time bill — marking paid does not create a transaction',[('Name','',None),('Due YYYY-MM-DD',datetime.date.today().isoformat(),None),('Amount','0',None)])
        if v: self.store.bill(*v); self.refresh()
    def toggle_bill(self):
        key=self.selected('Bills'); r=self.store.rows('SELECT * FROM bills WHERE id=?',(key,))[0]; self.store.paid(key,not r['paid']); self.refresh()
    def refresh(self):
        config=self.store.config()
        if not config: self.summary.set_text('Create a budget to begin.'); return
        s=self.store.summary(self.period.get_text()); self.summary.set_text(f"{config['name']} • {config['currency']} | Planned income {self.fmt(s['planned_income'])} | Actual income {self.fmt(s['income'])} | Spending {self.fmt(s['spending'])}")
        for model,view in self.views.values(): model.clear()
        def add(tab,values): self.views[tab][0].append([str(v) for v in values]+['']*(8-len(values)))
        names=lambda table,key: next((r['name'] for r in self.store.rows('SELECT * FROM '+table) if r['id']==key),'')
        for e in self.store.search(self.query.get_text()): add('Transactions',[e['id'],e['date'],e['kind'],self.fmt(e['amount']),names('accounts',e['account']),names('accounts',e['target']) or names('categories',e['category']),e['memo']])
        for c in s['categories']: add('Categories',[c['id'],c['name'],self.fmt(c['planned']),self.fmt(c['spent']),self.fmt(c['remaining'])])
        for a in self.store.balances(): add('Accounts',[a['id'],a['name'],self.fmt(a['opening']),self.fmt(a['balance'])])
        today=datetime.date.today().isoformat()
        for b in self.store.rows('SELECT * FROM bills ORDER BY due'): add('Bills',[b['id'],b['name'],b['due'],self.fmt(b['amount']),'Paid' if b['paid'] else ('Overdue' if b['due']<today else 'Upcoming')])
    def choose(self,title,save=True):
        d=Gtk.FileChooserDialog(title=title,transient_for=self.window,action=Gtk.FileChooserAction.SAVE if save else Gtk.FileChooserAction.OPEN)
        d.add_buttons('Cancel',Gtk.ResponseType.CANCEL,'Choose',Gtk.ResponseType.OK); response=d.run(); path=d.get_filename() if response==Gtk.ResponseType.OK else None; d.destroy(); return path
    def export(self):
        d=Gtk.Dialog(title='Export preview — includes all account names, amounts and memos',transient_for=self.window,modal=True)
        d.add_buttons('Cancel',Gtk.ResponseType.CANCEL,'Export JSON',Gtk.ResponseType.OK); d.set_default_size(700,450)
        text=Gtk.TextView(editable=False); text.get_buffer().set_text(json.dumps(self.store.export(),indent=2)); scroll=Gtk.ScrolledWindow(); scroll.add(text); d.get_content_area().pack_start(scroll,True,True,0); d.show_all(); response=d.run(); d.destroy()
        if response==Gtk.ResponseType.OK:
            p=self.choose('Save records to a new JSON filename')
            if p: self.store.export_to(p)
    def backup(self):
        p=self.choose('Save private unencrypted SQLite backup to a new filename')
        if p: self.store.backup(p)
    def restore(self):
        source=self.choose('Choose CGH Budget SQLite backup',False)
        if not source:return
        destination=self.choose('Restore to a NEW SQLite file; current budget is preserved')
        if destination:
            Store.restore(source,destination)
            restored=Store(destination)
            self.store.close(); self.store=restored
            self.window.set_title('CGH Budget — '+str(destination)); self.refresh()
            d=Gtk.MessageDialog(transient_for=self.window,modal=True,buttons=Gtk.ButtonsType.OK,text='Restore completed. The restored budget is now open. The previous budget file is preserved.'); d.run(); d.destroy()

if __name__=='__main__':
    import argparse
    parser=argparse.ArgumentParser(); parser.add_argument('--database',type=Path); args=parser.parse_args()
    app=Budget(args.database); app.run([sys.argv[0]])
