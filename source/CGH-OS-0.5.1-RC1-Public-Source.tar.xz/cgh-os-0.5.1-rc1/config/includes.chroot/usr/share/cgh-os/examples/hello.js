console.log('Hello from CGH OS JavaScript!');
