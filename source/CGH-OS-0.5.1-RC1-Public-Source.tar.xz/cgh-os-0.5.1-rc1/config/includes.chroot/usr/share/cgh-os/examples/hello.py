print('Hello from CGH OS Python!')
