import gi,subprocess
from pathlib import Path
gi.require_version("Gtk","3.0")
from gi.repository import Gtk,GLib
GLib.set_prgname("cgh-welcome")
w=Gtk.Window(title="CGH OS — Welcome")
w.set_default_size(760,560);w.set_icon_name("cgh-welcome")
b=Gtk.Box(orientation=Gtk.Orientation.VERTICAL,spacing=14,margin=24);w.add(b)
b.pack_start(Gtk.Label(label="CGH OS",xalign=0),False,False,0)
b.pack_start(Gtk.Label(label="Everyday computing, building, learning, and exploration.",wrap=True,xalign=0),False,False,0)
scroll=Gtk.ScrolledWindow();scroll.set_policy(Gtk.PolicyType.NEVER,Gtk.PolicyType.AUTOMATIC)
view=Gtk.TextView();view.set_editable(False);view.set_cursor_visible(False);view.set_wrap_mode(Gtk.WrapMode.WORD_CHAR)
message = "PREVIEW.txt" if Path("/run/live/medium").exists() else "INSTALLED.txt"
view.get_buffer().set_text((Path("/usr/share/cgh-os") / message).read_text());scroll.add(view);b.pack_start(scroll,True,True,0)
x=Gtk.Button(label="Open CGH Control Center");x.connect("clicked",lambda _:subprocess.Popen(["python3","/usr/share/cgh-os/control_center.py"]));b.pack_start(x,False,False,0)
x=Gtk.Button(label="Close and explore the desktop");x.connect("clicked",lambda _:w.destroy());b.pack_start(x,False,False,0)
w.connect("destroy",Gtk.main_quit);w.show_all();Gtk.main()
