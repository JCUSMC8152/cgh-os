#!/usr/bin/env python3
"""CGH Developer tools: local workspaces and an explicit-request API client."""
import argparse
import http.server
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import threading
import urllib.error
import urllib.parse
import urllib.request
import venv

CONFIG = Path.home() / '.config/cgh-os/developer.json'
TOOLS = ('git', 'python3', 'node', 'npm', 'gcc', 'g++', 'make', 'gdb', 'curl', 'jq', 'sqlite3', 'shellcheck')
MAX_RESPONSE = 1024 * 1024


def load_settings():
    try:
        data = json.loads(CONFIG.read_text())
        return {'workspace': str(Path(data['workspace']).expanduser().resolve())}
    except (OSError, ValueError, KeyError, TypeError):
        return {'workspace': str(Path.home() / 'Projects')}


def save_settings(workspace):
    path = Path(workspace).expanduser().resolve()
    if not path.is_dir():
        raise ValueError('Choose an existing workspace folder.')
    CONFIG.parent.mkdir(parents=True, exist_ok=True)
    temp = CONFIG.with_suffix('.tmp')
    with temp.open('w') as stream:
        os.chmod(temp, 0o600)
        json.dump({'workspace': str(path)}, stream, indent=2)
    temp.replace(CONFIG)


class NoRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, req, fp, code, msg, headers, newurl):
        return None  # Show redirect to the user; never forward credentials automatically.


def api_request(method, url, headers_text='{}', body=''):
    if method not in ('GET', 'HEAD', 'POST', 'PUT', 'PATCH', 'DELETE'):
        raise ValueError('Unsupported request method.')
    parsed = urllib.parse.urlsplit(url)
    if parsed.scheme not in ('http', 'https') or not parsed.hostname or parsed.username or parsed.password:
        raise ValueError('Enter an HTTP or HTTPS URL without embedded credentials.')
    headers = json.loads(headers_text)
    if not isinstance(headers, dict) or not all(isinstance(k, str) and isinstance(v, str) for k, v in headers.items()):
        raise ValueError('Headers must be a JSON object with text keys and values.')
    if any('\r' in k+v or '\n' in k+v for k, v in headers.items()):
        raise ValueError('Header names and values cannot contain line breaks.')
    req = urllib.request.Request(url, data=body.encode() if body else None, headers=headers, method=method)
    opener = urllib.request.build_opener(NoRedirect())
    try:
        response = opener.open(req, timeout=20)
    except urllib.error.HTTPError as error:
        response = error
    with response:
        content = response.read(MAX_RESPONSE + 1)
        truncated = len(content) > MAX_RESPONSE
        text = content[:MAX_RESPONSE].decode(response.headers.get_content_charset() or 'utf-8', errors='replace')
        return f'HTTP {response.status}\n{response.headers}\n{text}' + ('\n[Response limited to 1 MiB]' if truncated else '')


def terminal_task(mode, folder):
    folder = Path(folder).resolve(strict=True)
    if not folder.is_dir():
        raise ValueError('Workspace must be a directory.')
    env = os.environ.copy()
    if mode == 'python':
        target = folder / '.venv'
        if target.exists() and not (target / 'pyvenv.cfg').is_file():
            raise ValueError('.venv exists and is not a Python environment. Choose another folder.')
        if not target.exists():
            venv.EnvBuilder(with_pip=True).create(target)
        env['VIRTUAL_ENV'] = str(target)
        env['PATH'] = str(target / 'bin') + os.pathsep + env.get('PATH', '')
        print('Python environment active:', target, '\nUse: python, pip, deactivate by exiting this terminal.', flush=True)
    elif mode == 'git':
        print('Git workspace:', folder, '\nCommands: git status | git init | git clone URL | git diff | git log\nNo repository is created or changed automatically.', flush=True)
        subprocess.run(['git', 'status', '--short', '--branch'], cwd=folder, check=False)
    elif mode == 'build':
        print('Build tools (no build or installation runs automatically):', flush=True)
        for tool in TOOLS:
            print(f'{tool}: {shutil.which(tool) or "MISSING"}', flush=True)
        print('Use the project instructions. Common commands: make, npm run build, python -m pytest.', flush=True)
    subprocess.run(['bash', '--noprofile', '--norc', '-i'], cwd=folder, env=env, check=False)


def serve(folder):
    from functools import partial
    handler = partial(http.server.SimpleHTTPRequestHandler, directory=str(Path(folder).resolve(strict=True)))
    with http.server.ThreadingHTTPServer(('127.0.0.1', 0), handler) as server:
        print(f'Local preview: http://127.0.0.1:{server.server_port}\nFolder: {folder}\nOnly this computer can connect. Ctrl+C stops the server.\nFiles and symlink targets in this folder can be served; choose a dedicated project folder.', flush=True)
        try:
            server.serve_forever()
        except KeyboardInterrupt:
            pass


def gui(mode):
    import gi
    gi.require_version('Gtk', '3.0')
    from gi.repository import Gtk, GLib
    if mode in ('git', 'python', 'web', 'build', 'database'):
        chooser = Gtk.FileChooserDialog(title='Choose a project folder', action=Gtk.FileChooserAction.SELECT_FOLDER)
        chooser.add_buttons('Cancel', Gtk.ResponseType.CANCEL, 'Open', Gtk.ResponseType.OK)
        base = Path(load_settings()['workspace'])
        if base.is_dir():
            chooser.set_current_folder(str(base))
        if chooser.run() != Gtk.ResponseType.OK:
            chooser.destroy()
            return
        folder = chooser.get_filename()
        chooser.destroy()
        if mode == 'database':
            file_dialog = Gtk.FileChooserDialog(title='Open an existing SQLite database', action=Gtk.FileChooserAction.OPEN)
            file_dialog.add_buttons('Cancel', Gtk.ResponseType.CANCEL, 'Open read-only', Gtk.ResponseType.OK)
            file_dialog.set_current_folder(folder)
            if file_dialog.run() == Gtk.ResponseType.OK:
                subprocess.Popen(['gnome-terminal', '--', 'sqlite3', '-readonly', file_dialog.get_filename()])
            file_dialog.destroy()
        else:
            subprocess.Popen(['gnome-terminal', '--working-directory', folder, '--', sys.executable, str(Path(__file__).resolve()), '--terminal', mode, folder])
        return
    if mode == 'logs':
        subprocess.Popen(['gnome-terminal', '--', 'journalctl', '--user', '-n', '200', '--no-hostname'])
        return
    window = Gtk.Window(title='CGH — ' + ('API Tester' if mode == 'api' else 'Developer Settings'))
    window.set_default_size(760, 620)
    window.set_icon_name('cgh-api' if mode == 'api' else 'cgh-developer-settings')
    window.connect('destroy', Gtk.main_quit)
    box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=10, margin=18)
    window.add(box)
    def label(text):
        item = Gtk.Label(label=text, xalign=0, wrap=True)
        box.pack_start(item, False, False, 0)
    def entry(name, value=''):
        label(name)
        item = Gtk.Entry(text=value)
        item.get_accessible().set_name(name)
        box.pack_start(item, False, False, 0)
        return item
    if mode == 'settings':
        label('Default project folder. Python environments stay inside each project; global system Python is unchanged.')
        workspace = entry('Workspace folder', load_settings()['workspace'])
        button = Gtk.Button(label='Save settings')
        box.pack_start(button, False, False, 0)
        status = Gtk.Label(xalign=0, wrap=True)
        box.pack_start(status, False, False, 0)
        def save(_):
            try:
                save_settings(workspace.get_text())
                status.set_text('Workspace saved.')
            except (OSError, ValueError) as exc:
                status.set_text(str(exc))
        button.connect('clicked', save)
        label('Available development tools:\n' + '\n'.join(f'{x}: {shutil.which(x) or "Not installed"}' for x in TOOLS))
    else:
        label('Requests run only when you press Send. POST, PUT, PATCH and DELETE can change the destination. Credentials and responses are not saved. Redirects are displayed without following them.')
        method = Gtk.ComboBoxText()
        for item in ('GET', 'HEAD', 'POST', 'PUT', 'PATCH', 'DELETE'):
            method.append_text(item)
        method.set_active(0)
        method.get_accessible().set_name('HTTP method')
        box.pack_start(method, False, False, 0)
        url = entry('Request URL')
        headers = entry('Headers (JSON)', '{}')
        body = entry('Request body (text or JSON)')
        button = Gtk.Button(label='Send request')
        box.pack_start(button, False, False, 0)
        output = Gtk.TextView(editable=False, monospace=True, wrap_mode=Gtk.WrapMode.WORD_CHAR)
        output.get_accessible().set_name('API response')
        scroll = Gtk.ScrolledWindow()
        scroll.add(output)
        box.pack_start(scroll, True, True, 0)
        def send(_):
            values = (method.get_active_text(), url.get_text(), headers.get_text(), body.get_text())
            button.set_sensitive(False)
            output.get_buffer().set_text('Sending…')
            def work():
                try:
                    result = api_request(*values)
                except Exception as exc:
                    result = 'Request failed: ' + str(exc)
                def done():
                    output.get_buffer().set_text(result)
                    button.set_sensitive(True)
                    return False
                GLib.idle_add(done)
            threading.Thread(target=work, daemon=True).start()
        button.connect('clicked', send)
    window.show_all()
    Gtk.main()


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('mode', choices=['git', 'python', 'web', 'build', 'api', 'database', 'logs', 'settings'])
    parser.add_argument('folder', nargs='?')
    parser.add_argument('--terminal', action='store_true')
    args = parser.parse_args()
    if args.terminal:
        try:
            if args.mode == 'web':
                serve(args.folder)
            else:
                terminal_task(args.mode, args.folder)
        except Exception as exc:
            print('Could not open developer workspace:', exc, file=sys.stderr)
            input('Press Enter to close.')
            sys.exit(1)
    else:
        gui(args.mode)
