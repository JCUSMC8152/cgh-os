#!/usr/bin/python3
"""Original CGH Workspace GTK interface. MIT; Copyright 2026 Crawford Group Holdings."""
import sys
from pathlib import Path
import sqlite3
from workspace_store import Store, atomic_export


def main():
    try:
        import gi
        gi.require_version('Gtk', '3.0')
        from gi.repository import Gtk, Gio, GLib
    except (ImportError, ValueError):
        print('CGH Workspace needs python3-gi and gir1.2-gtk-3.0. Install the CGH desktop package dependencies.', file=sys.stderr)
        return 1

    class Workspace(Gtk.Application):
        def __init__(self):
            super().__init__(application_id='com.crawfordgroupholdings.CGHWorkspace', flags=Gio.ApplicationFlags.FLAGS_NONE)
            self.window = None
            self.store = None
            self.current = None
            self.loading = False
            self.dirty = False

        def error(self, message):
            dialog = Gtk.MessageDialog(transient_for=self.window, modal=True, message_type=Gtk.MessageType.ERROR, buttons=Gtk.ButtonsType.CLOSE, text=str(message))
            dialog.run()
            dialog.destroy()

        def guarded(self, operation):
            try:
                operation()
            except (OSError, ValueError, sqlite3.Error, GLib.Error) as error:
                self.error(error)

        def do_activate(self):
            if self.window:
                self.window.present()
                return
            self.window = Gtk.ApplicationWindow(application=self, title='CGH Workspace')
            self.window.set_default_size(960, 720)
            self.window.set_icon_name('com.crawfordgroupholdings.CGHWorkspace')
            self.window.connect('delete-event', self.close_window)
            try:
                self.store = Store()
            except (OSError, ValueError, sqlite3.Error) as error:
                self.error('Workspace could not open. Your files have not been moved.\n' + str(error))
                self.quit()
                return
            header = Gtk.HeaderBar(title='CGH Workspace', show_close_button=True)
            self.window.set_titlebar(header)
            new = Gtk.Button.new_from_icon_name('list-add-symbolic', Gtk.IconSize.BUTTON)
            new.set_tooltip_text('New project (Ctrl+N)')
            new.get_accessible().set_name('New project')
            new.connect('clicked', lambda _: self.guarded(self.new_project))
            header.pack_start(new)
            export = Gtk.Button(label='Export…')
            export.connect('clicked', lambda _: self.guarded(self.export))
            header.pack_end(export)
            outer = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=10, margin=12)
            self.window.add(outer)
            notice = Gtk.Label(label='Saved locally between app restarts. A live USB reboot may erase this data. Export to a separate drive to keep a copy.', xalign=0, wrap=True)
            outer.pack_start(notice, False, False, 0)
            pane = Gtk.Paned(orientation=Gtk.Orientation.HORIZONTAL)
            outer.pack_start(pane, True, True, 0)
            side = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=8)
            side.set_size_request(230, -1)
            self.search = Gtk.SearchEntry(placeholder_text='Search projects, notes, tasks')
            self.search.get_accessible().set_name('Search workspace')
            self.search.connect('search-changed', lambda _: self.guarded(self.refresh))
            side.pack_start(self.search, False, False, 0)
            self.rows = Gtk.ListBox()
            self.rows.connect('row-selected', self.selected)
            scroll = Gtk.ScrolledWindow()
            scroll.add(self.rows)
            side.pack_start(scroll, True, True, 0)
            pane.pack1(side, False, False)
            self.details = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=10, margin_start=16)
            pane.pack2(self.details, True, False)
            self.title = Gtk.Label(label='Create a project to get started', xalign=0, wrap=True)
            self.details.pack_start(self.title, False, False, 0)
            self.folder = Gtk.Label(xalign=0, wrap=True, selectable=True)
            self.details.pack_start(self.folder, False, False, 0)
            self.open = Gtk.Button(label='Open linked folder')
            self.open.connect('clicked', lambda _: self.guarded(self.open_folder))
            self.details.pack_start(self.open, False, False, 0)
            self.notes = Gtk.TextView(wrap_mode=Gtk.WrapMode.WORD_CHAR)
            self.notes.get_accessible().set_name('Project notes')
            self.notes.get_buffer().connect('changed', self.notes_changed)
            ns = Gtk.ScrolledWindow()
            ns.set_min_content_height(160)
            ns.add(self.notes)
            self.details.pack_start(Gtk.Label(label='Notes', xalign=0), False, False, 0)
            self.details.pack_start(ns, True, True, 0)
            save = Gtk.Button(label='Save notes (Ctrl+S)')
            save.connect('clicked', lambda _: self.guarded(self.save))
            self.details.pack_start(save, False, False, 0)
            self.task_entry = Gtk.Entry(placeholder_text='New task — press Enter')
            self.task_entry.get_accessible().set_name('New task')
            self.task_entry.connect('activate', lambda _: self.guarded(self.add_task))
            self.details.pack_start(self.task_entry, False, False, 0)
            self.task_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=4)
            ts = Gtk.ScrolledWindow()
            ts.set_min_content_height(100)
            ts.add(self.task_box)
            self.details.pack_start(ts, True, True, 0)
            self.status = Gtk.Label(label='No projects yet. Use + to link an existing folder.', xalign=0, wrap=True)
            outer.pack_start(self.status, False, False, 0)
            self.details.set_sensitive(False)
            for name, accelerator, callback in [('save','<Primary>s',self.save),('new','<Primary>n',self.new_project),('search','<Primary>f',self.search.grab_focus)]:
                action = Gio.SimpleAction.new(name, None)
                action.connect('activate', lambda a,p,fn=callback: self.guarded(fn))
                self.add_action(action)
                self.set_accels_for_action('app.'+name, [accelerator])
            self.refresh()
            first = self.rows.get_row_at_index(0)
            if first:
                self.rows.select_row(first)
            self.window.show_all()

        def refresh(self):
            # Preserve the editor and unsaved notes when filtering.
            for row in self.rows.get_children():
                self.rows.remove(row)
            for pid,name,folder,notes in self.store.projects(self.search.get_text()):
                row = Gtk.ListBoxRow()
                row.project = (pid,name,folder,notes)
                row.add(Gtk.Label(label=name, xalign=0, margin=10, wrap=True))
                self.rows.add(row)
            self.rows.show_all()

        def notes_changed(self, _):
            if not self.loading:
                self.dirty = True
                self.status.set_text('Notes changed — save with Ctrl+S.')

        def save(self):
            if self.current and self.dirty:
                buffer = self.notes.get_buffer()
                self.store.save_notes(self.current[0], buffer.get_text(*buffer.get_bounds(), True))
                self.dirty = False
                self.status.set_text('Notes saved on this session’s filesystem. Export before leaving a live session.')

        def selected(self, _, row):
            if not row:
                return
            try:
                self.save()
                self.current = row.project
                # Reread after save so a selected row cannot restore stale notes.
                project = next(p for p in self.store.projects() if p[0] == self.current[0])
                self.current = project
                self.title.set_text(project[1])
                self.folder.set_text(project[2])
                self.loading = True
                self.notes.get_buffer().set_text(project[3])
                self.loading = False
                self.dirty = False
                self.details.set_sensitive(True)
                self.render_tasks()
                self.status.set_text('Folder linked; existing files stay in place.' if Path(project[2]).is_dir() else 'Linked folder is unavailable. Reconnect the drive to open it; notes and tasks remain available.')
            except (OSError, ValueError, sqlite3.Error) as error:
                self.error(error)

        def new_project(self):
            dialog = Gtk.FileChooserDialog(title='Link an existing project folder', transient_for=self.window, action=Gtk.FileChooserAction.SELECT_FOLDER)
            dialog.add_buttons('Cancel', Gtk.ResponseType.CANCEL, 'Link folder', Gtk.ResponseType.OK)
            try:
                if dialog.run() != Gtk.ResponseType.OK:
                    return
                folder = dialog.get_filename()
            finally:
                dialog.destroy()
            dialog = Gtk.Dialog(title='Name project', transient_for=self.window, modal=True)
            entry = Gtk.Entry(text=Path(folder).name, activates_default=True)
            dialog.get_content_area().add(entry)
            dialog.add_buttons('Cancel', Gtk.ResponseType.CANCEL, 'Create', Gtk.ResponseType.OK)
            dialog.set_default_response(Gtk.ResponseType.OK)
            dialog.show_all()
            try:
                if dialog.run() != Gtk.ResponseType.OK:
                    return
                pid = self.store.create(entry.get_text(), folder)
            finally:
                dialog.destroy()
            self.search.set_text('')
            self.refresh()
            for row in self.rows.get_children():
                if row.project[0] == pid:
                    self.rows.select_row(row)

        def open_folder(self):
            path = Path(self.current[2])
            if not path.is_dir():
                raise ValueError('Linked folder is unavailable. Reconnect its drive; CGH Workspace will not create or move it.')
            Gio.AppInfo.launch_default_for_uri(path.as_uri(), None)

        def render_tasks(self):
            for child in self.task_box.get_children():
                self.task_box.remove(child)
            for tid,title,done in self.store.tasks(self.current[0]):
                check = Gtk.CheckButton(label=title)
                check.set_active(bool(done))
                check.connect('toggled', lambda button, task=tid: self.guarded(lambda: self.store.set_done(task, button.get_active())))
                self.task_box.pack_start(check, False, False, 0)
            self.task_box.show_all()

        def add_task(self):
            if self.current:
                self.store.add_task(self.current[0], self.task_entry.get_text())
                self.task_entry.set_text('')
                self.render_tasks()

        def export(self):
            self.save()
            content = self.store.export()
            preview = Gtk.Dialog(title='Review export — contains your notes and folder paths', transient_for=self.window, modal=True)
            preview.set_default_size(650, 450)
            view = Gtk.TextView(editable=False, monospace=True, wrap_mode=Gtk.WrapMode.WORD_CHAR)
            view.get_buffer().set_text(content)
            scroll = Gtk.ScrolledWindow()
            scroll.add(view)
            preview.get_content_area().pack_start(scroll, True, True, 0)
            preview.add_buttons('Cancel', Gtk.ResponseType.CANCEL, 'Choose export file…', Gtk.ResponseType.OK)
            preview.show_all()
            try:
                if preview.run() != Gtk.ResponseType.OK:
                    return
            finally:
                preview.destroy()
            dialog = Gtk.FileChooserDialog(title='Export workspace metadata (linked files are not copied)', transient_for=self.window, action=Gtk.FileChooserAction.SAVE)
            dialog.add_buttons('Cancel', Gtk.ResponseType.CANCEL, 'Export', Gtk.ResponseType.OK)
            dialog.set_current_name('cgh-workspace.json')
            dialog.set_do_overwrite_confirmation(True)
            try:
                if dialog.run() == Gtk.ResponseType.OK:
                    atomic_export(dialog.get_filename(), content)
                    self.status.set_text('Export saved. Keep it on a separate drive for live-session use. Linked files need their own backup.')
            finally:
                dialog.destroy()

        def close_window(self, *_):
            try:
                self.save()
            except (OSError, ValueError, sqlite3.Error) as error:
                self.error('Notes could not be saved. The window will stay open.\n' + str(error))
                return True
            return False

        def do_shutdown(self):
            if self.store:
                self.store.close()
            Gtk.Application.do_shutdown(self)

    return Workspace().run(sys.argv)


if __name__ == '__main__':
    raise SystemExit(main())
