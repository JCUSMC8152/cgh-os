"""Remove CGH live-only configuration from the installed target."""
from pathlib import Path

LIVE_FILES = (
    'etc/systemd/system/cgh-live-credentials.service',
    'etc/systemd/system/graphical.target.wants/cgh-live-credentials.service',
    'etc/systemd/system/getty@.service.d/60-cgh-credentials.conf',
    'etc/systemd/system/serial-getty@.service.d/60-cgh-credentials.conf',
    'etc/systemd/system/display-manager.service.d/60-cgh-credentials.conf',
    'usr/local/sbin/cgh-live-credentials',
    'usr/local/bin/cgh-install',
    'usr/local/sbin/cgh-calamares-root',
    'usr/share/polkit-1/actions/com.crawfordgroupholdings.install.policy',
    'usr/share/applications/calamares-install-debian.desktop',
    'usr/share/applications/install-debian.desktop',
    'etc/xdg/autostart/calamares-desktop-icon.desktop',
    'var/lib/systemd/random-seed',
)


def finalize(root):
    root = Path(root).resolve()
    if root == Path('/') or not (root / 'etc/debian_version').is_file():
        raise ValueError('Refusing invalid installation target')
    # Resolve each parent, not the final symlink: unlinking a live service link
    # must remove the link rather than its target.
    for name in LIVE_FILES:
        p = root / name
        if not p.parent.resolve().is_relative_to(root):
            raise ValueError('Target directory escapes installation root')
        p.unlink(missing_ok=True)
    return root


def run():
    import libcalamares
    try:
        root = finalize(libcalamares.globalstorage.value('rootMountPoint'))
        # Keep the superuser locked; the named installer-created user uses sudo.
        rc = libcalamares.utils.target_env_call(['passwd', '-l', 'root'])
        if rc:
            return ('Root account lock failed', 'Could not secure the installed root account.')
        (root / 'etc/apt/sources.list').write_text(
            'deb https://deb.debian.org/debian trixie main non-free-firmware\n'
            'deb https://deb.debian.org/debian trixie-updates main non-free-firmware\n'
            'deb https://deb.debian.org/debian-security trixie-security main non-free-firmware\n')
    except (OSError, ValueError, TypeError) as error:
        return ('CGH installed-system configuration failed', str(error))
    return None
