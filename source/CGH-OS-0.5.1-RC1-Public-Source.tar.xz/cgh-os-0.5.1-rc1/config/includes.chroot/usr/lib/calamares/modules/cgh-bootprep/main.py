"""Use bundled bootloader files; installation must not download boot packages."""
from pathlib import Path


def run():
    import libcalamares
    root = Path(libcalamares.globalstorage.value('rootMountPoint'))
    if not root.is_absolute() or root == Path('/') or not (root / 'etc/debian_version').is_file():
        return ('Invalid installation target', 'CGH boot preparation refused an invalid target root.')
    # Both BIOS and UEFI GRUB platform files are bundled in the candidate.
    platform = 'x86_64-efi' if Path('/sys/firmware/efi').exists() else 'i386-pc'
    if not (root / 'usr/lib/grub' / platform / 'modinfo.sh').is_file():
        return ('Missing bootloader files', 'Required GRUB platform is not bundled: ' + platform)
    p = root / 'etc/initramfs-tools/conf.d/60-cgh-permissions'
    p.write_text('UMASK=0077\n')
    return None
