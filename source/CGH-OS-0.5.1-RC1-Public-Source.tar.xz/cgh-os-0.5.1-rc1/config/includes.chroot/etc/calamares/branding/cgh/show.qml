import QtQuick 2.0
import calamares.slideshow 1.0
Presentation {
    Slide {
        Image {
            source: "/usr/share/backgrounds/cgh-orbit-approved.png"
            anchors.centerIn: parent
            width: parent.width * 0.85
            height: parent.height * 0.72
            fillMode: Image.PreserveAspectFit
        }
        Text {
            anchors.bottom: parent.bottom
            anchors.horizontalCenter: parent.horizontalCenter
            width: parent.width * 0.9
            wrapMode: Text.WordWrap
            horizontalAlignment: Text.AlignHCenter
            text: "CGH OS is based on Debian. Keep the laptop connected to power while installation completes."
        }
    }
}
